        function setActive(category) {
            document.querySelectorAll('.title').forEach(title => title.classList.remove('active'));
            const selectedTitle = document.getElementById(`title${category.charAt(0).toUpperCase() + category.slice(1)}`);
            
            if (selectedTitle) {
                selectedTitle.classList.add('active');
                showCategory(category);
            } 
        }
        

        // Display service items based on selected category
        function showCategory(category) {
            const services = {
                mobil: `
                    <div class="service" onclick="navigateTo('perawatan_mobil')" data-menu="perawatan_mobil"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
                    <div class="service" onclick="navigateTo('perbaikan_mobil')" data-menu="perbaikan_mobil"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
                    <div class="service" onclick="navigateTo('inspeksi_mobil')" data-menu="inspeksi_mobil"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
                    <div class="service" onclick="navigateTo('sukucadang_mobil')" data-menu="sukucadang_mobil"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
                    <div class="service" onclick="navigateTo('kustom_mobil')" data-menu="kustom_mobil"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
                    <div class="service" onclick="navigateTo('darurat_mobil')" data-menu="darurat_mobil"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
                    <div class="service" onclick="navigateTo('diagnostik_mobil')" data-menu="diagnostik_mobil"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
                    <div class="service" onclick="navigateTo('cuci_mobil')" data-menu="cuci_mobil"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
                `,
                
                motor: `
                    <div class="service" onclick="navigateTo('perbaikan_motor')" data-menu="perbaikan_motor"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
                    <div class="service" onclick="navigateTo('perawatan_motor')" data-menu="perawatan_motor"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
                    <div class="service" onclick="navigateTo('kustom_motor')" data-menu="kustom_motor"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
                    <div class="service" onclick="navigateTo('inspeksi_motor')" data-menu="inspeksi_motor"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
                    <div class="service" onclick="navigateTo('darurat_motor')" data-menu="darurat_motor"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
                    <div class="service" onclick="navigateTo('sukucadang_motor')" data-menu="sukucadang_motor"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
                    <div class="service" onclick="navigateTo('diagnostik_motor')" data-menu="diagnostik_motor"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
                    <div class="service" onclick="navigateTo('cuci_motor')" data-menu="cuci_motor"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
                    `,
                    
                    teknisi: `
                    <div class="service" onclick="navigateTo('teknisi_mobil')" data-menu="teknisi_mobil"><i class="bi bi-car-front icon"></i><div class="text">Teknisi Mobil</div></div>
                    <div class="service" onclick="navigateTo('teknisi_motor')" data-menu="teknisi_motor"><i class="bi bi-bicycle icon"></i><div class="text">Teknisi Motor</div></div>
                    `,
                    
            };
            document.getElementById('servicesContainer').innerHTML = services[category];
        }

        // Load category based on URL parameter or default to "Mobil"
        document.addEventListener('DOMContentLoaded', function () {
            const params = new URLSearchParams(window.location.search);
            const menu = params.get('menu') || 'mobil'; // Default to 'mobil' if no 'menu' parameter is present
            setActive(menu);
        });
        
        