function navigateTo(menu, id) {
    $.ajax({
        url: '_fungsi/content_loader.php',
        type: 'GET',
        data: { menu: menu, id: id },
        success: function (response) {
            $('#main-content').fadeOut(0, function() {
                $(this).html(response).fadeIn(0);
            });
            $('a[data-menu]').removeClass('active');
            $(`a[data-menu="${menu}"]`).addClass('active');
        },
        error: function (xhr, status, error) {
            console.error("Error loading content:", status, error);
            $('#main-content').html('<p>Error loading content. Please try again later.</p>');
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const menu = params.get('menu') || 'home'; // Jika tidak ada parameter 'menu', set default ke 'home'

    // Panggil fungsi yang sesuai berdasarkan parameter, atau default ke 'home'
    switch (menu) {
        case 'home':
            home();
            break;
        case 'home_bottom':
            home_bottom();
            break;
        case 'service':
            service();
            break;
        case 'booking':
            booking();
            break;
        case 'history':
            history();
            break;
        case 'profile':
            profile();
            break;
        case 'about':
            about();
            break;
        default:
            home(); // Jika tidak ada menu yang sesuai, default ke 'home'
    }
});

function home() { navigateTo('home'); }
function home_bottom() { navigateTo('home_bottom'); }
function service() { navigateTo('service'); }
function booking() { navigateTo('booking'); }
function history() { navigateTo('history'); }
function profile() { navigateTo('profile'); }
function about() { navigateTo('about'); }

document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const menu = params.get('menu') || ''; 
});

// Event listener untuk menutup sidebar saat item menu diklik
$('.nav-link:not(.dropdown-btn)').on('click', function () {
if ($('.sidebar').hasClass('open')) {
    toggleSidebar(); // Tutup sidebar setelah item menu diklik
}
closeAllDropdowns(); // Tutup semua dropdown saat menu lain diklik
});

// Tutup sidebar jika klik di luar sidebar
$(document).click(function (e) {
if (!$(e.target).closest('.sidebar, .navbar-toggler').length) {
    if ($('.sidebar').hasClass('open')) {
        toggleSidebar();
    }
}
});

// Event listener untuk menutup dropdown saat item di dalam dropdown diklik
$('.dropdown-container .nav-link').on('click', function () {
closeAllDropdowns(); // Tutup semua dropdown saat salah satu item diklik
});

// Pastikan semua dropdown tertutup saat halaman dimuat
closeAllDropdowns();

// Fungsi untuk membuka dan menutup sidebar
function toggleSidebar() {
const sidebar = $('.sidebar');

// Toggle kelas 'open' pada sidebar
sidebar.toggleClass('open');
}

function toggleSidebar() {
const topNavbar = $('.topNavbar');
const sidebar = $('.sidebar');
const body = $('body');

// Toggle kelas 'open' pada sidebar
sidebar.toggleClass('open');

// Atur posisi body dan navbar berdasarkan status sidebar
if (sidebar.hasClass('open')) {
topNavbar.css('left', '0'); // Sesuaikan dengan lebar sidebar
body.css('margin-left', '50px'); // Sesuaikan dengan lebar sidebar
} else {
topNavbar.css('left', '0');
body.css('margin-left', '5px');
sidebar.css('top', '48px'); // Kembali ke posisi semula atau tetap di 70px
}
}

// Fungsi untuk menutup semua dropdown
function closeAllDropdowns() {
$('.dropdown-container').slideUp(); // Sembunyikan semua dropdown
}

// Fungsi untuk membuka dan menutup dropdown
function toggleDropdown(id) {
// Tutup semua dropdown sebelum menampilkan yang dipilih
closeAllDropdowns();

// Toggle dropdown yang dipilih jika belum terbuka
const dropdown = $('#' + id);
if (!dropdown.is(':visible')) {
dropdown.slideDown(); // Buka dropdown jika belum terbuka
}
}

// Fungsi untuk mengaktifkan menu yang diklik
function activateMenu(menu) {
// Hapus kelas 'active' dari semua menu-item
document.querySelectorAll('.menu-item').forEach(item => {
item.classList.remove('active');
});

// Tambahkan kelas 'active' pada menu yang diklik
const selectedMenu = document.querySelector(`[data-menu="${menu}"]`);
selectedMenu.classList.add('active');
}
