function toggleServices(menuId) {
    const menu = document.getElementById(menuId);
    const services = menu.querySelectorAll('.service');
    const toggleButton = menu.nextElementSibling;

    // Toggle visibility of elements after the second
    services.forEach((service, index) => {
        if (index >= 2) {
            service.classList.toggle('hidden');
        }
    });

    // Update the toggle button text
    const isHidden = services[2].classList.contains('hidden');
    toggleButton.innerHTML = isHidden 
        ? 'Lihat Lainnya <i>▼</i>' 
        : 'Sembunyikan <i>▲</i>';
}

// Load transaksi detail (dummy function, replace with real implementation)
function loadTransaksi(idLayanan) {
    alert(`Load detail transaksi untuk layanan ID: ${idLayanan}`);
}


function goToTransaction(namaTeknisi) {
    // Redirect ke URL baru dengan parameter namaTeknisi
    const url = `teknisi?namaTeknisi=${encodeURIComponent(namaTeknisi)}`;
    window.location.href = url;
}

document.addEventListener("DOMContentLoaded", function () {
    const serviceItems = document.querySelectorAll(".service");

    console.log(serviceItems); // Debugging: memastikan elemen ditemukan

    serviceItems.forEach(item => {
        item.addEventListener("click", function () {
            const index = this.getAttribute("data-index");
            const id = this.getAttribute("data-id");

            console.log("Klik pada layanan:", index, id); // Debugging log

            if (index !== null && id !== null) {
                window.location.href = `/transaksi/${index}/${encodeURIComponent(id)}`;
            }
        });
    });
});

function loadTeknisi(namaTeknisi) {
    const content = document.getElementById('main-content');
    content.classList.add('loading'); // Tambahkan efek loading
    fetch(`_page/service/teknisi.php?namaTeknisi=${encodeURIComponent(namaTeknisi)}`)
        .then(response => response.text())
        .then(html => {
            content.innerHTML = html;
        })
        .finally(() => {
            content.classList.remove('loading'); // Hapus efek loading
        });
}

function loadTransaksi(layanan) {
    // Kirim permintaan AJAX ke transaksi.php
    fetch(`_page/service/transaksi.php?layanan=${encodeURIComponent(layanan)}`)
        .then(response => response.text())
        .then(html => {
            // Muat hasil ke dalam div #main-content
            document.getElementById('main-content').innerHTML = html;
        })
        .catch(error => {
            console.error('Gagal memuat layanan:', error);
        });
}

let teknisiIdTerpilih = null;

function showTeknisiDetails(teknisi) {
    const detailContent = document.getElementById('detail-teknisi-content');
    const btnLanjut = document.getElementById('btn-lanjut');

    // Simpan ID teknisi yang dipilih
    teknisiIdTerpilih = teknisi.id_teknisi;

    // Isi detail teknisi
    detailContent.innerHTML = `
        <img src="path_to_images/${teknisi.foto}" alt="Foto ${teknisi.nama}" style="width: 100px; height: 100px;">
        <p><strong>Nama:</strong> ${teknisi.nama}</p>
        <p><strong>Kategori:</strong> ${teknisi.kategori}</p>
        <p><strong>Spesialisasi:</strong> ${teknisi.spesialisasi}</p>
        <p><strong>Alamat:</strong> ${teknisi.alamat}</p>
    `;

    // Tampilkan tombol "Lanjut"
    btnLanjut.style.display = 'block';
}

function lanjutTransaksi() {
    // Cek apakah teknisi telah dipilih
    if (!teknisiIdTerpilih) {
        alert('Silakan pilih teknisi terlebih dahulu.');
        return;
    }

    const layananInput = document.querySelector('input[name="id_layanan"]');
    if (!layananInput) {
        alert('Layanan ID tidak ditemukan. Silakan coba lagi.');
        return;
    }

    const layananId = layananInput.value;

    // Kirim data ke server
    fetch('_page/service/detail-transaksi.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id_teknisi=${teknisiIdTerpilih}&id_layanan=${layananId}`
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.text();
    })
    .then(html => {
        const mainContent = document.getElementById('main-content');
        if (mainContent) {
            mainContent.innerHTML = html;
        } else {
            console.error('#main-content tidak ditemukan di halaman!');
        }
    })
    .catch(error => {
        console.error('Gagal memuat transaksi:', error);
        alert('Terjadi kesalahan saat memuat transaksi. Silakan coba lagi.');
    });
}

function Konfirmasi(event) {
    event.preventDefault();

    // Tampilkan SweetAlert konfirmasi sebelum melanjutkan
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Transaksi akan diproses setelah Anda mengonfirmasi.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Konfirmasi!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        // Jika pengguna memilih "Ya, Konfirmasi!", lanjutkan proses pengiriman form
        if (result.isConfirmed) {
            // Ambil data dari form
            const formData = new FormData(document.getElementById('form-teknisi'));

            // Kirim data ke server
            fetch('_page/service/purchase.php', {
                method: 'POST',
                body: new URLSearchParams(formData) // Mengonversi FormData ke format URL-encoded
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.text();
            })
            .then(html => {
                // Tampilkan SweetAlert untuk keberhasilan
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil dikonfirmasi!',
                    text: 'Tunggu teknisi kami datang ya!!',
                    confirmButtonText: 'OK'
                }).then(() => {
                    // Update konten halaman dengan respons
                    document.getElementById('main-content').innerHTML = html;
                });
            })
            .catch(error => {
                console.error('Error:', error);
                // Tampilkan SweetAlert jika terjadi kesalahan
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'Terjadi kesalahan saat memproses transaksi.',
                    confirmButtonText: 'Coba Lagi'
                });
            });
        } else {
            // Jika pengguna memilih "Batal", tidak ada tindakan yang dilakukan
            console.log('Transaksi dibatalkan.');
        }
    });
}

function konfirmasiBooking(event) {
    event.preventDefault();

    // Validasi tanggal dan waktu
    const tanggal = document.getElementById('tanggal').value;
    const pukul = document.getElementById('pukul').value;
    const sekarang = new Date();
    const bookingTime = new Date(`${tanggal}T${pukul}`);

    if (bookingTime < sekarang) {
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Tanggal atau waktu tidak boleh di masa lalu.',
            confirmButtonText: 'Coba Lagi'
        });
        return;
    }

    // Tampilkan SweetAlert konfirmasi sebelum melanjutkan
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Transaksi akan diproses setelah Anda mengonfirmasi.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Konfirmasi!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            // Ambil data dari form
            const formData = new FormData(document.getElementById('form-group'));  // Correct form ID here

            // Kirim data ke server
            fetch('_page/booking/purchase.php', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(html => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil dikonfirmasi!',
                        text: 'Tunggu konfirmasi dari teknisi kami ya!!',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        document.getElementById('main-content').innerHTML = html;
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: 'Terjadi kesalahan saat memproses transaksi.',
                        confirmButtonText: 'Coba Lagi'
                    });
                });
        } else {
            console.log('Transaksi dibatalkan.');
        }
    });
}



function bookTechnician(teknisiId) {
    // Validasi ID teknisi
    if (!teknisiId || isNaN(teknisiId)) {
        alert('ID teknisi tidak valid!');
        return;
    }

    // Buat FormData dengan nama kolom id_teknisi
    const formData = new FormData();
    formData.append('id_teknisi', teknisiId);

    // Tampilkan indikator loading
    const mainContent = document.getElementById('main-content');
    // if (mainContent) {
    //     mainContent.innerHTML = '<p>Sedang memuat...</p>';
    // }

    // Kirim permintaan POST ke server
    fetch('_page/booking/bookteknisi.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.text(); // Asumsikan server mengembalikan HTML
        })
        .then(html => {
            // Update konten di halaman utama
            if (mainContent) {
                mainContent.innerHTML = html; // Update konten dengan HTML dari server
            } else {
                console.error('#main-content tidak ditemukan di halaman utama!');
            }
        })
        .catch(error => {
            console.error('Gagal memuat halaman booking:', error);
            if (mainContent) {
                mainContent.innerHTML = '<p>Terjadi kesalahan. Silakan coba lagi nanti.</p>';
            }
            alert('Terjadi kesalahan saat memuat halaman booking. Silakan coba lagi.');
        });
}

function processBooking(teknisiId) {
    const selectedSpecialization = document.querySelector('input[name="spesialisasi"]:checked');

    if (!selectedSpecialization) {
        alert('Pilih salah satu spesialisasi terlebih dahulu.');
        return;
    }

    const formData = new FormData();
    formData.append('id_teknisi', teknisiId);
    formData.append('spesialisasi', selectedSpecialization.value);

    const mainContent = document.getElementById('main-content');
    // if (mainContent) {
    //     mainContent.innerHTML = '<p>Sedang memuat...</p>';
    // }

    fetch('_page/booking/pilih_layanan.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.text();
        })
        .then(html => {
            if (mainContent) {
                mainContent.innerHTML = html;
            } else {
                console.error('#main-content tidak ditemukan di halaman utama!');
            }
        })
        .catch(error => {
            console.error('Gagal memuat halaman layanan:', error);
            if (mainContent) {
                mainContent.innerHTML = '<p>Terjadi kesalahan. Silakan coba lagi nanti.</p>';
            }
            alert('Terjadi kesalahan saat memuat halaman layanan. Silakan coba lagi.');
        });
}

function showDetails(id, deskripsi, harga) {
    // Tampilkan elemen detail
    const detailsDiv = document.getElementById('layanan-details');
    detailsDiv.style.display = 'block';

    // Masukkan deskripsi dan harga ke dalam elemen
    document.getElementById('layanan-deskripsi').textContent = `Deskripsi: ${deskripsi}`;
    document.getElementById('layanan-harga').textContent = `Harga: Rp ${parseInt(harga).toLocaleString()}`;
}

function processLayanan(teknisiId) {
    const selectedLayanan = document.querySelector('input[name="id_layanan"]:checked');

    if (!selectedLayanan) {
        alert('Pilih salah satu layanan terlebih dahulu.');
        return;
    }

    const formData = new FormData();
    formData.append('id_teknisi', teknisiId);
    formData.append('id_layanan', selectedLayanan.value);

    const mainContent = document.getElementById('main-content');
    // if (mainContent) {
    //     mainContent.innerHTML = '<p>Sedang memuat...</p>';
    // }

    fetch('_page/booking/isi_alamat.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.text();
        })
        .then(html => {
            if (mainContent) {
                mainContent.innerHTML = html;
            } else {
                console.error('#main-content tidak ditemukan di halaman utama!');
            }
        })
        .catch(error => {
            console.error('Gagal memuat halaman alamat:', error);
            if (mainContent) {
                mainContent.innerHTML = '<p>Terjadi kesalahan. Silakan coba lagi nanti.</p>';
            }
            alert('Terjadi kesalahan saat memuat halaman alamat. Silakan coba lagi.');
        });
}


function showService(serviceType) {
    // Sembunyikan kedua card terlebih dahulu
    document.getElementById('serviceLangsungCard').style.display = 'none';
    document.getElementById('serviceBookingCard').style.display = 'none';
  
    // Sembunyikan title aktif sebelumnya
    document.querySelectorAll('.title').forEach(title => title.classList.remove('active'));
  
    // Tampilkan card yang sesuai berdasarkan pilihan
    if (serviceType === 'langsung') {
      document.getElementById('serviceLangsungCard').style.display = 'block';
      document.getElementById('serviceLangsungBtn').classList.add('active');
    } else if (serviceType === 'booking') {
      document.getElementById('serviceBookingCard').style.display = 'block';
      document.getElementById('serviceBookingBtn').classList.add('active');
    }
  }
  
  // Secara default, tampilkan Service Langsung saat halaman dimuat
  window.onload = function() {
    showService('langsung');
  }
  
  
function openModalHarga(idHistory = '', idHistoryBooking = '', layanan = '', harga = '', eWalletNames = '') {
    const modal = document.getElementById('paymentModal');
    modal.style.display = 'flex';
    document.getElementById('modalLayanan').textContent = layanan;
    document.getElementById('modalHarga').textContent = harga;
  
    // Tampilkan semua metode e-wallet sebagai tombol
    const eWalletButtonsContainer = document.getElementById('eWalletButtons');
    eWalletButtonsContainer.innerHTML = ''; // Kosongkan sebelumnya
  
    // Pisahkan eWalletNames jika dipisahkan dengan koma
    const eWalletArray = eWalletNames.split(', ');
    eWalletArray.forEach(eWalletName => {
      const button = document.createElement('button');
      button.className = 'btn-modal';
      button.textContent = eWalletName;
      button.setAttribute('onclick', `selectPayment('${eWalletName}')`);
      eWalletButtonsContainer.appendChild(button);
    });
  
    // Simpan kedua ID yang dipilih
    window.selectedHistoryId = idHistory;
    window.selectedHistoryBookingId = idHistoryBooking;
  
    // Tambahkan event listener untuk menutup modal jika klik di luar modal
    document.addEventListener('click', closeModalOutsideClick);
  }
  

// Fungsi untuk menutup modal
// Fungsi untuk menutup modal
function closeModalHarga() {
    const modal = document.getElementById('paymentModal');
    modal.style.display = 'none';

    // Hapus event listener untuk menghindari kebocoran memori
    document.removeEventListener('click', closeModalOutsideClick);
}

// Fungsi untuk menutup modal jika klik di luar area modal
function closeModalOutsideClick(event) {
    const modal = document.getElementById('paymentModal');
    if (event.target === modal) {
        closeModalHarga();
    }
}

// Tutup modal saat pengguna mengklik di luar modal
window.onclick = function(event) {
    const modal = document.getElementById('paymentModal');
    if (event.target === modal) {
        closeModal();
    }
}

function selectPayment(method) {
    // Ambil kedua ID yang dipilih
    const idHistory = window.selectedHistoryId;
    const idHistoryBooking = window.selectedHistoryBookingId;

    // Buat form data yang akan dikirim ke server
    const formData = new FormData();
    formData.append('payment_method', method);
    formData.append('id_history', idHistory);
    formData.append('id_history_booking', idHistoryBooking);

    // Gunakan fetch untuk mengirim data dan mengisi #main-content
    fetch('../../_fungsi/history/konfirmasi_pembayaran.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(html => {
        // Isi elemen dengan ID #main-content dengan konten dari server
        document.getElementById('main-content').innerHTML = html;
    })
    .catch(error => {
        console.error('Terjadi kesalahan:', error);
    });
}

function confirmPayment(paymentMethod, idHistory, idHistoryBooking) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: `Konfirmasi pembayaran dengan metode ${paymentMethod}`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Konfirmasi!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            // Buat form data untuk dikirim ke server
            const formData = new FormData();
            formData.append('payment_method', paymentMethod);
            formData.append('id_history', idHistory);
            formData.append('id_history_booking', idHistoryBooking);

            // Kirim request untuk update status pembayaran
            fetch('../../_fungsi/history/update_pembayaran.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Pembayaran berhasil dikonfirmasi!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        // Refresh halaman atau alihkan ke halaman lain
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'Gagal!',
                        text: 'Terjadi kesalahan saat mengonfirmasi pembayaran.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            })
            .catch(error => {
                console.error('Terjadi kesalahan:', error);
                Swal.fire({
                    title: 'Error!',
                    text: 'Tidak dapat terhubung ke server.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            });
        }
    });
}

function lihatHistory(idHistory = null, idHistoryBooking = null) {
    // Buat URL dengan parameter
    let url = '../../_page/history/purchase.php';
    if (idHistory) {
        url += `?id_history=${idHistory}`;
    } else if (idHistoryBooking) {
        url += `?id_history_booking=${idHistoryBooking}`;
    }

    // Ambil elemen main-content dan lakukan fetch untuk memuat konten
    const mainContent = document.getElementById('main-content');
    fetch(url)
        .then(response => response.text())
        .then(data => {
            mainContent.innerHTML = data;
        })
        .catch(error => {
            console.error('Error fetching purchase page:', error);
            mainContent.innerHTML = '<p>Gagal memuat data. Silakan coba lagi.</p>';
        });
}
