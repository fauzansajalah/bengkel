// Fungsi untuk memuat detail teknisi secara dinamis
function loadTeknisiDetail(teknisiId) {
    // Menggunakan AJAX untuk memuat konten dari teknisi.php
    const xhr = new XMLHttpRequest();
    xhr.open('GET', '_page/booking/teknisi/teknisi.php?id=' + teknisiId, true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Menyisipkan konten yang diterima ke dalam container di halaman utama
            document.getElementById('main-content').innerHTML = xhr.responseText;
        } else {
            console.error('Terjadi kesalahan saat memuat detail teknisi.');
        }
    };
    xhr.send();
}

function toggleTechnicianMenu(menuId) {
    const menu = document.getElementById(menuId);
    const hiddenItems = menu.querySelectorAll('.hidden');
    const toggleButton = menu.nextElementSibling;

    if (hiddenItems.length > 0) {
        hiddenItems.forEach(item => item.classList.remove('hidden'));
        toggleButton.innerHTML = "Sembunyikan <i>▲</i>";
    } else {
        menu.querySelectorAll('.teknisi-item:nth-child(n+3)').forEach(item => item.classList.add('hidden'));
        toggleButton.innerHTML = "Lihat Lainnya <i>▼</i>";
    }
}
