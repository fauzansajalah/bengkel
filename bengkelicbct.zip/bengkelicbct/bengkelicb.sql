-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: bengkelicb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_admin`),
  UNIQUE KEY `username` (`nama`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','123','admin aja','admin@example.com','08123456789','2024-12-14 11:09:38'),(2,'superadmin','123','Super Admin','admin1@example.com','081234567890','2024-12-14 11:30:38');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_logs`
--

DROP TABLE IF EXISTS `admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_admin` int NOT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_admin` (`id_admin`),
  CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `admin` (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_logs`
--

LOCK TABLES `admin_logs` WRITE;
/*!40000 ALTER TABLE `admin_logs` DISABLE KEYS */;
INSERT INTO `admin_logs` VALUES (1,2,'Mengedit teknisi: Fauzan (ID: 1)','2024-12-28 18:55:52'),(2,2,'Admin menambahkan teknisi: apa (apalah@example.com)','2024-12-28 18:57:48'),(3,2,'Admin menghapus teknisi: apa (apalah@example.com)','2024-12-28 19:03:07'),(4,2,'Mengedit teknisi: manusia serigala (ID: 2)','2024-12-28 19:03:45'),(5,2,'Mengedit teknisi: Fauzan (ID: 1)','2024-12-28 19:06:14'),(6,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-28 20:01:10'),(7,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-28 20:07:10'),(8,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-28 20:07:20'),(9,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-28 20:07:28'),(10,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-28 20:09:36'),(11,2,'Mengedit layanan: Perawatan AC (ID: 3)','2024-12-28 20:09:45'),(12,2,'Menambah layanan: testing','2024-12-28 20:19:34'),(13,2,'Admin menghapus layanan: testing (Kategori: Mobil)','2024-12-28 20:44:53'),(14,2,'Mengedit data admin: Administrator (ID: 1)','2024-12-28 21:34:46'),(15,2,'Mengedit data admin: Administrator (ID: 1)','2024-12-28 21:39:52'),(16,2,'Mengedit data admin: Administrator (ID: 1)','2024-12-28 21:42:42'),(17,2,'Mengedit data admin: Nama Lengkap Admin (ID: 3)','2024-12-28 21:43:06'),(18,2,'Mengedit data admin: Nama Lengkap Admin (ID: 3)','2024-12-28 21:43:54'),(19,2,'Mengedit data admin: Administrator (ID: 1)','2024-12-28 21:44:20'),(20,2,'Menambahkan admin: fauzannnnnnnnn','2024-12-28 21:56:30'),(21,2,'Menghapus admin dengan nama: fauzan','2024-12-28 22:04:42'),(22,2,'Mengedit layanan: Service Berkala (ID: 1)','2024-12-29 09:26:05'),(23,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.comk)','2025-01-01 16:47:28'),(24,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.come)','2025-01-01 16:49:57'),(25,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.comk)','2025-01-01 16:51:47'),(26,2,'Menghapus teknisi: Fauzannn (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:51:52'),(27,2,'Menghapus teknisi: fauzanaaa (fauzanalazhar9@gmail.comds)','2025-01-01 16:51:57'),(28,2,'Menghapus teknisi: fauzanaaa (fauzanalazhar9@gmail.comds)','2025-01-01 16:52:01'),(29,2,'Menghapus teknisi: sayaaaa (fauzanalazhar9@gmail.comfsdfs)','2025-01-01 16:52:05'),(30,2,'Menghapus teknisi: sayaaaa (fauzanalazhar9@gmail.comfsdfs)','2025-01-01 16:52:09'),(31,2,'Menghapus teknisi: sayaaaa (fauzanalazhar9@gmail.comfsdfs)','2025-01-01 16:52:13'),(32,2,'Menambahkan teknisi: kami (fauzanalazhar9@gmail.comaaas)','2025-01-01 16:53:22'),(33,2,'Menambahkan teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:54:57'),(34,2,'Menambahkan teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:54:59'),(35,2,'Menambahkan teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:55:00'),(36,2,'Menambahkan teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:55:00'),(37,2,'Menambahkan teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 16:55:00'),(38,2,'Menambahkan teknisi: fauzan (fauzanalazhar9@gmail.come)','2025-01-01 16:55:37'),(39,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:56'),(40,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:58'),(41,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:58'),(42,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(43,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(44,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(45,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(46,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(47,2,'Menambahkan teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 16:56:59'),(48,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:34'),(49,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:35'),(50,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:35'),(51,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(52,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(53,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(54,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(55,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(56,2,'Menambahkan teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 16:57:36'),(57,2,'Menambahkan teknisi: sayaar (fauzanalazhar9@gmail.comek)','2025-01-01 16:58:56'),(58,2,'Menambahkan teknisi: fauzangdfgd (fauzanalazhar9@gmail.comekk)','2025-01-01 17:02:07'),(59,2,'Menambahkan teknisi: fauzangdfgd (fauzanalazhar9@gmail.comekk)','2025-01-01 17:02:14'),(60,2,'Menghapus teknisi: fauzangdfgd (fauzanalazhar9@gmail.comekk)','2025-01-01 17:02:45'),(61,2,'Menghapus teknisi: fauzangdfgd (fauzanalazhar9@gmail.comekk)','2025-01-01 17:02:49'),(62,2,'Menghapus teknisi: sayaar (fauzanalazhar9@gmail.comek)','2025-01-01 17:02:52'),(63,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:02:54'),(64,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:02:55'),(65,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:02:57'),(66,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:02:58'),(67,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:02:59'),(68,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:03:00'),(69,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:03:01'),(70,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:03:02'),(71,2,'Menghapus teknisi: sfsdfsd (fauzanalazhar9@gmail.comsdf)','2025-01-01 17:03:03'),(72,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:04'),(73,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:06'),(74,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:07'),(75,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:07'),(76,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:08'),(77,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:09'),(78,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:12'),(79,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:13'),(80,2,'Menghapus teknisi: Fauzann (fauzanalazhar9@gmail.com)','2025-01-01 17:03:14'),(81,2,'Menghapus teknisi: fauzan (fauzanalazhar9@gmail.come)','2025-01-01 17:03:15'),(82,2,'Menghapus teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 17:03:16'),(83,2,'Menghapus teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 17:03:17'),(84,2,'Menghapus teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 17:03:18'),(85,2,'Menghapus teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 17:03:19'),(86,2,'Menghapus teknisi: kami22 (fauzanalazhar9@gmail.comaaa)','2025-01-01 17:03:20'),(87,2,'Menghapus teknisi: kami (fauzanalazhar9@gmail.comaaas)','2025-01-01 17:03:20'),(88,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.come)','2025-01-01 17:03:21'),(89,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-01 17:05:58'),(90,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-01 17:06:17'),(91,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-01 17:14:52'),(92,2,'Menambahkan teknisi: fauzanqw (fauzanalazhar9@gmail.comaaaeew)','2025-01-01 17:21:38'),(93,2,'Menghapus teknisi: fauzanqw (fauzanalazhar9@gmail.comaaaeew)','2025-01-05 15:35:00'),(94,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-05 15:35:05'),(95,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-05 15:35:09'),(96,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.com)','2025-01-05 15:35:13'),(97,2,'Menambahkan teknisi: fauzan (fauzanalazhar9@gmail.comaaa)','2025-01-05 17:12:27'),(98,2,'Menghapus teknisi: fauzan (fauzanalazhar9@gmail.comaaa)','2025-01-05 17:12:42'),(99,2,'Menghapus admin: Nama Admin','2025-01-05 17:15:08'),(100,2,'Mengedit layanan: Service Berkala (ID: 1)','2025-01-10 14:31:43'),(101,2,'Mengedit layanan: Service Berkala (ID: 1)','2025-01-10 14:32:10'),(102,2,'Menambah layanan: cuci kaca','2025-01-10 14:38:22'),(103,2,'Mengedit layanan: Cuci kaca Mobil (ID: 143)','2025-01-10 14:39:25'),(104,2,'Menambah layanan: Cuci Interior Mobil','2025-01-10 14:41:06'),(105,2,'Menambah layanan: Cuci Eksterior Mobil','2025-01-10 14:41:57'),(106,2,'Menambah layanan: Cuci Detail (Interior & Eksterior)','2025-01-10 14:43:27'),(107,2,'Menambah layanan: Cuci Bike Bawah','2025-01-10 14:44:40'),(108,2,'Menambah layanan: Cuci Eksterior Motor','2025-01-10 14:46:23'),(109,2,'Menambah layanan: Cuci Interior Motor','2025-01-10 14:47:19'),(110,2,'Menambah layanan: Cuci Detail (Interior & Eksterior)','2025-01-10 14:48:26'),(111,2,'Mengedit layanan: Cuci Interior Motor (ID: 149)','2025-01-10 14:48:57'),(112,2,'Mengedit layanan: Cuci Eksterior Motor (ID: 148)','2025-01-10 14:49:15'),(113,2,'Menghapus teknisi: sfsds (mobil5@example.com)','2025-01-14 09:33:41'),(114,2,'Menambahkan teknisi: ntahlah (mobil5@example.com)','2025-01-14 09:34:03'),(115,2,'Menambahkan teknisi: saya (fauzanalazhar9@gmail.comsas)','2025-01-14 09:34:58'),(116,2,'Menghapus teknisi: saya (fauzanalazhar9@gmail.comsas)','2025-01-14 09:35:05'),(117,2,'Menambahkan teknisi: fauzan (fauzanalazhar9@gmail.com)','2025-01-14 09:35:30'),(118,2,'Menghapus teknisi: fauzan (fauzanalazhar9@gmail.com)','2025-01-14 09:35:41'),(119,2,'Menghapus teknisi: ntahlah (mobil5@example.com)','2025-01-14 09:35:45'),(120,2,'Menambahkan teknisi: taktaw (mobil5@example.com)','2025-01-14 09:36:10'),(121,1,'Menambahkan admin: fauzan','2025-01-18 17:57:23'),(122,1,'Mengedit admin: fauzan (ID: 5)','2025-01-18 17:59:42'),(123,2,'Menghapus admin: saya','2025-01-18 18:01:55'),(124,2,'Mengedit admin: admin aja (ID: 1)','2025-01-18 18:02:13'),(125,2,'Mengedit admin: admin aja (ID: 1)','2025-01-18 18:02:27'),(126,2,'Menambahkan admin: fauzan','2025-01-18 18:02:39'),(127,2,'Menghapus admin: Fauzannn','2025-01-18 18:02:48'),(128,2,'Mengedit layanan: Service Berkala (ID: 1)','2025-01-18 18:04:10'),(129,2,'Mengedit layanan: Service Berkala (ID: 1)','2025-01-18 18:04:33'),(130,2,'Menambah layanan: testing','2025-01-18 18:04:57'),(131,2,'Menghapus layanan: testing (Kategori: Mobil)','2025-01-18 18:05:22');
/*!40000 ALTER TABLE `admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_wallets`
--

DROP TABLE IF EXISTS `e_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `e_wallets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_wallet` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_wallet` (`nama_wallet`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_wallets`
--

LOCK TABLES `e_wallets` WRITE;
/*!40000 ALTER TABLE `e_wallets` DISABLE KEYS */;
INSERT INTO `e_wallets` VALUES (3,'DANA'),(1,'GoPay'),(5,'LinkAja'),(2,'OVO'),(4,'ShopeePay');
/*!40000 ALTER TABLE `e_wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id_feedback` int NOT NULL AUTO_INCREMENT,
  `rating` tinyint(1) NOT NULL,
  `komentar` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `tanggal_feedback` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_feedback`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,3,'pko','2025-01-01 00:46:35'),(2,3,'f','2025-01-01 00:48:02'),(3,2,'esg','2025-01-01 00:53:32'),(4,3,'fssdf','2025-01-05 14:44:51'),(5,5,'bagus sekali','2025-01-05 23:18:40'),(6,5,'utuutuy','2025-01-06 21:46:18'),(7,3,'mnjhkj','2025-01-14 09:17:35'),(8,5,'','2025-01-18 17:42:34');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_booking`
--

DROP TABLE IF EXISTS `history_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_booking` (
  `id_history_booking` int NOT NULL AUTO_INCREMENT,
  `id_teknisi` int NOT NULL,
  `id_layanan` int NOT NULL,
  `id_pelanggan` int NOT NULL,
  `alamat` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `no_hp` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tanggal_booking` date NOT NULL,
  `pukul` time NOT NULL,
  `tanggal_konfirmasi` datetime DEFAULT NULL,
  `status_pembayaran` enum('Belum Dibayar','Sudah Dibayar') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Belum Dibayar',
  `konfirmasi_teknisi` enum('Belum Dikonfirmasi','Dikonfirmasi','Ditolak') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Belum Dikonfirmasi',
  PRIMARY KEY (`id_history_booking`),
  KEY `id_teknisi` (`id_teknisi`),
  KEY `id_layanan` (`id_layanan`),
  KEY `id_pelanggan` (`id_pelanggan`),
  CONSTRAINT `history_booking_ibfk_1` FOREIGN KEY (`id_teknisi`) REFERENCES `teknisi` (`id_teknisi`) ON DELETE CASCADE,
  CONSTRAINT `history_booking_ibfk_2` FOREIGN KEY (`id_layanan`) REFERENCES `layanan` (`id_layanan`) ON DELETE CASCADE,
  CONSTRAINT `history_booking_ibfk_3` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_booking`
--

LOCK TABLES `history_booking` WRITE;
/*!40000 ALTER TABLE `history_booking` DISABLE KEYS */;
INSERT INTO `history_booking` VALUES (29,1,145,1,'kebongedang8kirconnnn','083879045071','2025-01-21','19:00:00','2025-01-18 10:48:37','Sudah Dibayar','Dikonfirmasi'),(30,1,97,1,'di rumah saya','083879045071','2025-01-21','18:50:00','2025-01-18 10:49:30','Belum Dibayar','Dikonfirmasi'),(31,1,14,1,'kebongedang8kirconnnn','083879045071','2025-02-01','19:51:00','2025-01-18 10:51:15','Belum Dibayar','Belum Dikonfirmasi');
/*!40000 ALTER TABLE `history_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_pelanggan`
--

DROP TABLE IF EXISTS `history_pelanggan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_pelanggan` (
  `id_history` int NOT NULL AUTO_INCREMENT,
  `id_transaksi` int NOT NULL,
  `id_pelanggan` int NOT NULL,
  `id_teknisi` int NOT NULL,
  `id_layanan` int NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `tanggal_konfirmasi` datetime NOT NULL,
  `status_pembayaran` enum('Sudah Dibayar','Belum Dibayar') NOT NULL DEFAULT 'Belum Dibayar',
  `harga` decimal(10,2) NOT NULL,
  `konfirmasi_teknisi` enum('Dikonfirmasi','Belum Dikonfirmasi') DEFAULT 'Belum Dikonfirmasi',
  PRIMARY KEY (`id_history`),
  KEY `id_transaksi` (`id_transaksi`),
  KEY `id_pelanggan` (`id_pelanggan`),
  KEY `id_teknisi` (`id_teknisi`),
  KEY `id_layanan` (`id_layanan`),
  CONSTRAINT `history_pelanggan_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`),
  CONSTRAINT `history_pelanggan_ibfk_2` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  CONSTRAINT `history_pelanggan_ibfk_3` FOREIGN KEY (`id_teknisi`) REFERENCES `teknisi` (`id_teknisi`),
  CONSTRAINT `history_pelanggan_ibfk_4` FOREIGN KEY (`id_layanan`) REFERENCES `layanan` (`id_layanan`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_pelanggan`
--

LOCK TABLES `history_pelanggan` WRITE;
/*!40000 ALTER TABLE `history_pelanggan` DISABLE KEYS */;
INSERT INTO `history_pelanggan` VALUES (117,124,1,1,1,'kebongedang8kirconnnn','083879045071','2025-01-18 10:46:41','Sudah Dibayar',55000.00,'Dikonfirmasi'),(118,125,1,1,9,'dimana ya','083879045071','2025-01-18 10:47:17','Belum Dibayar',60000.00,'Dikonfirmasi'),(119,126,1,1,2,'disana aja','083879045071','2025-01-18 10:47:43','Belum Dibayar',150000.00,'Belum Dikonfirmasi');
/*!40000 ALTER TABLE `history_pelanggan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layanan`
--

DROP TABLE IF EXISTS `layanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layanan` (
  `id_layanan` int NOT NULL AUTO_INCREMENT,
  `kategori` enum('Mobil','Motor') COLLATE utf8mb4_general_ci NOT NULL,
  `menu_layanan` enum('Perawatan','Perbaikan','Inspeksi','Kustom','Darurat','Diagnostik','Suku Cadang','Cuci') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nama_layanan` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `deskripsi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `harga` int DEFAULT NULL,
  PRIMARY KEY (`id_layanan`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layanan`
--

LOCK TABLES `layanan` WRITE;
/*!40000 ALTER TABLE `layanan` DISABLE KEYS */;
INSERT INTO `layanan` VALUES (1,'Mobil','Perawatan','Service Berkala','Layanan perawatan berkala untuk mobil Anda.',55000),(2,'Mobil','Perawatan','Perawatan Mesin','Perawatan dan pengecekan mesin mobil Anda untuk memastikan kinerjanya optimal.',150000),(3,'Mobil','Perawatan','Perawatan AC','Perawatan sistem AC mobil untuk kenyamanan berkendara.',75000),(4,'Mobil','Perawatan','Perawatan Kaki-Kaki','Pemeriksaan dan perawatan sistem kaki-kaki mobil Anda.',20000),(5,'Mobil','Perawatan','Perawatan sistem Kelistrikan','Pemeriksaan dan perbaikan sistem kelistrikan mobil Anda.',50000),(6,'Mobil','Perawatan','Perawatan Rem','Pengecekan dan perawatan sistem rem mobil Anda.',85000),(7,'Mobil','Perawatan','Perawatan Cairan Mobil','Pengecekan dan penggantian cairan mobil seperti oli, radiator, dll.',70000),(8,'Mobil','Perawatan','Perawatan Ban','Pemeriksaan dan penggantian ban mobil Anda.',90000),(9,'Mobil','Perawatan','Eksterior dan Interior','Pembersihan dan perawatan eksterior serta interior mobil Anda.',60000),(10,'Mobil','Perawatan','Mobil Listrik/Hybrid','Perawatan untuk mobil listrik dan hybrid.',80000),(12,'Mobil','Perbaikan','Perbaikan Mesin Mobil','Perbaikan dan penggantian komponen mesin mobil Anda.',400000),(13,'Mobil','Perbaikan','Perbaikan AC','Perbaikan dan penggantian komponen AC mobil Anda.',120000),(14,'Mobil','Perbaikan','Perbaikan Kaki-Kaki','Perbaikan atau penggantian sistem kaki-kaki mobil Anda.',150000),(15,'Mobil','Perbaikan','Perbaikan Sistem Kelistrikan','Perbaikan pada sistem kelistrikan mobil Anda.',180000),(16,'Mobil','Perbaikan','Perbaikan Rem Mobil','Perbaikan atau penggantian sistem rem mobil Anda.',250000),(17,'Mobil','Perbaikan','Perbaikan Ban Mobil','Perbaikan atau penggantian ban mobil, termasuk pompaan dan ganti.',100000),(18,'Mobil','Perbaikan','Suspensi','Perbaikan dan penggantian sistem suspensi mobil Anda.',110000),(19,'Mobil','Perbaikan','Transmisi','Perbaikan atau penggantian komponen transmisi mobil Anda.',95000),(20,'Mobil','Perbaikan','Sistem Pembuangan','Perbaikan dan penggantian sistem pembuangan mobil Anda.',105000),(21,'Mobil','Perbaikan','Sistem Pendingin','Perbaikan atau penggantian sistem pendingin mobil Anda.',500000),(22,'Motor','Perawatan','Ganti Oli','Mengganti oli mesin secara berkala untuk menjaga performa dan umur mesin motor.',50000),(23,'Motor','Perawatan','Servis Rutin','Melakukan pemeriksaan dan perawatan rutin untuk memastikan semua komponen motor berfungsi optimal.',50000),(24,'Motor','Perawatan','Tune Up','Penyesuaian dan penyetelan mesin untuk meningkatkan efisiensi dan kinerja motor.',800000),(25,'Motor','Perawatan','Balancing Roda','Menyeimbangkan roda motor untuk mengurangi getaran dan meningkatkan kenyamanan berkendara.',400000),(26,'Motor','Perawatan','Ganti Aki','Penggantian aki motor yang sudah lemah atau tidak berfungsi untuk memastikan motor dapat dihidupkan dengan baik.',100000),(27,'Motor','Perawatan','Perawatan Rem','Merawat sistem pengereman untuk memastikan keamanan saat berkendara.',20000),(28,'Motor','Perawatan','Penggantian Ban','Mengganti ban motor yang sudah aus atau rusak untuk menjaga kestabilan dan keamanan.',700000),(29,'Motor','Perawatan','Pembersihan Karburator','Membersihkan karburator untuk memastikan campuran bahan bakar dan udara yang optimal.',300000),(30,'Motor','Perawatan','Sistem Kelistrikan','Memperbaiki komponen kelistrikan motor seperti lampu, starter, dan sistem pengapian.',350000),(31,'Motor','Perawatan','Overhaul Mesin','Pembongkaran dan perbaikan menyeluruh mesin motor untuk mengembalikan performa optimal.',250000),(32,'Motor','Perbaikan','Mesin','Perbaikan mesin untuk mengatasi masalah seperti overheat, suara kasar, atau performa menurun.',400000),(33,'Motor','Perbaikan','Rem','Pemeriksaan dan perbaikan sistem pengereman untuk memastikan keamanan maksimal.',800000),(34,'Motor','Perbaikan','Suspensi','Memperbaiki suspensi untuk meningkatkan kenyamanan dan stabilitas berkendara.',300000),(35,'Motor','Perbaikan','Sistem Kelistrikan','Perbaikan pada sistem kelistrikan seperti kabel, lampu, dan pengapian motor.',500000),(36,'Motor','Perbaikan','Karburator','Perbaikan karburator untuk mengembalikan efisiensi bahan bakar dan performa mesin.',600000),(37,'Motor','Perbaikan','Radiator','Memperbaiki radiator untuk mencegah mesin overheat.',200000),(38,'Motor','Perbaikan','Starter','Memperbaiki atau mengganti starter motor yang bermasalah.',700000),(39,'Motor','Perbaikan','Kopling','Pemeriksaan dan perbaikan kopling untuk menjaga perpindahan gigi yang halus.',450000),(40,'Motor','Perbaikan','Transmisi','Perbaikan transmisi untuk mengatasi masalah perpindahan gigi atau suara tidak normal.',650000),(41,'Motor','Perbaikan','Sistem Pengapian Motor','Memperbaiki sistem pengapian untuk memastikan motor dapat dinyalakan dengan lancar.',400000),(42,'Motor','Inspeksi','Inspeksi Mesin Motor','Pemeriksaan menyeluruh pada mesin motor untuk memastikan kinerja optimal.',300000),(43,'Motor','Inspeksi','Inspeksi Sistem Pengapian','Pemeriksaan sistem pengapian motor untuk mencegah masalah di jalan.',800000),(44,'Motor','Inspeksi','Inspeksi Rangka Motor','Memeriksa kondisi rangka motor untuk memastikan tidak ada kerusakan atau keausan.',100000),(45,'Motor','Inspeksi','Inspeksi Sistem Pengereman Motor','Pemeriksaan sistem pengereman untuk memastikan keselamatan berkendara.',900000),(46,'Motor','Inspeksi','Inspeksi Kelistrikan Motor','Memeriksa sistem kelistrikan motor untuk memastikan fungsionalitasnya.',700000),(47,'Motor','Inspeksi','Inspeksi Oli Motor','Memeriksa tingkat dan kondisi oli mesin motor untuk mencegah kerusakan.',550000),(48,'Motor','Inspeksi','Inspeksi Sistem Suspensi Motor','Pemeriksaan kondisi suspensi motor untuk kenyamanan berkendara.',650000),(49,'Motor','Inspeksi','Inspeksi Rantai Motor','Memeriksa kondisi rantai motor untuk mencegah keausan berlebihan.',250000),(50,'Motor','Inspeksi','Inspeksi Lampu dan Sinyal Motor','Memeriksa lampu depan, belakang, dan sinyal untuk memastikan visibilitas di jalan.',500000),(51,'Motor','Inspeksi','Inspeksi Ban Motor','Memeriksa kondisi ban motor untuk memastikan keamanan dan kenyamanan berkendara.',20000),(52,'Motor','Suku Cadang','Ganti Rantai Motor','Penggantian rantai motor untuk kinerja optimal.',850000),(53,'Motor','Suku Cadang','Ganti Oli Motor','Penggantian oli motor untuk menjaga kinerja mesin.',950000),(54,'Motor','Suku Cadang','Ganti Ban Motor','Penggantian ban motor untuk kenyamanan dan keamanan berkendara.',500000),(55,'Motor','Suku Cadang','Ganti Kampas Rem','Penggantian kampas rem motor untuk memastikan sistem pengereman berfungsi dengan baik.',200000),(56,'Motor','Suku Cadang','Ganti Aki Motor','Penggantian aki motor untuk memastikan sistem kelistrikan berjalan dengan baik.',400000),(57,'Motor','Suku Cadang','Ganti Busi Motor','Penggantian busi motor untuk memastikan pengapian yang baik.',850000),(58,'Motor','Suku Cadang','Ganti Filter Udara','Penggantian filter udara untuk memastikan pembakaran mesin yang efisien.',950000),(59,'Motor','Suku Cadang','Ganti Pelek Motor','Penggantian pelek motor untuk menjaga keseimbangan dan keamanan.',500000),(60,'Motor','Suku Cadang','Ganti Sistem Pengereman','Penggantian sistem pengereman untuk meningkatkan keselamatan berkendara.',700000),(61,'Motor','Suku Cadang','Ganti Lampu Motor','Penggantian lampu motor untuk meningkatkan visibilitas di jalan.',650000),(62,'Motor','Kustom','Modifikasi Mesin Motor','Modifikasi mesin motor untuk meningkatkan performa.',300000),(63,'Motor','Kustom','Modifikasi Rangka Motor','Modifikasi rangka motor untuk penampilan dan kenyamanan lebih.',900000),(64,'Motor','Kustom','Modifikasi Warna Motor','Pemilihan warna motor sesuai keinginan untuk penampilan personal.',500000),(65,'Motor','Kustom','Modifikasi Lampu Motor','Penambahan lampu custom untuk penampilan dan visibilitas lebih baik.',800000),(66,'Motor','Kustom','Modifikasi Jok Motor','Penyesuaian jok motor untuk kenyamanan dan gaya.',600000),(67,'Motor','Kustom','Modifikasi Ban Motor','Mengubah ukuran atau tipe ban motor sesuai kebutuhan.',550000),(68,'Motor','Kustom','Modifikasi Pelek Motor','Mengganti pelek motor untuk tampilan yang lebih sporty.',750000),(69,'Motor','Kustom','Modifikasi Sistem Pengereman','Modifikasi sistem pengereman motor untuk meningkatkan performa.',450000),(70,'Motor','Kustom','Modifikasi Knalpot Motor','Modifikasi knalpot motor untuk suara dan penampilan yang lebih menarik.',400000),(71,'Motor','Kustom','Modifikasi Sistem Pengapian','Modifikasi sistem pengapian motor untuk efisiensi bahan bakar lebih baik.',600000),(72,'Motor','Darurat','Perbaikan Darurat Mesin Motor','Perbaikan mesin motor secara darurat di tempat kejadian.',950000),(73,'Motor','Darurat','Perbaikan Darurat Rangka Motor','Perbaikan rangka motor secara darurat di lokasi.',500000),(74,'Motor','Darurat','Perbaikan Darurat Sistem Pengereman','Perbaikan sistem pengereman motor di tempat kejadian.',400000),(75,'Motor','Darurat','Perbaikan Darurat Kelistrikan Motor','Perbaikan sistem kelistrikan motor yang rusak di lokasi.',750000),(76,'Motor','Darurat','Perbaikan Darurat Oli Motor','Pengisian ulang atau penggantian oli motor di lokasi darurat.',500000),(77,'Motor','Darurat','Perbaikan Darurat Ban Motor','Penggantian atau perbaikan ban motor di tempat kejadian.',500000),(78,'Motor','Darurat','Perbaikan Darurat Lampu Motor','Perbaikan lampu motor yang rusak di lokasi.',850000),(79,'Motor','Darurat','Perbaikan Darurat Busi Motor','Penggantian busi motor yang rusak di lokasi darurat.',600000),(80,'Motor','Darurat','Perbaikan Darurat Sistem Pengapian','Perbaikan sistem pengapian motor di tempat kejadian.',800000),(81,'Motor','Darurat','Perbaikan Darurat Sistem Suspensi','Perbaikan sistem suspensi motor yang rusak di lokasi.',600000),(82,'Motor','Diagnostik','Diagnostik Mesin Motor','Diagnostik untuk mendeteksi masalah pada mesin motor.',600000),(83,'Motor','Diagnostik','Diagnostik Sistem Pengapian','Mendeteksi masalah pada sistem pengapian motor.',750000),(84,'Motor','Diagnostik','Diagnostik Sistem Pengereman','Mendeteksi masalah pada sistem pengereman motor.',300000),(85,'Motor','Diagnostik','Diagnostik Kelistrikan Motor','Mendeteksi masalah kelistrikan pada motor.',450000),(86,'Motor','Diagnostik','Diagnostik Rangka Motor','Mendeteksi masalah pada rangka motor.',500000),(87,'Motor','Diagnostik','Diagnostik Oli Motor','Mendeteksi masalah pada sistem pelumasan mesin motor.',600000),(88,'Motor','Diagnostik','Diagnostik Ban Motor','Mendeteksi masalah pada kondisi ban motor.',450000),(89,'Motor','Diagnostik','Diagnostik Lampu Motor','Mendeteksi masalah pada lampu motor.',700000),(90,'Motor','Diagnostik','Diagnostik Busi Motor','Mendeteksi masalah pada busi motor.',300000),(91,'Motor','Diagnostik','Diagnostik Sistem Suspensi','Mendeteksi masalah pada sistem suspensi motor.',550000),(92,'Mobil','Inspeksi','Inspeksi Mesin Mobil','Pemeriksaan menyeluruh pada mesin mobil untuk memastikan kinerja optimal.',800000),(93,'Mobil','Inspeksi','Inspeksi Sistem Pengapian Mobil','Pemeriksaan sistem pengapian mobil untuk mencegah masalah di jalan.',950000),(94,'Mobil','Inspeksi','Inspeksi Rangka Mobil','Memeriksa kondisi rangka mobil untuk memastikan tidak ada kerusakan atau keausan.',400000),(95,'Mobil','Inspeksi','Inspeksi Sistem Pengereman Mobil','Pemeriksaan sistem pengereman untuk memastikan keselamatan berkendara.',700000),(96,'Mobil','Inspeksi','Inspeksi Kelistrikan Mobil','Memeriksa sistem kelistrikan mobil untuk memastikan fungsionalitasnya.',300000),(97,'Mobil','Inspeksi','Inspeksi Oli Mobil','Memeriksa tingkat dan kondisi oli mesin mobil untuk mencegah kerusakan.',300000),(98,'Mobil','Inspeksi','Inspeksi Sistem Suspensi','Pemeriksaan kondisi suspensi mobil untuk kenyamanan berkendara.',750000),(99,'Mobil','Inspeksi','Inspeksi Rantai Mobil','Memeriksa kondisi rantai mobil untuk mencegah keausan berlebihan.',650000),(100,'Mobil','Inspeksi','Inspeksi Lampu dan Sinyal','Memeriksa lampu depan, belakang, dan sinyal untuk memastikan visibilitas di jalan.',450000),(101,'Mobil','Inspeksi','Inspeksi Ban Mobil','Memeriksa kondisi ban mobil untuk memastikan keamanan dan kenyamanan berkendara.',500000),(102,'Mobil','Suku Cadang','Ganti Rantai Mobil','Penggantian rantai mobil untuk kinerja optimal.',400000),(103,'Mobil','Suku Cadang','Ganti Oli Mobil','Penggantian oli mobil untuk menjaga kinerja mesin.',700000),(104,'Mobil','Suku Cadang','Ganti Ban Mobil','Penggantian ban mobil untuk kenyamanan dan keamanan berkendara.',350000),(105,'Mobil','Suku Cadang','Ganti Kampas Rem Mobil','Penggantian kampas rem mobil untuk memastikan sistem pengereman berfungsi dengan baik.',600000),(106,'Mobil','Suku Cadang','Ganti Aki Mobil','Penggantian aki mobil untuk memastikan sistem kelistrikan berjalan dengan baik.',800000),(107,'Mobil','Suku Cadang','Ganti Busi Mobil','Penggantian busi mobil untuk memastikan pengapian yang baik.',450000),(108,'Mobil','Suku Cadang','Ganti Filter Udara Mobil','Penggantian filter udara untuk memastikan pembakaran mesin yang efisien.',750000),(109,'Mobil','Suku Cadang','Ganti Pelek Mobil','Penggantian pelek mobil untuk menjaga keseimbangan dan keamanan.',300000),(110,'Mobil','Suku Cadang','Ganti Sistem Pengereman','Penggantian sistem pengereman untuk meningkatkan keselamatan berkendara.',650000),(111,'Mobil','Suku Cadang','Ganti Lampu Mobil','Penggantian lampu mobil untuk meningkatkan visibilitas di jalan.',400000),(112,'Mobil','Kustom','Modifikasi Mesin Mobil','Modifikasi mesin mobil untuk meningkatkan performa.',900000),(113,'Mobil','Kustom','Modifikasi Rangka Mobil','Modifikasi rangka mobil untuk penampilan dan kenyamanan lebih.',250000),(114,'Mobil','Kustom','Modifikasi Warna Mobil','Pemilihan warna mobil sesuai keinginan untuk penampilan personal.',700000),(115,'Mobil','Kustom','Modifikasi Lampu Mobil','Penambahan lampu custom untuk penampilan dan visibilitas lebih baik.',300000),(116,'Mobil','Kustom','Modifikasi Jok Mobil','Penyesuaian jok mobil untuk kenyamanan dan gaya.',850000),(117,'Mobil','Kustom','Modifikasi Ban Mobil','Mengubah ukuran atau tipe ban mobil sesuai kebutuhan.',500000),(118,'Mobil','Kustom','Modifikasi Pelek Mobil','Mengganti pelek mobil untuk tampilan yang lebih sporty.',200000),(119,'Mobil','Kustom','Modifikasi Sistem Pengereman','Modifikasi sistem pengereman mobil untuk meningkatkan performa.',750000),(120,'Mobil','Kustom','Modifikasi Knalpot Mobil','Modifikasi knalpot mobil untuk suara dan penampilan yang lebih menarik.',350000),(121,'Mobil','Kustom','Modifikasi Sistem Pengapian','Modifikasi sistem pengapian mobil untuk efisiensi bahan bakar lebih baik.',950000),(122,'Mobil','Darurat','Perbaikan Darurat Mesin Mobil','Perbaikan mesin mobil secara darurat di tempat kejadian.',400000),(123,'Mobil','Darurat','Perbaikan Darurat Rangka Mobil','Perbaikan rangka mobil secara darurat di lokasi.',800000),(124,'Mobil','Darurat','Perbaikan Darurat Sistem Pengereman','Perbaikan sistem pengereman mobil di tempat kejadian.',600000),(125,'Mobil','Darurat','Perbaikan Darurat Kelistrikan Mobil','Perbaikan sistem kelistrikan mobil yang rusak di lokasi.',300000),(126,'Mobil','Darurat','Perbaikan Darurat Oli Mobil','Pengisian ulang atau penggantian oli mobil di lokasi darurat.',1000000),(127,'Mobil','Darurat','Perbaikan Darurat Ban Mobil','Penggantian atau perbaikan ban mobil di tempat kejadian.',550000),(128,'Mobil','Darurat','Perbaikan Darurat Lampu Mobil','Perbaikan lampu mobil yang rusak di lokasi.',200000),(129,'Mobil','Darurat','Perbaikan Darurat Busi Mobil','Penggantian busi mobil yang rusak di lokasi darurat.',650000),(130,'Mobil','Darurat','Perbaikan Darurat Sistem Pengapian','Perbaikan sistem pengapian mobil di tempat kejadian.',750000),(131,'Mobil','Darurat','Perbaikan Darurat Sistem Suspensi','Perbaikan sistem suspensi mobil yang rusak di lokasi.',450000),(132,'Mobil','Diagnostik','Diagnostik Mesin Mobil','Diagnostik untuk mendeteksi masalah pada mesin mobil.',900000),(133,'Mobil','Diagnostik','Diagnostik Sistem Pengapian Mobil','Mendeteksi masalah pada sistem pengapian mobil.',700000),(134,'Mobil','Diagnostik','Diagnostik Sistem Pengereman Mobil','Mendeteksi masalah pada sistem pengereman mobil.',350000),(135,'Mobil','Diagnostik','Diagnostik Kelistrikan Mobil','Mendeteksi masalah kelistrikan pada mobil.',800000),(136,'Mobil','Diagnostik','Diagnostik Rangka Mobil','Mendeteksi masalah pada rangka mobil.',600000),(137,'Mobil','Diagnostik','Diagnostik Oli Mobil','Mendeteksi masalah pada sistem pelumasan mesin mobil.',250000),(138,'Mobil','Diagnostik','Diagnostik Ban Mobil','Mendeteksi masalah pada kondisi ban mobil.',700000),(139,'Mobil','Diagnostik','Diagnostik Lampu Mobil','Mendeteksi masalah pada lampu mobil.',400000),(140,'Mobil','Diagnostik','Diagnostik Busi Mobil','Mendeteksi masalah pada busi mobil.',850000),(141,'Mobil','Diagnostik','Diagnostik Sistem Suspensi Mobil','Mendeteksi masalah pada sistem suspensi mobil.',300000),(143,'Mobil','Cuci','Cuci kaca Mobil','bersihkan kaca mobil mu agar berkendara lebih nyaman',10000),(144,'Mobil','Cuci','Cuci Interior Mobil','Bersihkan interior mobil mu agar lebih nyaman saat berkendara',20000),(145,'Mobil','Cuci','Cuci Eksterior Mobil','Bersihkan eksterior mobil mu agar lebih nyaman saat berkendara',20000),(146,'Mobil','Cuci','Cuci Detail (Interior & Eksterior)','besihkan mobil mu agar kendaraan terlihat seperti baru lagi',35000),(147,'Mobil','Cuci','Cuci Bike Bawah','Bersihkan bike bawah kendaraan mu agar lebih bersih',15000),(148,'Motor','Cuci','Cuci Eksterior Motor','bersihkan kendaraan mu agar lebih nyaman saat di pakai',12000),(149,'Motor','Cuci','Cuci Interior Motor','bersihkan kendaraan mu agar lebih nyaman saat di pakai',12000),(150,'Motor','Cuci','Cuci Detail (Interior & Eksterior)','bersihkan kendaraan mu agar lebih nyaman saat di pakai',20000);
/*!40000 ALTER TABLE `layanan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelanggan`
--

DROP TABLE IF EXISTS `pelanggan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelanggan` (
  `id_pelanggan` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `no_hp` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_general_ci,
  `foto_profil` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_daftar` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pelanggan`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelanggan`
--

LOCK TABLES `pelanggan` WRITE;
/*!40000 ALTER TABLE `pelanggan` DISABLE KEYS */;
INSERT INTO `pelanggan` VALUES (1,'fauzannnn','fauzanalazhar9@gmail.com','$2y$10$KtnjmVpbSCfmrkrmGf71POC/H2kW4WHhu8DfUSxIShDVogaTdRGeW','083879045071','kebongedang8kirconnnn','untitled.png','2024-11-15 00:00:00'),(5,'','','$2y$10$Uz67pRNBt/aYHuqNhzJseeOF8ClApb1866whEsyVAwviNt6yW.N7O','','','untitled.png','2024-11-15 00:00:00'),(7,'saya','fauzanalazhar@gmail.com','$2y$10$o1ZDfptuyEUixAbUc5u29ubbi8rsFm7MJZ4mYqdK3IOAXXiJ3GJbW','083879045071','kebongedang8\nkircon','untitled.png','2024-11-18 00:00:00'),(8,'kami','fauzan@gmail.com','$2y$10$6UA/MtWTU2Rbv33mWVbEieJ2dqwTEODv0w8scu.LmYo/PVWdpKjY6','083879045071','kebongedang8\nkircon','untitled.png','2024-11-24 00:00:00'),(9,'kami','fauzanalazar9@gmail.com','$2y$10$3I8V4rUoXs812eNVS.AZfOId8vZKtvSXTzPSyTIlRfcJ.pvdNyEY2','083879045071','kebongedang8\nkircon','untitled.png','2024-11-30 00:00:00'),(10,'rasya','auzanalazhar9@gmail.com','$2y$10$qRR/YweZQ5iWJD.E4YMkYux7nmK0oGwanJS1lk2/Ja4IGAuPkns4y','083879045071','kebongedang8\nkircon',NULL,'2024-11-30 00:00:00'),(11,'saya saja','fauzanalazhar9@gmail.co','$2y$10$ghQEZAfpvEPkOegv.zLO8OBsoy/gM3IBRtJiy9e2wZ.PQ9OAs5Q1y','083879045071','kebongedang8\nkircon',NULL,'2024-11-30 00:00:00'),(12,'dasas','fauzanalazhar9@gmal.com','$2y$10$nwhZAM/.gzE1d/zoI7iTAOxOVHUaWLrlfnsBZ5CVjCf3tM6VW7Vau','083879045071','kebongedang8\nkircon',NULL,'2024-11-30 00:00:00'),(13,'fauzann','fauzanalazhar9@gmail.comn','$2y$10$RYej3llDDTbcpPYrTno6SODHUBOqNCcknoMdpTNGbKLSQRMKQXssG','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(14,'s','s@s','$2y$10$Ox.SUk9JXey6Iy2JgpF1Men4mEOw82tAiuVx39AQKOHkY1/e34GhG','1','s',NULL,'2024-12-01 00:00:00'),(15,'a','ajawibuwibu@gmail.com','$2y$10$d6YG8XMdgrrBMREo1XNbMOWfAMgy1LJfAazjLGlbDtaTn3pmNeY9W','2','a',NULL,'2024-12-01 00:00:00'),(16,'dapa','fauzanalazhar9@gmail.coma','$2y$10$BMFpzUOT1TR8w8GiKslTYO1kB4c6KKZZ/F93mwAKHpG2hHEIfungW','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(18,'c','ajawibuwibu@gmail.coms','$2y$10$pSVezV2erNlADatbxxIIfe50vBd2/bsDSNfX2CujfK71qckw67SXe','1','a',NULL,'2024-12-01 00:00:00'),(20,'dapa','fauzanalazhar9@gmail.comas','$2y$10$NEURgvbIO/euUA9Q7RsDIem7Fpw52sxvnBEnV5rfycvNUVK1lCYWm','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(22,'dapa','fauzanalazhar9@gmail.comasa','$2y$10$E2ZvrrAG9XOqBBFtxmDM9.qva3NeSTZXb3ktg6b7bv6NwH/Gp1m6e','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(23,'fauzan','fauzanalazhar9@gmail.comz','$2y$10$GMCR1IFNU9/CykXO4G9HHefehveszotnc8JdJxY7pQxHY.c9oRZYS','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(24,'z','fauzanalazhar9@gmail.comm','$2y$10$NXO.jA121pcOoYIOfctjSOojQMvvbvlP4qK/fbdn5MFzo1JyfgbRy','083879045071','kebongedang8\nkircon',NULL,'2024-12-01 00:00:00'),(25,'rasyas','fauzanalazhar9@gmail.comaaa','$2y$10$J6m1MxDrGLBLR02FpMtRleO6nmC.3UooLka1mfnwHHihsddebVDUW','083879045071','kebongedang8kircon',NULL,'2024-12-08 00:00:00'),(26,'saya sajas','fauzanalazhar9@gmail.comaaaa','$2y$10$UF7jQTuJyWCkYAf0atacqeU/I5d4O5LwrBMwAm6zXYIhetcIAqQpq','083879045071','kebongedang8\nkircon',NULL,'2024-12-08 00:00:00'),(27,'sss','fauzanalazhar9@gmail.come','$2y$10$4g2WKpK0jLanRcjDKfpU8e6kt48ttvladPOjh7MekaAROLbBrJVAG','083879045071','kebongedang8\nkircon',NULL,'2024-12-11 00:00:00'),(28,'jordi','jordi@.com','$2y$10$MisNE7G4ogd.RfWAXoGBEusUO.fbuMhdkr/6XkcjHN5gmpexT62MO','083879045071','kebongedang8\nkircon',NULL,'2024-12-12 00:00:00'),(29,'guq','fauzanalazhar9@gmail.comq','$2y$10$uIbwtUNi98oGA37hk6dH5ejuSNJ4/tqHdjxhwbvWO6xE5sxMRiiaa','083879045071','kebongedang8\nkircon',NULL,'2025-01-06 00:00:00');
/*!40000 ALTER TABLE `pelanggan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelanggan_per_bulan`
--

DROP TABLE IF EXISTS `pelanggan_per_bulan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelanggan_per_bulan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tahun` int NOT NULL,
  `bulan` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `jumlah_pelanggan` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelanggan_per_bulan`
--

LOCK TABLES `pelanggan_per_bulan` WRITE;
/*!40000 ALTER TABLE `pelanggan_per_bulan` DISABLE KEYS */;
INSERT INTO `pelanggan_per_bulan` VALUES (1,2024,'January',50),(2,2024,'February',45),(3,2024,'Maret',60),(4,2024,'april',80),(5,2024,'Mei',70),(6,2024,'Juni',65),(7,2024,'Juli',75),(8,2024,'Agustus',80),(9,2024,'September',90),(10,2024,'Oktober',85),(11,2024,'November',95),(12,2024,'Desember',100),(13,2025,'January',75),(14,2025,'February',1);
/*!40000 ALTER TABLE `pelanggan_per_bulan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teknisi`
--

DROP TABLE IF EXISTS `teknisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teknisi` (
  `id_teknisi` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kategori` enum('mobil','motor') COLLATE utf8mb4_general_ci NOT NULL,
  `spesialisasi` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pengalaman` text COLLATE utf8mb4_general_ci,
  `foto` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_general_ci,
  `no_hp` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_daftar` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('aktif','tidak aktif') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'tidak aktif',
  `e_wallet_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nomor_e_wallet` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id_teknisi`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teknisi`
--

LOCK TABLES `teknisi` WRITE;
/*!40000 ALTER TABLE `teknisi` DISABLE KEYS */;
INSERT INTO `teknisi` VALUES (1,'mobil1@example.com','fauzan','mobil','Perawatan,Perbaikan,Inspeksi,Kustom,Cuci','Pengalaman 5 tahun di perbaikan mobil','teknisi.png','Jalan Mobil No. 1, Jakarta','6283879045071','123','2024-12-10 08:01:52','aktif','2,3,5','{\"2\":\"13312312222\",\"3\":\"083879045071\",\"5\":\"43243\"}'),(2,'mobil2@example.com','gm chess','mobil','perbaikan,perawatan,darurat,diagnostik','pengalaman 5 dekade jadi ayam di bengkel tok dalang','1736000171_pp.jpg','di deket kuburan','082345678901','123','2024-12-10 08:01:52','aktif','1,2,3,4,5','{\"1\":\"083879045071\",\"2\":\"1331231\",\"3\":\"083879045071\",\"4\":\"4644567\",\"5\":\"43243\"}'),(3,'mobil3@example.com','hasbi bilah','mobil','Perawatan,Kustom,Darurat,Diagnostik','Pengalaman 7 tahun di modifikasi mobil','teknisi.png','Jalan Mobil No. 3, Surabaya','083456789012','123','2024-12-10 08:01:52','aktif','3,2,1','{\"3\":\"083879045071\",\"2\":\"1331231\",\"1\":\"083879045071\"}'),(4,'mobil4@example.com','dzikri melimpah','mobil','Perawatan,Perbaikan,Suku Cadang','Pengalaman 4 tahun dalam perbaikan darurat','teknisi.png','Jalan Mobil No. 4, Bali','084567890123','123','2024-12-10 08:01:52','aktif','4,3','{\"4\":\"4644567\",\"3\":\"083879045071\"}'),(5,'motor1@example.com','ahmat tahalu','motor','Inspeksi,Kustom,Darurat,Diagnostik,Suku Cadang','Pengalaman 6 tahun di perbaikan motor','teknisi.png','Jalan Motor No. 1, Jakarta','085678901234','123','2024-12-10 08:01:52','aktif','4,5','{\"4\":\"4644567\",\"5\":\"43243\"}'),(6,'motor2@example.com','lubu','motor','Perawatan,Inspeksi,Kustom,Diagnostik','Pengalaman 5 tahun di inspeksi motor','teknisi.png','Jalan Motor No. 2, Yogyakarta','086789012345','123','2024-12-10 08:01:52','aktif','1','{\"1\":\"083879045071\"}'),(7,'motor3@example.com','posaidon','motor','Perbaikan,Kustom,Diagnostik,Suku Cadang','Pengalaman 4 tahun di modifikasi motor','teknisi.png','Jalan Motor No. 3, Bandung','087890123456','123','2024-12-10 08:01:52','aktif','5,4','{\"5\":\"43243\",\"4\":\"3131312\"}'),(9,'motor4@example.com','jack the ripper','motor','Perawatan,Perbaikan,Kustom,Darurat','','teknisi.png','disana jauh','0838790450711','123','2024-12-28 10:23:16','tidak aktif','2,3','{\"2\":\"1331231\",\"3\":\"083879045071\"}'),(10,'motor5@example.com','hitler','motor','Perawatan,Perbaikan,Inspeksi,Kustom','','teknisi.png','kebongedang8\r\nkircon','083879045071','123','2024-12-28 11:21:34','tidak aktif','1,5','{\"1\":\"083879045071\",\"5\":\"43243\"}'),(57,'mobil5@example.com','kim jong un','mobil','Perawatan,Perbaikan,Inspeksi,Kustom','','teknisi.png','kebongedang8\r\nkircon','083879045071','123','2025-01-14 09:36:10','tidak aktif','4,3','{\"4\":\"4644567\",\"3\":\"083879045071\"}');
/*!40000 ALTER TABLE `teknisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi` (
  `id_transaksi` int NOT NULL AUTO_INCREMENT,
  `id_pelanggan` int DEFAULT NULL,
  `id_teknisi` int DEFAULT NULL,
  `id_layanan` int DEFAULT NULL,
  `tanggal_transaksi` datetime DEFAULT CURRENT_TIMESTAMP,
  `status_pembayaran` enum('Belum Dibayar','Sudah Dibayar') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `metode_pembayaran` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_pelanggan` (`id_pelanggan`),
  KEY `id_teknisi` (`id_teknisi`),
  KEY `id_layanan` (`id_layanan`),
  CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_teknisi`) REFERENCES `teknisi` (`id_teknisi`),
  CONSTRAINT `transaksi_ibfk_3` FOREIGN KEY (`id_layanan`) REFERENCES `layanan` (`id_layanan`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi`
--

LOCK TABLES `transaksi` WRITE;
/*!40000 ALTER TABLE `transaksi` DISABLE KEYS */;
INSERT INTO `transaksi` VALUES (124,1,1,1,'2025-01-18 10:46:41','Belum Dibayar','Cash'),(125,1,1,9,'2025-01-18 10:47:17','Belum Dibayar','Cash'),(126,1,1,2,'2025-01-18 10:47:43','Belum Dibayar','Cash');
/*!40000 ALTER TABLE `transaksi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-18 22:57:54
