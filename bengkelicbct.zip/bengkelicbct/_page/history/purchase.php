<?php
// Koneksi ke database
include('../../_config/koneksi/koneksi.php'); // File koneksi database
// Periksa apakah parameter id_history atau id_history_booking dikirimkan
$idHistory = $_GET['id_history'] ?? null;
$idHistoryBooking = $_GET['id_history_booking'] ?? null;

if ($idHistory) {
    // Query untuk history pelanggan
    $query = "
        SELECT 
            hp.id_history, 
            hp.id_transaksi, 
            hp.konfirmasi_teknisi, 
            hp.alamat AS alamat_pelanggan, 
            hp.no_hp AS no_hp_pelanggan, 
            hp.tanggal_konfirmasi AS konfirmasi_pelanggan, 
            hp.status_pembayaran AS status_pembayaran_pelanggan, 
            hp.harga, 
            t.nama AS nama_teknisi,
            p.nama AS nama_pelanggan,
            l.kategori,
            l.menu_layanan,
            l.nama_layanan
        FROM 
            history_pelanggan hp
            LEFT JOIN pelanggan p ON hp.id_pelanggan = p.id_pelanggan
            LEFT JOIN teknisi t ON hp.id_teknisi = t.id_teknisi
            LEFT JOIN layanan l ON hp.id_layanan = l.id_layanan
        WHERE hp.id_history = '$idHistory'
    ";
} elseif ($idHistoryBooking) {
    // Query untuk history booking
    $query = "
        SELECT 
            hb.id_history_booking, 
            hb.konfirmasi_teknisi, 
            hb.alamat AS alamat_booking, 
            hb.no_hp AS no_hp_booking, 
            hb.tanggal_booking, 
            hb.pukul, 
            hb.status_pembayaran AS status_pembayaran_booking, 
            t.nama AS nama_teknisi,
            p.nama AS nama_pelanggan,
            l.harga,
            l.kategori,
            l.menu_layanan,
            l.nama_layanan
        FROM 
            history_booking hb
            LEFT JOIN pelanggan p ON hb.id_pelanggan = p.id_pelanggan
            LEFT JOIN teknisi t ON hb.id_teknisi = t.id_teknisi
            LEFT JOIN layanan l ON hb.id_layanan = l.id_layanan
        WHERE hb.id_history_booking = '$idHistoryBooking'
    ";
}

$result = $koneksi->query($query);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    ?>
<?php
if ($idHistory) {
    // Detail untuk id_history (Service Langsung)
    ?>
    <div class="container">
    <div class="purchase-details">
        <h2>Service Langsung</h2>
        <p><strong>Nama Pelanggan:</strong> <?= $data['nama_pelanggan'] ?></p>
        <p><strong>Alamat:</strong> <?= $data['alamat_pelanggan'] ?></p>
        <p><strong>No HP:</strong> <?= $data['no_hp_pelanggan'] ?></p>
        <p><strong>Kategori:</strong> <?= $data['kategori'] ?></p>
        <p><strong>Menu Layanan:</strong> <?= $data['menu_layanan'] ?></p>
        <p><strong>Nama Layanan:</strong> <?= $data['nama_layanan'] ?></p>
        <p><strong>Harga:</strong> <?= $data['harga'] ?></p>
        <p><strong>Nama Teknisi:</strong> <?= $data['nama_teknisi'] ?></p>
        <p><strong>Status Pembayaran:</strong> <?= $data['status_pembayaran_pelanggan'] ?></p>
    </div>
    </div>
    <?php
} elseif ($idHistoryBooking) {
    // Detail untuk id_history_booking (Service Booking)
    ?>
    <div class="container">
    <div class="purchase-details">
        <h2>Service Booking</h2>
        <p><strong>Nama Pelanggan:</strong> <?= $data['nama_pelanggan'] ?></p>
        <p><strong>Alamat:</strong> <?= $data['alamat_booking'] ?></p>
        <p><strong>No HP:</strong> <?= $data['no_hp_booking'] ?></p>
        <p><strong>Kategori:</strong> <?= $data['kategori'] ?></p>
        <p><strong>Menu Layanan:</strong> <?= $data['menu_layanan'] ?></p>
        <p><strong>Nama Layanan:</strong> <?= $data['nama_layanan'] ?></p>
        <p><strong>Harga:</strong> <?= $data['harga'] ?></p>
        <p><strong>Nama Teknisi:</strong> <?= $data['nama_teknisi'] ?></p>
        <p><strong>Tanggal Booking:</strong> <?= $data['tanggal_booking'] ?></p>
        <p><strong>Pukul:</strong> <?= $data['pukul'] ?></p>
        <p><strong>Status Pembayaran:</strong> <?= $data['status_pembayaran_booking'] ?></p>
    </div>
    </div>
    <?php
}
?>

    <?php
} else {
    echo "<p>Data tidak ditemukan.</p>";
}

$koneksi->close();
?>