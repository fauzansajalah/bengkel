<?php
// Memulai sesi jika belum dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id'])) {
  // Jika belum login, tampilkan pesan
  echo "<p>Anda perlu login untuk melihat history.</p>";
  exit(); // Hentikan eksekusi skrip
}

// Ambil ID pelanggan dari sesi
$id_pelanggan = $_SESSION['user_id'];

// Konfigurasi database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'bengkelicb';

// Membuat koneksi ke database
$koneksi = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$query_service = "
SELECT 
  hp.id_history, 
  hp.id_transaksi, 
  hp.konfirmasi_teknisi, 
  hp.alamat AS alamat_pelanggan, 
  hp.no_hp AS no_hp_pelanggan, 
  hp.tanggal_konfirmasi AS konfirmasi_pelanggan, 
  hp.status_pembayaran AS status_pembayaran_pelanggan, 
  hp.harga, 
  t.nama AS nama_teknisi,
  t.e_wallet_id,
  p.nama AS nama_pelanggan,
  l.kategori,
  l.menu_layanan,
  l.nama_layanan
FROM 
  history_pelanggan hp
  LEFT JOIN pelanggan p ON hp.id_pelanggan = p.id_pelanggan
  LEFT JOIN teknisi t ON hp.id_teknisi = t.id_teknisi
  LEFT JOIN layanan l ON hp.id_layanan = l.id_layanan
WHERE 
  hp.id_pelanggan = '$id_pelanggan'
ORDER BY 
  hp.id_history DESC;
";

$result_service = $koneksi->query($query_service);

$query_booking = "
SELECT 
  hb.id_history_booking,
  hb.konfirmasi_teknisi,
  hb.alamat AS alamat_booking,
  hb.no_hp AS no_hp_booking,
  hb.tanggal_booking,
  hb.pukul,
  hb.status_pembayaran AS status_pembayaran_booking,
  hb.konfirmasi_teknisi AS konfirmasi_teknisi_booking,
  t.nama AS nama_teknisi,
  t.e_wallet_id,
  p.nama AS nama_pelanggan,
  l.harga,
  l.kategori,
  l.menu_layanan,
  l.nama_layanan
FROM 
  history_booking hb
  LEFT JOIN pelanggan p ON hb.id_pelanggan = p.id_pelanggan
  LEFT JOIN teknisi t ON hb.id_teknisi = t.id_teknisi
  LEFT JOIN layanan l ON hb.id_layanan = l.id_layanan
WHERE 
  hb.id_pelanggan = '$id_pelanggan'
ORDER BY 
  hb.id_history_booking DESC;
";

$result_booking = $koneksi->query($query_booking);

?>
<div class="container">
  <h2>History</h2>
<!-- Menu untuk memilih antara Service Langsung dan Service Booking -->
<div class="header">
    <div class="title active" id="serviceLangsungBtn" onclick="showService('langsung')">Service Langsung</div>
    <div class="title" id="serviceBookingBtn" onclick="showService('booking')">Service Booking</div>
</div>

<div id="serviceLangsungCard" class="card-container">
    <?php
    if ($result_service->num_rows > 0) {
        while ($row = $result_service->fetch_assoc()) {
          $e_wallet_methods = [
            '1' => 'GoPay',
            '2' => 'OVO',
            '3' => 'DANA',
            '4' => 'ShopeePay',
            '5' => 'LinkAja'
        ];
// Pastikan e_wallet_id tidak kosong atau null sebelum menggunakan explode
$e_wallet_ids = !empty($row['e_wallet_id']) ? explode(',', $row['e_wallet_id']) : [];

// Inisialisasi array untuk menyimpan nama metode e-wallet
$e_wallet_names = [];
foreach ($e_wallet_ids as $e_wallet_id) {
    if (isset($e_wallet_methods[$e_wallet_id])) {
        $e_wallet_names[] = $e_wallet_methods[$e_wallet_id];
    } else {
        $e_wallet_names[] = 'Tidak Tersedia';
    }
}
$e_wallet_names_str = implode(',', $e_wallet_names);

            ?>
            <div class="card">
                <h2>Service Langsung</h2>
                <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($row['nama_teknisi']) ?></p>
                <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($row['nama_pelanggan']) ?></p>
                <p><strong>Layanan:</strong> <?= htmlspecialchars($row['kategori']) ?> - <?= htmlspecialchars($row['menu_layanan']) ?> - <?= htmlspecialchars($row['nama_layanan']) ?></p>
                <p><strong>Harga:</strong> Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
                <p><strong>Alamat:</strong> <?= htmlspecialchars($row['alamat_pelanggan']) ?></p>
                <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($row['status_pembayaran_pelanggan']) ?></p>
                <p><strong>Konfirmasi Teknisi:</strong> <?= htmlspecialchars($row['konfirmasi_teknisi']) ?></p>

                <?php if ($row['konfirmasi_teknisi'] === 'Dikonfirmasi' && $row['status_pembayaran_pelanggan'] !== 'Sudah Dibayar') { ?>
                  <button class="btn btn-edit" 
        onclick="openModalHarga('<?= htmlspecialchars($row['id_history'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['id_history_booking'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['kategori'] ?? '') ?> - <?= htmlspecialchars($row['menu_layanan'] ?? '') ?> - <?= htmlspecialchars($row['nama_layanan'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['harga'] ?? '0') ?>', 
                         '<?= $e_wallet_names_str ?>')">Bayar Layanan</button>

<?php } elseif ($row['status_pembayaran_pelanggan'] === 'Sudah Dibayar') { ?>
  <button class="btn btn-view-history" 
      onclick="lihatHistory(<?= htmlspecialchars($row['id_history'] ?? 'null') ?>, <?= htmlspecialchars($row['id_history_booking'] ?? 'null') ?>)">
      Lihat History
  </button>
<?php } ?>

<?php if ($row['konfirmasi_teknisi'] === 'Belum Dikonfirmasi') { ?>

  <p style="color: #FF0000;">Tunggu Konfirmasi Teknisi ya!</p>

<?php } ?>

            </div>
            <?php
        }
    }
    ?>
</div>



<div id="serviceBookingCard" class="card-container" style="display: none;">
    <?php
    if ($result_booking->num_rows > 0) {
      while ($row = $result_booking->fetch_assoc()) {
        $e_wallet_methods = [
          '1' => 'GoPay',
          '2' => 'OVO',
          '3' => 'DANA',
          '4' => 'ShopeePay',
          '5' => 'LinkAja'
      ];
// Ambil semua e_wallet_id yang dimiliki teknisi
$e_wallet_ids = explode(',', $row['e_wallet_id']); // Misalkan e_wallet_id disimpan dengan koma sebagai pemisah

// Inisialisasi array untuk menyimpan nama metode e-wallet
$e_wallet_names = [];
foreach ($e_wallet_ids as $e_wallet_id) {
    if (isset($e_wallet_methods[$e_wallet_id])) {
        $e_wallet_names[] = $e_wallet_methods[$e_wallet_id];
    } else {
        $e_wallet_names[] = 'Tidak Tersedia';
    }
}
$e_wallet_names_str = implode(',', $e_wallet_names);


        ?>
            <div class="card">
                <h2>Booking Service</h2>
                <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($row['nama_teknisi']) ?></p>
                <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($row['nama_pelanggan']) ?></p>
                <p><strong>Layanan:</strong> <?= htmlspecialchars($row['kategori']) ?> - <?= htmlspecialchars($row['menu_layanan']) ?> - <?= htmlspecialchars($row['nama_layanan']) ?></p>
                <p><strong>Alamat:</strong> <?= htmlspecialchars($row['alamat_booking']) ?></p>
                <p><strong>No. HP:</strong> <?= htmlspecialchars($row['no_hp_booking']) ?></p>
                <p><strong>Waktu Booking:</strong> <?= htmlspecialchars($row['tanggal_booking']) ?> <?= htmlspecialchars($row['pukul']) ?></p>
                <p><strong>Harga:</strong> <?= htmlspecialchars($row['harga']) ?></p>
                <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($row['status_pembayaran_booking']) ?></p>
                <p><strong>Konfirmasi Teknisi:</strong> <?= htmlspecialchars($row['konfirmasi_teknisi']) ?></p>

                <?php if ($row['konfirmasi_teknisi'] === 'Dikonfirmasi' && $row['status_pembayaran_booking'] !== 'Sudah Dibayar') { ?>
                  <button class="btn btn-edit" 
        onclick="openModalHarga('<?= htmlspecialchars($row['id_history'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['id_history_booking'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['kategori'] ?? '') ?> - <?= htmlspecialchars($row['menu_layanan'] ?? '') ?> - <?= htmlspecialchars($row['nama_layanan'] ?? '') ?>', 
                         '<?= htmlspecialchars($row['harga'] ?? '0') ?>', 
                         '<?= $e_wallet_names_str ?>')">Bayar Layanan</button>

<?php } elseif ($row['status_pembayaran_booking'] === 'Sudah Dibayar') { ?>
  <button class="btn btn-view-history" 
      onclick="lihatHistory(<?= htmlspecialchars($row['id_history'] ?? 'null') ?>, <?= htmlspecialchars($row['id_history_booking'] ?? 'null') ?>)">
      Lihat History
  </button>
<?php } ?>

<?php if ($row['konfirmasi_teknisi'] === 'Belum Dikonfirmasi') { ?>
  <p style="color: #FF0000;">Tunggu Konfirmasi Teknisi ya!</p>

<?php } ?>


            </div>
            <?php
        }
    }
    ?>
</div>

<!-- Modal -->
  <!-- Modal -->
  <div id="paymentModal" class="modal">
      <div class="modal-content">
          <h2>Pilih Metode Pembayaran</h2>
          <p><strong>Layanan:</strong> <span id="modalLayanan"></span></p>
          <p><strong>Harga:</strong> <span id="modalHarga"></span></p>
          <p><strong>Metode Pembayaran:</strong></p>
          <div id="eWalletButtons"></div>
      </div>
  </div>


  </div>
<script>
function showService(serviceType) {
  // Sembunyikan kedua card terlebih dahulu
  document.getElementById('serviceLangsungCard').style.display = 'none';
  document.getElementById('serviceBookingCard').style.display = 'none';

  // Sembunyikan title aktif sebelumnya
  document.querySelectorAll('.title').forEach(title => title.classList.remove('active'));

  // Tampilkan card yang sesuai berdasarkan pilihan
  if (serviceType === 'langsung') {
    document.getElementById('serviceLangsungCard').style.display = 'block';
    document.getElementById('serviceLangsungBtn').classList.add('active');
  } else if (serviceType === 'booking') {
    document.getElementById('serviceBookingCard').style.display = 'block';
    document.getElementById('serviceBookingBtn').classList.add('active');
  }
}

// Secara default, tampilkan Service Langsung saat halaman dimuat
window.onload = function() {
  showService('langsung');
}

// Fungsi untuk menutup modal
// Fungsi untuk menutup modal
function closeModalHarga() {
    const modal = document.getElementById('paymentModal');
    modal.style.display = 'none';

    // Hapus event listener untuk menghindari kebocoran memori
    document.removeEventListener('click', closeModalOutsideClick);
}

// Fungsi untuk menutup modal jika klik di luar area modal
function closeModalOutsideClick(event) {
    const modal = document.getElementById('paymentModal');
    if (event.target === modal) {
        closeModalHarga();
    }
}

// Tutup modal saat pengguna mengklik di luar modal
window.onclick = function(event) {
    const modal = document.getElementById('paymentModal');
    if (event.target === modal) {
        closeModal();
    }
}

function openModalHarga(idHistory = '', idHistoryBooking = '', layanan = '', harga = '', eWalletNames = '') {
    const modal = document.getElementById('paymentModal');
    modal.style.display = 'flex';

    // Tampilkan detail layanan dan harga di modal
    document.getElementById('modalLayanan').textContent = layanan;
    document.getElementById('modalHarga').textContent = harga;

    // Kosongkan elemen sebelumnya di eWalletButtonsContainer
    const eWalletButtonsContainer = document.getElementById('eWalletButtons');
    eWalletButtonsContainer.innerHTML = '';

    // Pisahkan eWalletNames dengan koma dan buat tombol untuk setiap metode pembayaran
    const eWalletArray = eWalletNames.split(',').map(name => name.trim());
    eWalletArray.forEach(eWalletName => {
        if (eWalletName) {
            const button = document.createElement('button');
            button.className = 'btn-modal';
            button.textContent = eWalletName;
            button.onclick = () => selectPayment(eWalletName);
            eWalletButtonsContainer.appendChild(button);
        }
    });

    // Simpan kedua ID yang dipilih di variabel global
    window.selectedHistoryId = idHistory;
    window.selectedHistoryBookingId = idHistoryBooking;

    // Tambahkan event listener untuk menutup modal jika klik di luar modal
    document.addEventListener('click', closeModalOutsideClick);
}



function selectPayment(method) {
    // Ambil kedua ID yang dipilih
    const idHistory = window.selectedHistoryId;
    const idHistoryBooking = window.selectedHistoryBookingId;

    // Buat form data yang akan dikirim ke server
    const formData = new FormData();
    formData.append('payment_method', method);
    formData.append('id_history', idHistory);
    formData.append('id_history_booking', idHistoryBooking);

    // Gunakan fetch untuk mengirim data ke server dan menampilkan konfirmasi pembayaran
    fetch('../../_fungsi/history/konfirmasi_pembayaran.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(html => {
        // Tampilkan data konfirmasi pembayaran di elemen dengan ID #main-content
        document.getElementById('main-content').innerHTML = html;
    })
    .catch(error => {
        console.error('Terjadi kesalahan:', error);
    });
}


</script>
