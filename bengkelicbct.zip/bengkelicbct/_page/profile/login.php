<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Bengkel ICB CT</title>
    <link rel="stylesheet" href="_assets/css/login.css">
    <style>
        .success-message {
            text-align: center;
            display: none;
        }
        .success-message img {
            width: 80px;
            margin-bottom: 10px;
        }
        .toggle-link {
            margin-top: 15px;
            text-align: center;
            cursor: pointer;
            color: #b30000;
        }

        #responseMessage {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container1">
    <!-- Header Image -->
    <img src="_assets/img/banner01.jpeg" alt="Login Header" class="header-image">

    <!-- Login Form -->

        <div id="responseMessage"></div> <!-- Tempat untuk menampilkan pesan response -->
        <form id="loginForm">
            <h2>Login</h2>
            <div class="form-group">
                <label for="loginEmail">Email:</label>
                <input type="email" name="email" id="loginEmail" required>
            </div>
            <div class="form-group">
                <label for="loginPassword">Password:</label>
                <input type="password" name="password" id="loginPassword" required>
            </div>
            <input type="button" class="btn" value="Login" onclick="handleLogin()">
        </form>

    <!-- Registration Form -->
    <form id="registerForm" style="display: none;">
        <h2>Register</h2>
    <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" id="nama" required>
        </div>
        <div class="form-group">
            <label for="registerEmail">Email:</label>
            <input type="email" name="email" id="registerEmail" required>
        </div>
        <div class="form-group">
            <label for="registerPassword">Password:</label>
            <input type="password" name="password" id="registerPassword" required>
        </div>
        <div class="form-group">
            <label for="no_hp">No HP:</label>
            <input type="tel" name="no_hp" id="no_hp" required>
        </div>
        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <textarea name="alamat" id="alamat" rows="2" required></textarea>
        </div>
        <input type="button" class="btn" value="Register" onclick="handleRegister()">
    </form>

    <!-- Success Message -->
    <div class="success-message" id="successMessage">
        <img src="_assets/img/succes.webp" alt="Success Checkmark">
    </div>

    <!-- Toggle Link -->
    <div class="toggle-link" onclick="toggleForms()">Belum punya akun? Register disini</div>
</div>

<script>
// Fungsi untuk toggle antara form login dan register
function toggleForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const successMessage = document.getElementById('successMessage');
    const toggleLink = document.querySelector('.toggle-link');

    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        successMessage.style.display = 'none';
        toggleLink.textContent = "Belum punya akun? Register disini";
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        toggleLink.textContent = "Sudah punya akun? login disini";
    }
}

// Fungsi untuk menangani registrasi
function handleRegister() {
    const nama = document.getElementById('nama').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const no_hp = document.getElementById('no_hp').value;
    const alamat = document.getElementById('alamat').value;

    const body = `nama=${encodeURIComponent(nama)}&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&no_hp=${encodeURIComponent(no_hp)}&alamat=${encodeURIComponent(alamat)}`;

    fetch('_fungsi/profile/login/register_handler.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
    })
    .then(response => response.text()) // Mengharapkan HTML response
    .then(responseText => {
        // Menampilkan pesan response pada div responseMessage
        document.getElementById('responseMessage').innerHTML = responseText;

        // Jika registrasi berhasil, tampilkan pesan sukses
        if (responseText.includes("Registration successful")) { 
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('successMessage').style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error processing registration.');
    });
}

// Fungsi untuk menangani login
function handleLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value.trim();

  // Validasi input
  if (email === "" || password === "") {
    Swal.fire({
      icon: 'error',
      title: 'Login Gagal',
      text: 'Email dan password harus diisi.',
      confirmButtonText: 'Tutup'
    });
    return;
  }

  fetch('_fungsi/profile/login/login_handler.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Redirect berdasarkan role
      if (data.role === 'teknisi') {
        window.location.href = '/teknisi';
    } else if (data.role === 'pelanggan') {
        window.location.href = '/';
      }
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Login Gagal',
        text: data.message,
        confirmButtonText: 'Tutup'
      });
    }
  })
  .catch(error => {
    console.error('Error:', error);
    Swal.fire({
      icon: 'error',
      title: 'Terjadi Kesalahan',
      text: 'Tidak dapat memproses login Anda saat ini.',
      confirmButtonText: 'Tutup'
    });
  });
}

// Fungsi untuk validasi form registrasi
function validateRegisterForm() {
    const nama = document.getElementById('nama').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value.trim();
    const no_hp = document.getElementById('no_hp').value.trim();
    const alamat = document.getElementById('alamat').value.trim();
    const registerButton = document.querySelector('#registerForm input[type="button"]');

    if (nama && email && password && no_hp && alamat) {
        registerButton.disabled = false;
    } else {
        registerButton.disabled = true;
    }
}

// Tambahkan event listener untuk setiap input pada form register
document.getElementById('nama').addEventListener('input', validateRegisterForm);
document.getElementById('registerEmail').addEventListener('input', validateRegisterForm);
document.getElementById('registerPassword').addEventListener('input', validateRegisterForm);
document.getElementById('no_hp').addEventListener('input', validateRegisterForm);
document.getElementById('alamat').addEventListener('input', validateRegisterForm);
</script>

</body>
</html>
