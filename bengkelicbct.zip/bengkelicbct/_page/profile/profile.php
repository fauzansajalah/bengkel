<?php
// Memulai sesi jika belum dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Memeriksa apakah pengguna adalah teknisi
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'teknisi') {
    // Fitur khusus untuk teknisi
    echo "Selamat datang, Teknisi!";
}

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../_page/profile/login.php'); // Arahkan ke halaman login jika belum login
    exit;
}

// Sertakan file koneksi database dan pengambilan data pengguna
include '../_config/koneksi/koneksi.php'; // Pastikan koneksi benar
$user_id = $_SESSION['user_id']; // Ambil user_id dari sesi

// Tentukan query berdasarkan role
$user_role = $_SESSION['user_role']; // Menyimpan role pengguna (pelanggan atau teknisi)
if ($user_role === 'pelanggan') {
    $sql = "SELECT * FROM pelanggan WHERE id_pelanggan = ?";
} elseif ($user_role === 'teknisi') {
    $sql = "SELECT * FROM teknisi WHERE id_teknisi = ?";
} else {
    die("Role pengguna tidak dikenali");
}

// Persiapkan dan eksekusi query
$stmt = $koneksi->prepare($sql);
if ($stmt === false) {
    die("Gagal mempersiapkan query: " . $koneksi->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Jika data pengguna ditemukan
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("Data pengguna tidak ditemukan");
}

// Tutup koneksi database
$stmt->close();
$koneksi->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
</head>
<body>
    <div class="container">
<div class="profile-container">
    <div class="profile-card">
        <h1>Profil Pengguna</h1>
    <!-- Menampilkan gambar profil -->
    <img src="../path_to_images/<?= htmlspecialchars($user['foto_profil'] ?? 'untitled.png') ?>" alt="Foto Profil" id="profile-photo">
    <h3> <strong>Nama:</strong> <span id="nama"><?= htmlspecialchars($user['nama'] ?? 'Nama tidak tersedia') ?></span></h3>
    <p><strong>Email:</strong> <span id="email"><?= htmlspecialchars($user['email'] ?? 'Email tidak tersedia') ?></span></p>
    <p><strong>No. HP:</strong> <span id="no_hp"><?= htmlspecialchars($user['no_hp'] ?? 'No HP tidak tersedia') ?></span></p>
    <p><strong>Alamat:</strong> <span id="alamat"><?= htmlspecialchars($user['alamat'] ?? 'Alamat tidak tersedia') ?></span></p>
    <p><strong>Tanggal Daftar:</strong> <?= date('d-m-Y', strtotime($user['tanggal_daftar'] ?? '1900-01-01')) ?></p>
    <button class="btn btn-edit" onclick="enableEditPelanggan()">Edit</button>
    <a href="javascript:void(0);" id="logoutLink" class="btn-logout">Logout</a>
</div>


</div>
    </div>
<script>
function enableEditPelanggan() {
  const profileCard = document.querySelector('.profile-card');
  const nama = document.getElementById('nama');
  const email = document.getElementById('email');
  const alamat = document.getElementById('alamat');
  const noHp = document.getElementById('no_hp');

  const logoutButton = document.querySelector('.btn-logout');
  if (logoutButton) {
    logoutButton.style.display = 'none';
  }
  const btnEdit = document.querySelector('.btn-edit');
  btnEdit.textContent = 'Simpan';
  btnEdit.onclick = saveEditPelanggan;

  nama.innerHTML = `<input type="text" id="nama-edit" value="${nama.textContent}">`;
  email.innerHTML = `<input type="email" id="email-edit" value="${email.textContent}">`;
  alamat.innerHTML = `<input type="text" id="alamat-edit" value="${alamat.textContent}">`;
  noHp.innerHTML = `<input type="text" id="no_hp-edit" value="${noHp.textContent}">`;

  const btnBatal = document.createElement('button');
  btnBatal.textContent = 'Batal';
  btnBatal.className = 'btn-cancel';
  btnBatal.onclick = cancelEditPelanggan;
  profileCard.appendChild(btnBatal);
}

function saveEditPelanggan() {
  const namaEdit = document.getElementById('nama-edit').value;
  const emailEdit = document.getElementById('email-edit').value;
  const alamatEdit = document.getElementById('alamat-edit').value;
  const noHpEdit = document.getElementById('no_hp-edit').value;

  fetch('/_pelanggan/edit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `nama=${encodeURIComponent(namaEdit)}&email=${encodeURIComponent(emailEdit)}&alamat=${encodeURIComponent(alamatEdit)}&no_hp=${encodeURIComponent(noHpEdit)}&user_id=${encodeURIComponent('<?php echo $_SESSION['user_id']; ?>')}`
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      Swal.fire({
        title: 'Berhasil!',
        text: 'Data Anda telah diperbarui.',
        icon: 'success'
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: 'Gagal!',
        text: data.message,
        icon: 'error'
      });
    }
  })
  .catch(error => {
    Swal.fire({
      title: 'Error!',
      text: 'Terjadi kesalahan.',
      icon: 'error'
    });
  });
}

function cancelEditPelanggan() {
  location.reload();
}

    // Menambahkan event listener untuk link logout
    document.getElementById('logoutLink').addEventListener('click', function(e) {
        // Mencegah link default agar tidak langsung melakukan redirect
        e.preventDefault();

        // Menampilkan SweetAlert konfirmasi
        Swal.fire({
            title: 'Apakah Anda yakin ingin logout?',
            text: "Anda akan keluar dari akun Anda.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Logout',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika pengguna mengonfirmasi logout, lakukan POST request
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = '/logout'; // Arahkan ke halaman logout
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'logout';
                input.value = 'true';
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        });
    });
</script>

</body>
</html>
