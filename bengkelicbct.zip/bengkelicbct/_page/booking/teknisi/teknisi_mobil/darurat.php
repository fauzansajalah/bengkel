<?php
require_once '../_fungsi/service/nama-teknisi.php'; // Muat file layanan.php
require_once '../_fungsi/booking/kategori-teknisi.php'; // Muat file layanan.php
?>

<style>
        
        /* Menambahkan grid untuk menampilkan 2 item per baris */
        .service-menu {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 2 kolom */
            gap: 10px; /* Jarak antar item */
            justify-content: center; /* Memusatkan elemen dalam container */
        }
        
        /* Menyembunyikan item lebih dari 2 ketika belum dibuka */
        .hidden {
            display: none;
        }
        
        
            </style>
<div class="container">
        <!-- Judul Kategori Menu -->

    <div class="title" id="titleTeknisi" onclick="setActive('teknisi')">Kategori Teknisi</div>

    <div class="services" id="servicesContainer">
            <div class="service" onclick="navigateTo('teknisi_mobil')" data-menu="teknisi_mobil"><i class="bi bi-car-front icon"></i><div class="text">Teknisi Mobil</div></div>
            <div class="service" onclick="navigateTo('teknisi_motor')" data-menu="teknisi_motor"><i class="bi bi-bicycle icon"></i><div class="text">Teknisi Motor</div></div>
        </div>


    <div class="title" id="titleMobil" >Spesialis Layanan Mobil</div>

    <div class="services" id="servicesContainer">
        <div class="service" onclick="navigateTo('perbaikan_mobilT')" data-menu="perbaikan_mobil"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
        <div class="service" onclick="navigateTo('perawatan_mobilT')" data-menu="perawatan_mobil"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
        <div class="service" onclick="navigateTo('kustom_mobilT')" data-menu="kustom_mobil"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
        <div class="service" onclick="navigateTo('inspeksi_mobilT')" data-menu="inspeksi_mobil"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
        <div class="service" onclick="navigateTo('darurat_mobilT')" data-menu="darurat_mobil"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
        <div class="service" onclick="navigateTo('sukucadang_mobilT')" data-menu="sukucadang_mobil"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
        <div class="service" onclick="navigateTo('diagnostik_mobilT')" data-menu="diagnostik_mobil"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
        <div class="service" onclick="navigateTo('cuci_mobilT')" data-menu="cuci_mobil"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
        </div>
</div>
<br>
<div class="container-service">

    <!-- Teknisi Mobil (Contoh lainnya) -->
    <div class="container-teknisi">
        <header class="header-service">
            <h1 class="title-service">Teknisi Mobil</h1>
        </header>  
        <section class="section">
        <h2 class="subtitle">darurat</h2>
        </section>
        <div class="service-menu" id="teknisi-mobil">
            <!-- PHP: Menampilkan teknisi mobil dengan spesialis darurat -->
            <?php
            $teknisiMobil = mysqli_query($koneksi, "SELECT * FROM teknisi WHERE kategori = 'Mobil' AND spesialisasi LIKE '%darurat%'");

            if (mysqli_num_rows($teknisiMobil) == 0) {
                echo "<p>Tidak ada teknisi yang ditemukan.</p>";
            } else {
                while ($teknisi = mysqli_fetch_assoc($teknisiMobil)) {
                    $teknisiId = $teknisi['id_teknisi'];
                    echo "<div class='teknisi-item' data-teknisi-id='{$teknisiId}' onclick='loadTeknisiDetail({$teknisiId})'>
                            <img src='path_to_images/{$teknisi['foto']}' alt='Foto Teknisi' class='teknisi-foto'>
                            <div class='teknisi-info'>
                                <span class='teknisi-nama'>{$teknisi['nama']}</span>
                                <span class='kategori'>{$teknisi['kategori']}</span>
                            </div>
                          </div>";
                }
            }
            ?>
        </div>
    </div>
</div>