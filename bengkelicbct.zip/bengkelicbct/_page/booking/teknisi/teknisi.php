<?php
include('../../../_config/koneksi/koneksi.php');
require_once '../../../_fungsi/booking/select-teknisi.php'; // Muat file layanan.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Teknisi</title>

</head>
<div class="container">
    <?php if ($teknisi): ?>
        <div class="card">
        <div class="profile-container">
                <h1>Profil Teknisi: <?php echo htmlspecialchars($teknisi['nama']); ?></h1>
                <img src="path_to_images/<?php echo htmlspecialchars($teknisi['foto']); ?>" alt="Foto Teknisi" id="profile-photo">
                <div class="profile-info">
                <p><strong>Kategori:</strong> <?php echo htmlspecialchars($teknisi['kategori']); ?></p>
            <p><strong>Spesialisasi:</strong> <?php echo htmlspecialchars($teknisi['spesialisasi']); ?></p>
            <p><strong>Pengalaman:</strong> <?php echo htmlspecialchars($teknisi['pengalaman']); ?></p>
            <p><strong>Alamat:</strong> <?php echo htmlspecialchars($teknisi['alamat']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($teknisi['status']); ?></p>
                </div>
        </div>

            <div class="booking">
                <p>Klik disini untuk Booking teknisi ini:</p>
                <!-- Pass the teknisi ID as a parameter -->
                <button class="btn" onclick="bookTechnician(<?php echo $teknisi['id_teknisi']; ?>)">Booking Sekarang</button>
            </div>
        </div>
    <?php else: ?>
        <div class="header">
            <h1><?php echo $errorMessage ? htmlspecialchars($errorMessage) : 'Terjadi kesalahan'; ?></h1>
        </div>
        <div class="content">
        </div>
    <?php endif; ?>
</div>
</div> <!-- Penutup elemen .container -->

</body>
</html>
