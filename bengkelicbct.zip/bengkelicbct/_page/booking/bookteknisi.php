<?php
require_once '../../_fungsi/booking/bookteknisi.php'
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Teknisi</title>
</head>
<body>
<div class="container">
    <?php if (isset($error_message)): ?>
        <p class="error"><?= htmlspecialchars($error_message); ?></p>
    <?php elseif (isset($teknisi)): ?>
        <section>
            <h2>Booking Teknisi</h2>
        </section>
        <div class="card">
            <p><strong>Teknisi:</strong> <?= htmlspecialchars($teknisi['nama']); ?></p>
            <p><strong>Kategori:</strong> <?= htmlspecialchars($teknisi['kategori']); ?></p>
            <p><strong>Spesialisasi:</strong> <?= htmlspecialchars($teknisi['spesialisasi']); ?></p>
            <p><strong>Alamat:</strong> <?= htmlspecialchars($teknisi['alamat']); ?></p>
        </div>

        <?php 
        $spesialisasiList = !empty($teknisi['spesialisasi']) ? explode(',', $teknisi['spesialisasi']) : [];
        if (!empty($spesialisasiList)): 
        ?>
            <h3>Pilih Spesialisasi</h3>
            <?php foreach ($spesialisasiList as $spesialisasi): ?>
                <div>
                    <input type="radio" id="spesialisasi_<?= htmlspecialchars($spesialisasi); ?>" 
                           name="spesialisasi" 
                           value="<?= htmlspecialchars($spesialisasi); ?>">
                    <label for="spesialisasi_<?= htmlspecialchars($spesialisasi); ?>">
                        <?= htmlspecialchars($spesialisasi); ?>
                    </label>
                </div>
            <?php endforeach; ?>
            <br>
            <button onclick="processBooking(<?= htmlspecialchars($teknisi['id_teknisi']); ?>)" class="btn">Lanjut</button>
        <?php else: ?>
            <p class="error">Tidak ada spesialisasi yang tersedia untuk teknisi ini.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Script JavaScript -->
<script>

</script>
</body>
</html>
