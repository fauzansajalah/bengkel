<?php
session_start();

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, tampilkan pesan
    echo "<p>Anda perlu login untuk memesan layanan.</p>";
    exit(); // Hentikan eksekusi skrip
}

include('../../_config/koneksi/koneksi.php'); // Menghubungkan file koneksi yang telah Anda buat sebelumnya
require_once '../../_fungsi/booking/pilih-layanan.php';
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Layanan</title>
</head>
<body>
<div class="container">
<?php
// Cek apakah data teknisi ada di session
if (isset($_SESSION['teknisi'])):
    $teknisi = $_SESSION['teknisi'];
    ?>
    <div class="card">
        <h2>Data Booking Teknisi</h2>
        <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($teknisi['nama']); ?></p>
        <p><strong>Kategori:</strong> <?= htmlspecialchars($teknisi['kategori']); ?></p>
        <p><strong>Spesialisasi yang dipilih:</strong> <?= htmlspecialchars($teknisi['spesialisasi']); ?></p>
        <p><strong>Alamat Teknisi:</strong> <?= htmlspecialchars($teknisi['alamat']); ?></p>
    </div>

    <h3>Pilih Layanan</h3>
    <div id="layanan-list">
        <?php
        // Query untuk mendapatkan layanan berdasarkan kategori dan menu layanan teknisi
        $kategori = $teknisi['kategori'];
        $menu_layanan = $teknisi['spesialisasi'];

        $query = "SELECT * FROM layanan WHERE kategori = '$kategori' AND menu_layanan = '$menu_layanan'";
        $result = mysqli_query($koneksi, $query);

        if (mysqli_num_rows($result) > 0):
            while ($layanan = mysqli_fetch_assoc($result)):
                ?>
                <div class="radio-option">
                    <input type="radio" name="id_layanan" id="layanan-<?= $layanan['id_layanan']; ?>" 
                           value="<?= $layanan['id_layanan']; ?>" 
                           onclick="showDetails('<?= $layanan['id_layanan']; ?>', '<?= addslashes($layanan['deskripsi']); ?>', '<?= $layanan['harga']; ?>')" required>
                    <label for="layanan-<?= $layanan['id_layanan']; ?>">
                        <?= htmlspecialchars($layanan['nama_layanan']); ?>
                    </label>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="error">Tidak ada layanan yang sesuai ditemukan.</p>
        <?php endif; ?>
    </div>
<br>
    <div id="layanan-details" class="details" style="display: none;">
        <h4>Detail Layanan:</h4>
        <p id="layanan-deskripsi"></p>
        <p id="layanan-harga"></p>
    </div>

    <button class="btn" onclick="processLayanan('<?= $teknisi['id_teknisi']; ?>')">Lanjutkan</button>
<?php else: ?>
    <p class="error">Data tidak ditemukan. Harap kembali dan pilih spesialisasi.</p>
<?php endif; ?>
</div>

</body>
</html>
