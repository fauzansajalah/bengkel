<?php
session_start();

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, tampilkan pesan
    echo "<p>Anda perlu login untuk memesan layanan.</p>";
    exit(); // Hentikan eksekusi skrip
}

include('../../_config/koneksi/koneksi.php'); // Pastikan path koneksi sesuai dengan struktur folder Anda
require_once '../../_fungsi/booking/isi-alamat.php'

?>

<div class="container">
<div class="card">
    <h2>Data Teknisi</h2>
    <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($teknisi['nama']); ?></p>
    <p><strong>Kategori:</strong> <?= htmlspecialchars($teknisi['kategori']); ?></p>
    <p><strong>Spesialisasi:</strong> <?= htmlspecialchars($teknisi['spesialisasi']); ?></p>
    <p><strong>Alamat Teknisi:</strong> <?= htmlspecialchars($teknisi['alamat']); ?></p>
</div>

<div class="card">
    <h2>Detail Layanan</h2>
    <p><strong>Kategori:</strong> <?= htmlspecialchars($layanan['kategori']); ?></p>
    <p><strong>Menu Layanan:</strong> <?= htmlspecialchars($layanan['menu_layanan']); ?></p>
    <p><strong>Nama Layanan:</strong> <?= htmlspecialchars($layanan['nama_layanan']); ?></p>
    <p><strong>Deskripsi Layanan:</strong> <?= htmlspecialchars($layanan['deskripsi']); ?></p>
    <p><strong>Harga:</strong> <?= htmlspecialchars($layanan['harga']); ?></p>
</div>

<form id="form-group" action="_page/booking/purchase.php" method="POST" onsubmit="konfirmasiBooking(event)">
    
    <div class="form-group">
        <label for="alamat">Alamat:</label>
        <input 
            type="text" 
            id="alamat" 
            name="alamat" 
            value="<?= htmlspecialchars($pelangganData['alamat']); ?>" 
            class="form-control" 
            required>
    </div>
    <div class="form-group">
        <label for="no_hp">No HP:</label>
        <input 
            type="text" 
            id="no_hp" 
            name="no_hp" 
            value="<?= htmlspecialchars($pelangganData['no_hp']); ?>" 
            class="form-control" 
            required>
    </div>
    <div class="form-group">
        <label for="tanggal">Tanggal Booking:</label>
        <input 
            type="date" 
            id="tanggal" 
            name="tanggal" 
            class="form-control" 
            required>
        </div>
        <div class="form-group">
            <label for="pukul">Pukul:</label>
            <input 
            type="time" 
            id="pukul" 
            name="pukul" 
            class="form-control" 
            required>
        </div>
        <input type="hidden" name="id_teknisi" value="<?= htmlspecialchars($teknisi['id_teknisi']); ?>">
        <input type="hidden" name="id_layanan" value="<?= htmlspecialchars($layanan['id_layanan']); ?>">
        <button type="submit" class="btn">Konfirmasi</button>
</form>

</div>

<?php
// Pastikan untuk menutup koneksi database
mysqli_close($koneksi);
?>
