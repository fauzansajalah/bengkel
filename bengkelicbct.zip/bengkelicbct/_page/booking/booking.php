<?php
// Meng-include koneksi database
include('../_config/koneksi/koneksi.php');
require_once '../_fungsi/service/nama-teknisi.php'; // Muat file layanan.php
require_once '../_fungsi/booking/kategori-teknisi.php'; // Muat file layanan.php
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Teknisi</title>
    <style>
        
/* Menambahkan grid untuk menampilkan 2 item per baris */
.service-menu {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* 2 kolom */
    gap: 10px; /* Jarak antar item */
    justify-content: center; /* Memusatkan elemen dalam container */
}

/* Menyembunyikan item lebih dari 2 ketika belum dibuka */
.hidden {
    display: none;
}


    </style>
</head>
<body>
<!-- HTML -->
<div class="container">
        <!-- Judul Kategori Menu -->

    <h2 class="title" id="titleTeknisi" onclick="setActive('teknisi')">Kategori Teknisi</h2>

    <div class="services" id="servicesContainer">
            <div class="service" onclick="navigateTo('teknisi_mobil')" data-menu="teknisi_mobil"><i class="bi bi-car-front icon"></i><div class="text">Teknisi Mobil</div></div>
            <div class="service" onclick="navigateTo('teknisi_motor')" data-menu="teknisi_motor"><i class="bi bi-bicycle icon"></i><div class="text">Teknisi Motor</div></div>
        </div>
    </div>
    <br>
<div class="container">
    <h2>Booking Teknisi</h2>

    <!-- Teknisi Motor -->
    <div class="container-teknisi">
        <header class="header-service">
            <h1 class="title-service">Teknisi Motor</h1>
            <button class="menu-button" onclick="navigateTo('teknisi_motor')">Lihat Teknisi lainnya</button>
        </header>
        
        <div class="service-menu" id="teknisi-motor">
            <!-- PHP: Menampilkan teknisi motor -->
            <?php
            // Ambil data teknisi mobil dari database
            $teknisiMotor = mysqli_query($koneksi, "SELECT * FROM teknisi WHERE kategori = 'Motor'");
            
            if (mysqli_num_rows($teknisiMotor) == 0) {
                echo "<p>Tidak ada teknisi yang ditemukan.</p>";
            } else {
                $counter = 0;
                while ($teknisi = mysqli_fetch_assoc($teknisiMotor)) {
                    $hiddenClass = $counter >= 2 ? 'hidden' : ''; // Sembunyikan jika lebih dari 2
                    $teknisiId = $teknisi['id_teknisi']; // Ganti 'id' dengan nama kolom yang sesuai
                    echo "<div class='teknisi-item $hiddenClass' data-teknisi-id='{$teknisiId}' onclick='loadTeknisiDetail({$teknisiId})'>
                            <img src='path_to_images/{$teknisi['foto']}' alt='Foto Teknisi' class='teknisi-foto'>
                            <div class='teknisi-info'>
                                <span class='teknisi-nama'>{$teknisi['nama']}</span>
                                <span class='kategori'>{$teknisi['kategori']}</span>
                            </div>
                          </div>";
                    $counter++;
                }
            }
            ?>
        </div>

        <div class="toggle-button" onclick="toggleTechnicianMenu('teknisi-motor')">
            Lihat Lainnya <i>▼</i>
        </div>
    </div>

    <!-- Teknisi Mobil (Contoh lainnya) -->
    <div class="container-teknisi">
        <header class="header-service">
            <h1 class="title-service">Teknisi Mobil</h1>
            <button class="menu-button" onclick="navigateTo('teknisi_mobil')">Lihat Teknisi lainnya</button>
        </header>
        
        <div class="service-menu" id="teknisi-mobil">
            <?php
            // Ambil data teknisi mobil dari database
            $teknisiMobil = mysqli_query($koneksi, "SELECT * FROM teknisi WHERE kategori = 'Mobil'");
            
            if (mysqli_num_rows($teknisiMobil) == 0) {
                echo "<p>Tidak ada teknisi yang ditemukan.</p>";
            } else {
                $counter = 0;
                while ($teknisi = mysqli_fetch_assoc($teknisiMobil)) {
                    $hiddenClass = $counter >= 2 ? 'hidden' : ''; // Sembunyikan jika lebih dari 2
                    $teknisiId = $teknisi['id_teknisi']; // Ganti 'id' dengan nama kolom yang sesuai
                    echo "<div class='teknisi-item $hiddenClass' data-teknisi-id='{$teknisiId}' onclick='loadTeknisiDetail({$teknisiId})'>
                            <img src='path_to_images/{$teknisi['foto']}' alt='Foto Teknisi' class='teknisi-foto'>
                            <div class='teknisi-info'>
                                <span class='teknisi-nama'>{$teknisi['nama']}</span>
                                <span class='kategori'>{$teknisi['kategori']}</span>
                            </div>
                          </div>";
                    $counter++;
                }
            }
            ?>
            

        </div>

        <div class="toggle-button" onclick="toggleTechnicianMenu('teknisi-mobil')">
            Lihat Lainnya <i>▼</i>
        </div>
    </div>
</div>


</body>
</html>
