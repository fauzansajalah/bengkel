<?php
// Menyertakan file koneksi database
include('../../_config/koneksi/koneksi.php');

// Memulai sesi untuk mendapatkan user_id dari sesi login
session_start();
if (!isset($_SESSION['user_id'])) {
    die("Akses ditolak. Anda harus login terlebih dahulu.");
}

// Mengambil data dari form
$id_teknisi = intval($_POST['id_teknisi']);
$id_layanan = intval($_POST['id_layanan']);
$alamat = $koneksi->real_escape_string(trim($_POST['alamat']));
$no_hp = $koneksi->real_escape_string(trim($_POST['no_hp']));
$tanggal_booking = $koneksi->real_escape_string($_POST['tanggal']);
$pukul = $koneksi->real_escape_string($_POST['pukul']);
$user_id = intval($_SESSION['user_id']);

// Tanggal konfirmasi otomatis diisi dengan waktu saat ini
$tanggal_konfirmasi = date('Y-m-d H:i:s');

// Status default
$status_pembayaran = 'belum dibayar';
$konfirmasi_teknisi = 'belum dikonfirmasi';

// Query untuk menyimpan data ke tabel history_booking
$sql = "INSERT INTO history_booking (
    id_teknisi,
    id_layanan,
    id_pelanggan,
    alamat,
    no_hp,
    tanggal_booking,
    pukul,
    tanggal_konfirmasi,
    status_pembayaran,
    konfirmasi_teknisi
) VALUES (
    $id_teknisi,
    $id_layanan,
    $user_id,
    '$alamat',
    '$no_hp',
    '$tanggal_booking',
    '$pukul',
    '$tanggal_konfirmasi',
    '$status_pembayaran',
    '$konfirmasi_teknisi'
)";

if ($koneksi->query($sql) === TRUE) {
    // Setelah berhasil menyimpan ke history_booking, ambil tahun dan bulan dari tanggal_booking
    $tahun = date('Y', strtotime($tanggal_booking));
    $bulan = date('F', strtotime($tanggal_booking)); // Format bulan dalam nama lengkap, misalnya "January"

    // Periksa apakah data tahun dan bulan sudah ada di tabel pelanggan_per_bulan
    $checkQuery = "SELECT id FROM pelanggan_per_bulan WHERE tahun = ? AND bulan = ?";
    $stmtCheck = $koneksi->prepare($checkQuery);
    $stmtCheck->bind_param('is', $tahun, $bulan);
    $stmtCheck->execute();
    $result = $stmtCheck->get_result();

    if ($result->num_rows > 0) {
        // Jika data sudah ada, update jumlah_pelanggan
        $updateQuery = "UPDATE pelanggan_per_bulan SET jumlah_pelanggan = jumlah_pelanggan + 1 WHERE tahun = ? AND bulan = ?";
        $stmtUpdate = $koneksi->prepare($updateQuery);
        $stmtUpdate->bind_param('is', $tahun, $bulan);
        $stmtUpdate->execute();
    } else {
        // Jika data belum ada, insert data baru
        $insertQuery = "INSERT INTO pelanggan_per_bulan (tahun, bulan, jumlah_pelanggan) VALUES (?, ?, 1)";
        $stmtInsert = $koneksi->prepare($insertQuery);
        $stmtInsert->bind_param('is', $tahun, $bulan);
        $stmtInsert->execute();
    }

    // Setelah berhasil menyimpan booking dan memperbarui pelanggan_per_bulan, arahkan ke halaman history.php
    header("Location: ../../_page/history/history.php");
    exit(); // Pastikan script berhenti setelah pengalihan
} else {
    echo "Gagal menyimpan booking: " . $koneksi->error;
}

// Menutup koneksi database
$koneksi->close();
?>
