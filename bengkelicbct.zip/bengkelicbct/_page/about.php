<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>
<body>
    <div class="about-container">
        <div class="section">
            <h2>Tentang Kami</h2>
            <p>Selamat datang di aplikasi <span class="highlight">Bengkel Mobile SMK ICB CT</span>. Kami hadir untuk memberikan layanan untuk berbagai masalah kendaraan dengan metode (Teknisi ke Pelanggan) yang mudah diakses dan profesional.</p>
        </div>

        <div class="section profile">
    <div class="logo-container">
        <img src="_assets/img/logo-icb.png" alt="Logo Bengkel">
        <img src="_assets/img/yamaha-logo.png" alt="Logo Yamaha">
        <img src="_assets/img/daihatsu-logo.png" alt="Logo Daihatsu">
    </div>
    <div class="info">
        <h3>Didukung oleh SMK ICB CT, Yamaha, dan Daihatsu</h3>
        <p>Dengan dukungan penuh dari SMK ICB CT, Yamaha, dan Daihatsu, kami memastikan kualitas layanan terbaik, inovasi terbaru, dan pengalaman yang tak tertandingi bagi pelanggan kami.</p>
    </div>
</div>

        <div class="section vision-mission">
            <div>
                <h4>Visi</h4>
                <p>Menjadi bengkel pilihan utama yang mampu memberikan solusi tepat dan cepat bagi setiap masalah kendaraan Anda.</p>
            </div>
            <div>
                <h4>Misi</h4>
                <p>Menyediakan layanan yang profesional dan terjangkau, dengan menerapkan teknologi terkini dan tenaga ahli dari SMK ICB CT.</p>
            </div>
        </div>
        <div class="section skills-container">
    <h2>Keahlian dan Kelebihan Kami</h2>
    <p>Kami di Bengkel SMK ICB CT ini berkomitmen untuk memberikan layanan terbaik dengan dukungan tenaga ahli yang terampil dan berpengalaman. Berikut adalah beberapa keahlian dan keunggulan yang kami miliki untuk memastikan kendaraan Anda dalam kondisi terbaik:</p>

    <div class="skill">
        <h4>Keahlian Mekanik Tingkat Tinggi</h4>
        <div class="skill-bar">
            <span style="--skill-level: 95%"></span>
        </div>
        <p>Kami memiliki tim mekanik yang terlatih dengan kemampuan dan keahlian yang sangat baik dalam menangani berbagai jenis kendaraan. Keahlian mekanik kami didukung dengan pengalaman bertahun-tahun dalam industri ini.</p>
    </div>

    <div class="skill">
        <h4>Inovasi dan Teknologi Terkini</h4>
        <div class="skill-bar">
            <span style="--skill-level: 88%"></span>
        </div>
        <p>Kami selalu memperbarui peralatan dan metode perbaikan kami dengan teknologi terbaru agar kendaraan Anda ditangani dengan teknik yang paling mutakhir. Dengan ini, kami siap memberikan hasil yang optimal.</p>
    </div>

    <div class="skill">
        <h4>Pelayanan Cepat dan Tepat Waktu</h4>
        <div class="skill-bar">
            <span style="--skill-level: 92%"></span>
        </div>
        <p>Waktu Anda sangat berharga. Kami selalu berusaha untuk menyelesaikan setiap pekerjaan dengan cepat tanpa mengorbankan kualitas, memastikan kendaraan Anda siap digunakan secepat mungkin.</p>
    </div>

    <div class="skill">
        <h4>Komitmen Terhadap Kepuasan Pelanggan</h4>
        <div class="skill-bar">
            <span style="--skill-level: 100%"></span>
        </div>
        <p>Kepuasan Anda adalah prioritas utama kami. Kami memberikan layanan yang ramah, transparan, dan informatif sehingga Anda dapat merasa nyaman dan percaya pada kualitas pekerjaan kami.</p>
    </div>
</div>

</body>
</html>
