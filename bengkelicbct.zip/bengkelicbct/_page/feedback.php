<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <style>
        .rating {
            display: flex;
            justify-content: center;
            gap: 10px;
            font-size: 2rem;
            color: #ddd;
            cursor: pointer;
        }

        .star {
            font-size: 2rem;
            cursor: pointer;
            color: #ccc; /* Warna default */
            transition: color 0.2s ease;
        }

        .star.active {
            color: #ffcc00; /* Warna untuk bintang aktif */
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Form Feedback</h2>
        <form id="feedback-form">
            <div class="mb-3">
                <label for="rating" class="form-label">Rating</label>
                <div class="rating" id="rating">
                    <span class="star" data-value="1">★</span>
                    <span class="star" data-value="2">★</span>
                    <span class="star" data-value="3">★</span>
                    <span class="star" data-value="4">★</span>
                    <span class="star" data-value="5">★</span>
                </div>
                <input type="hidden" name="rating" id="rating-value" required>
                <div class="rating-description mt-2 text-muted" id="rating-description">Pilih jumlah bintang</div>
            </div>
            <br>
            <div class="mb-3">
                <label for="komentar" class="form-label">Komentar</label>
                <textarea class="form-control" id="komentar" name="komentar" rows="4"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Kirim Feedback</button>
        </form>
    </div>
    <script>

const stars = document.querySelectorAll('.star');
const ratingValue = document.getElementById('rating-value');
const ratingDescription = document.getElementById('rating-description');

const descriptions = {
    1: "Sangat Buruk",
    2: "Buruk",
    3: "Cukup",
    4: "Baik",
    5: "Sangat Baik"
};

stars.forEach((star, index) => {
    star.addEventListener('click', () => {
        // Hapus kelas 'active' dari semua bintang
        stars.forEach(s => s.classList.remove('active'));
        
        // Aktifkan bintang sampai indeks yang dipilih
        for (let i = 0; i <= index; i++) {
            stars[i].classList.add('active');
        }
        
        // Set nilai rating ke input tersembunyi
        ratingValue.value = star.dataset.value;

        // Perbarui deskripsi rating
        ratingDescription.textContent = descriptions[star.dataset.value];
    });
});

// Fungsi untuk menangani pengiriman feedback
document.getElementById('feedback-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const rating = document.getElementById('rating-value').value;
    const komentar = document.getElementById('komentar').value;

    fetch('_fungsi/feedback.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'  // Mengatur header menjadi JSON
    },
    body: JSON.stringify({
        rating: rating,
        komentar: komentar
    })  // Mengirim data dalam format JSON
})
.then(response => {
    console.log(response);  // Debugging untuk melihat respons dari server
    return response.json();  // Parsing respons JSON
})
.then(data => {
    if (data.status === 'success') {
        Swal.fire({
            icon: 'success',
            title: 'Terima kasih atas feedbacknya!',
            text: 'Kami akan selalu usahakan yang terbaik.',
            confirmButtonText: 'OK'
        }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
            }
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Terjadi kesalahan saat mengirim feedback. Silakan coba lagi.',
            confirmButtonText: 'OK'
        });
    }
})
.catch(error => {
    console.error('Error:', error);
    Swal.fire({
        icon: 'error',
        title: 'Kesalahan!',
        text: 'Gagal mengirim feedback. Silakan coba lagi.',
        confirmButtonText: 'OK'
    });
});

});
    </script>
</body>
</html>
