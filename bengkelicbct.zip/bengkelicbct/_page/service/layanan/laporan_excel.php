<?php
// Sertakan file koneksi
include('../../../_config/koneksi/koneksi.php'); // Pastikan jalur ini benar

// Set header untuk mengunduh file Excel
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_layanan_mobil.xls");

try {
    // Query untuk mengambil data layanan berdasarkan kategori
    $sql = "
        SELECT kategori, nama_layanan, harga, deskripsi 
        FROM layanan 
        WHERE kategori = 'Mobil' 
        ORDER BY kategori, nama_layanan
    ";
    $result = $koneksi->query($sql);

    // Periksa jika query berhasil
    if (!$result) {
        echo "Gagal mendapatkan data layanan.";
        exit;
    }

    // Header kolom
    echo "Kategori\tNama Layanan\tHarga\tDeskripsi\n";

    // Output data layanan
    while ($layanan = $result->fetch_assoc()) {
        echo htmlspecialchars($layanan['kategori']) . "\t" .
             htmlspecialchars($layanan['nama_layanan']) . "\t" .
             number_format($layanan['harga'], 0, ',', '.') . "\t" .
             htmlspecialchars($layanan['deskripsi']) . "\n";
    }
} catch (Exception $e) {
    echo "Terjadi kesalahan: " . $e->getMessage();
    exit;
}
?>
