<?php
require_once '../_fungsi/service/nama-layanan.php'; // Muat file layanan.php
?>
    <div class="container">
    <div class="title" id="titlemenu" onclick="setActive('menu')">Kategori Menu Service</div>

<div class="services" id="servicesContainer">
        <div class="service" onclick="navigateTo('menu_mobil')" data-menu="menu_mobil"><i class="bi bi-car-front icon"></i><div class="text">Mobil</div></div>
        <div class="service" onclick="navigateTo('menu_motor')" data-menu="menu_motor"><i class="bi bi-bicycle icon"></i><div class="text">Motor</div></div>
    </div>
<br>

<!-- Category Titles -->
<div class="title" id="titleMobil">Mobil</div>

<div class="services" id="servicesContainer">
    <div class="service" onclick="navigateTo('perawatan_mobil')" data-menu="perawatan_mobil"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
    <div class="service" onclick="navigateTo('perbaikan_mobil')" data-menu="perbaikan_mobil"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
    <div class="service" onclick="navigateTo('inspeksi_mobil')" data-menu="inspeksi_mobil"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
    <div class="service" onclick="navigateTo('sukucadang_mobil')" data-menu="sukucadang_mobil"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
    <div class="service" onclick="navigateTo('kustom_mobil')" data-menu="kustom_mobil"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
    <div class="service" onclick="navigateTo('darurat_mobil')" data-menu="darurat_mobil"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
    <div class="service" onclick="navigateTo('diagnostik_mobil')" data-menu="diagnostik_mobil"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
    <div class="service" onclick="navigateTo('cuci_mobil')" data-menu="cuci_mobil"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
 
</div>
</div>
<br>
<div class="container-service">
        <header class="header-service">
            <h1 class="title-service">Mobil</h1>
            <button class="menu-button" onclick="navigateTo('menu_mobil')" data-menu="menu_mobil">Lihat Menu Lainnya</button>
        </header>

        <!-- Sub Title cuci -->
        <section class="section">
            <h2 class="subtitle">cuci</h2>
            <div class="service-menu" id="cuci-mobil">
                <?php
                $cuciLayanan = getLayanan('Mobil', 'cuci');
                if (empty($cuciLayanan)) {
                    echo "<p>Tidak ada layanan yang ditemukan.</p>";
                } else {
                    foreach ($cuciLayanan as $index => $layanan) {
                        $hiddenClass = $index >= 2 ? 'hidden' : ''; // Sembunyikan jika lebih dari 2
                        echo "<div class='service $hiddenClass' data-index='$index' onclick=\"loadTransaksi('" . urlencode($layanan) . "')\">$layanan</div>";
                    }
                }
                ?>
            </div>

            <div class="toggle-button" onclick="toggleServices('cuci-mobil')">
                Lihat Lainnya <i>▼</i>
            </div>
        </section>
    </div>