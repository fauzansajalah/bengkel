<?php
require_once '../_fungsi/service/nama-layanan.php'; // Muat file layanan.php
?>
<div class="container">
<div class="title" id="titlemenu" onclick="setActive('menu')">Kategori Menu Service</div>

<div class="services" id="servicesContainer">
        <div class="service" onclick="navigateTo('menu_mobil')" data-menu="menu_mobil"><i class="bi bi-car-front icon"></i><div class="text">Mobil</div></div>
        <div class="service" onclick="navigateTo('menu_motor')" data-menu="menu_motor"><i class="bi bi-bicycle icon"></i><div class="text">Motor</div></div>
    </div>
<br>
    <div class="title" id="titleMotor" >Motor</div>

    <div class="services" id="servicesContainer">
        <div class="service" onclick="navigateTo('perbaikan_motor')" data-menu="perbaikan_motor"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
        <div class="service" onclick="navigateTo('perawatan_motor')" data-menu="perawatan_motor"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
        <div class="service" onclick="navigateTo('kustom_motor')" data-menu="kustom_motor"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
        <div class="service" onclick="navigateTo('inspeksi_motor')" data-menu="inspeksi_motor"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
        <div class="service" onclick="navigateTo('darurat_motor')" data-menu="darurat_motor"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
        <div class="service" onclick="navigateTo('sukucadang_motor')" data-menu="sukucadang_motor"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
        <div class="service" onclick="navigateTo('diagnostik_motor')" data-menu="diagnostik_motor"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
        <div class="service" onclick="navigateTo('cuci_motor')" data-menu="cuci_motor"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
    
    </div>
</div>
<br>
<div class="container-service">
        <header class="header-service">
            <h1 class="title-service">motor</h1>
            <button class="menu-button" onclick="navigateTo('menu_motor')" data-menu="menu_motor">Lihat Menu Lainnya</button>
        </header>

        <!-- Sub Title inspeksi -->
        <section class="section">
            <h2 class="subtitle">inspeksi</h2>
            <div class="service-menu" id="inspeksi-motor">
                <?php
                $inspeksiLayanan = getLayanan('motor', 'inspeksi');
                if (empty($inspeksiLayanan)) {
                    echo "<p>Tidak ada layanan yang ditemukan.</p>";
                } else {
                    foreach ($inspeksiLayanan as $index => $layanan) {
                        $hiddenClass = $index >= 2 ? 'hidden' : ''; // Sembunyikan jika lebih dari 2
                        echo "<div class='service $hiddenClass' data-index='$index' onclick=\"loadTransaksi('" . urlencode($layanan) . "')\">$layanan</div>";
                    }
                }
                ?>
            </div>

            <div class="toggle-button" onclick="toggleServices('inspeksi-motor')">
                Lihat Lainnya <i>▼</i>
            </div>
        </section>
    </div>