<?php
require('../../../libary/fpdf.php'); // Sertakan pustaka FPDF
include '../../../_config/koneksi/koneksi.php'; // Pastikan jalur koneksi benar

// Inisialisasi objek PDF
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Setel judul
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(200, 10, 'Laporan Layanan Berdasarkan Kategori', 0, 0, 'C');

// Tambahkan spasi
$pdf->Cell(10, 15, '', 0, 1);
$pdf->SetFont('Times', 'B', 10);

// Setel header tabel
$pdf->Cell(10, 7, 'No', 1, 0, 'C');
$pdf->Cell(50, 7, 'Kategori', 1, 0, 'C');
$pdf->Cell(50, 7, 'Nama Layanan', 1, 0, 'C');
$pdf->Cell(30, 7, 'Harga', 1, 0, 'C');
$pdf->Cell(50, 7, 'Deskripsi', 1, 1, 'C');

// Setel font untuk data
$pdf->SetFont('Times', '', 10);

// Query untuk mengambil data layanan berdasarkan kategori
$sql = "SELECT kategori, nama_layanan, harga, deskripsi FROM layanan WHERE kategori = 'Mobil' ORDER BY kategori, nama_layanan";
$result = $koneksi->query($sql);

// Cek apakah query berhasil
if ($result === false) {
    echo json_encode(['error' => 'Query failed']);
    exit;
}

// Tambahkan data ke PDF
$no = 1;
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(10, 6, $no++, 1, 0, 'C');
    $pdf->Cell(50, 6, $row['kategori'], 1, 0);
    $pdf->Cell(50, 6, $row['nama_layanan'], 1, 0);
    $pdf->Cell(30, 6, number_format($row['harga'], 0, ',', '.'), 1, 0);
    $pdf->Cell(50, 6, $row['deskripsi'], 1, 1);
}

// Output PDF
$pdf->Output();
?>
