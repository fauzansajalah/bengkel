<?php
// Memasukkan file yang menangani pengambilan data layanan
require_once('../../_fungsi/service/layanan-transaksi.php');
require_once('../../_fungsi/service/pilih-teknisi.php');
require_once('../../_fungsi/service/detail-teknisi.php');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Layanan</title>

    <style>
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Detail Layanan</h1>
            <?php if ($data): ?>
                <div class="card-body">
                    <h2><?php echo htmlspecialchars($data['nama_layanan']); ?></h2>
                    <p><strong>Kategori:</strong> <?php echo htmlspecialchars($data['kategori']); ?></p>
                    <p><strong>Menu Layanan:</strong> <?php echo htmlspecialchars($data['menu_layanan']); ?></p>
                    <p><strong>Deskripsi:</strong> <?php echo htmlspecialchars($data['deskripsi']); ?></p>
                    <p><strong>Harga:</strong> Rp <?php echo number_format($data['harga'], 0, ',', '.'); ?></p>
                </div>
            <?php else: ?>
                <p>Detail layanan tidak ditemukan.</p>
            <?php endif; ?>
        </div>

        <h2>Pilih Teknisi</h2>
        <form id="form-teknisi" method="POST" action="_page/service/detail-transaksi.php">
            <?php if (!empty($teknisiList)): ?>
                <?php foreach ($teknisiList as $teknisi): ?>
                    <div class="form-group">
                        <input 
                            type="radio" 
                            name="teknisi" 
                            value="<?php echo $teknisi['id_teknisi']; ?>" 
                            id="teknisi-<?php echo $teknisi['id_teknisi']; ?>" 
                            onclick="showTeknisiDetails(<?php echo htmlspecialchars(json_encode($teknisi)); ?>)">
                        <label for="teknisi-<?php echo $teknisi['id_teknisi']; ?>">
                            <?php echo htmlspecialchars($teknisi['nama']); ?> - 
                            <span style="font-style: italic; color: gray;">
                                <?php echo htmlspecialchars($teknisi['spesialisasi']); ?>
                            </span>
                        </label>
                    </div>
                <?php endforeach; ?>
                <input type="hidden" name="id_layanan" value="<?php echo htmlspecialchars($data['id_layanan']); ?>">
            <?php else: ?>
                <p>Tidak ada teknisi yang sesuai dengan kategori layanan ini.</p>
            <?php endif; ?>
        </form>

        <h2>Profile Teknisi</h2>
        <div id="detail-teknisi-content"><!-- js nya sudah ada jangan di apa apain --></div> 
        <button class="btn" id="btn-lanjut" onclick="lanjutTransaksi()" style="display: none;">Lanjut</button>
    </div>
</body>
</html>
