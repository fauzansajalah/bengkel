<?php
session_start();

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, tampilkan pesan
    echo "<p>Anda perlu login untuk memesan layanan.</p>";
    exit(); // Hentikan eksekusi skrip
}

include('../../_config/koneksi/koneksi.php');
require_once '../../_fungsi/service/detail-transaksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi</title>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>Detail Layanan</h1>
        <div class="card-body">
    <h2><?php echo htmlspecialchars($dataLayanan['nama_layanan'] ?? 'Tidak ditemukan'); ?></h2>
    <p><strong>Kategori:</strong> <?php echo htmlspecialchars($dataLayanan['kategori'] ?? 'Tidak ditemukan'); ?></p>
    <p><strong>Menu Layanan:</strong> <?php echo htmlspecialchars($dataLayanan['menu_layanan'] ?? 'Tidak ditemukan'); ?></p>
    <p><strong>Harga:</strong> 
        <?php 
            if (isset($dataLayanan['harga'])) {
                echo 'Rp ' . htmlspecialchars(number_format($dataLayanan['harga'], 0, ',', '.'));
            } else {
                echo 'Tidak tersedia';
            }
            ?>
    </p>
    
    <p><strong>Teknisi yang Dipilih:</strong> <?php echo htmlspecialchars($dataTeknisi['nama'] ?? 'Tidak ada teknisi yang dipilih'); ?></p>
</div>
</div>


    <form id="form-teknisi" method="POST" action="_page/service/purchase.php" onsubmit="Konfirmasi(event)">
        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <input 
                type="text" 
                id="alamat" 
                name="alamat" 
                value="<?php echo htmlspecialchars($pelangganData['alamat']); ?>" 
                class="form-control">
        </div>
        <div class="form-group">
            <label for="no_hp">No HP:</label>
            <input 
                type="text" 
                id="no_hp" 
                name="no_hp" 
                value="<?php echo htmlspecialchars($pelangganData['no_hp']); ?>" 
                class="form-control">
        </div>
        <input type="hidden" name="harga" value="<?php echo htmlspecialchars($dataLayanan['harga']); ?>">
        <input type="hidden" name="id_teknisi" value="<?php echo htmlspecialchars($teknisiId); ?>">
        <input type="hidden" name="id_layanan" value="<?php echo htmlspecialchars($layananId); ?>">
        <button type="submit" class="btn">Konfirmasi</button>
    </form>

</body>
</html>
