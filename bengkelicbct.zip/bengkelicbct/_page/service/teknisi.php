<?php
require_once '../../_fungsi/service/teknisi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Teknisi</title>
    <style>
        .layanan-container {
            margin: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .layanan {
            padding: 10px;
            margin: 5px 0;
            background: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<h1>Nama Teknisi: <?= htmlspecialchars($namaTeknisi) ?></h1>
<div class="layanan-container">
    <?php if (!empty($layanan)): ?>
        <?php foreach ($layanan as $item): ?>
            <div class="layanan"><?= htmlspecialchars($item) ?></div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Tidak ada layanan tersedia untuk teknisi ini.</p>
    <?php endif; ?>
</div>

</body>
</html>
