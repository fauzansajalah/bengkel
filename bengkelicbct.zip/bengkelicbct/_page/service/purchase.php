<?php

require_once '../../_fungsi/service/insert-history.php';
require_once '../../_fungsi/service/insert-transaksi.php';
include('../../_config/koneksi/koneksi.php'); // Pastikan path koneksi benar

// Validasi ID transaksi dari URL
if (!isset($_GET['id_transaksi']) || empty($_GET['id_transaksi'])) {
    exit;
}

$idTransaksi = intval($_GET['id_transaksi']); // Ambil ID transaksi dari URL

// Query untuk mendapatkan detail transaksi
$query = "
    SELECT 
        t.id_transaksi,
        p.nama AS nama_pelanggan,
        t.alamat,
        t.no_hp,
        l.nama_layanan,
        l.harga,
        tek.nama AS nama_teknisi,
        t.status_pembayaran,
        t.metode_pembayaran,
        t.tanggal_transaksi
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_user
    JOIN layanan l ON t.id_layanan = l.id_layanan
    JOIN teknisi tek ON t.id_teknisi = tek.id_teknisi
    WHERE t.id_transaksi = ?
";

$stmt = $koneksi->prepare($query);
$stmt->bind_param('i', $idTransaksi);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Detail transaksi tidak ditemukan.";
    exit;
}

$dataTransaksi = $result->fetch_assoc();

$stmt->close();
$koneksi->close();
?>
