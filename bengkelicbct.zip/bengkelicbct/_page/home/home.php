<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - BENGKEL ICB CT</title>
    <style>
        /* Styling for the banner container */
.banner-slider-container {
    position: relative;
    max-width: 100%;
    overflow: hidden; /* Hide overflow to only show one image at a time */
    margin: auto;
}

/* Styling for the banner slider (holding all banners) */
.banner-slider {
    display: flex;
    transition: transform 0.5s ease; /* Smooth sliding transition */
}

/* Styling for each banner item */
.banner {
    min-width: 100%; /* Make each banner take the full width */
    box-sizing: border-box;
}

/* Styling for the images inside each banner */
.banner img {
    width: 100%;
    height: auto;
    display: block;
}

/* Styling for the slider control buttons */
.slider-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    border: none;
    padding: 10px;
    font-size: 24px;
    cursor: pointer;
    z-index: 1;
}

/* Left button positioning */
.left {
    left: 10px;
}

/* Right button positioning */
.right {
    right: 10px;
}

/* Media queries for mobile view */
@media (max-width: 768px) {
    /* Ensure that images stay horizontally aligned */
    .banner-slider {
        flex-direction: row; /* Keep images in a horizontal row */
    }

    .banner {
        min-width: 100%; /* Ensure each banner takes the full width */
    }
}

    </style>
</head>

<body>

    <!-- Header Image -->
    <div class="header">
        <img src="_assets/img/banner01.jpeg" class="header-image" alt="Header Banner">
    </div>

    <div class="container">
        <!-- Judul Kategori Menu -->
    <h2 class="category-title">Kategori Menu</h2>

        <!-- Category Titles -->
    <div class="title active" id="titleMobil" onclick="setActive('mobil')">Mobil</div>
    <div class="title" id="titleMotor" onclick="setActive('motor')">Motor</div>

        <div class="services" id="servicesContainer">
            <div class="service" onclick="navigateTo('perawatan_mobil')" data-menu="perawatan_mobil"><i class="bi bi-tools icon"></i><div class="text">Perawatan</div></div>
            <div class="service" onclick="navigateTo('perbaikan_mobil')" data-menu="perbaikan_mobil"><i class="bi bi-wrench icon"></i><div class="text">Perbaikan</div></div>
            <div class="service" onclick="navigateTo('inspeksi_mobil')" data-menu="inspeksi_mobil"><i class="bi bi-clipboard-check icon"></i><div class="text">Inspeksi</div></div>
            <div class="service" onclick="navigateTo('sukucadang_mobil')" data-menu="sukucadang_mobil"><i class="bi bi-gear icon"></i><div class="text">Suku Cadang</div></div>
            <div class="service" onclick="navigateTo('kustom_mobil')" data-menu="kustom_mobil"><i class="bi bi-star icon"></i><div class="text">Kustom</div></div>
            <div class="service" onclick="navigateTo('darurat_mobil')" data-menu="darurat_mobil"><i class="bi bi-life-preserver icon"></i><div class="text">Darurat</div></div>
            <div class="service" onclick="navigateTo('diagnostik_mobil')" data-menu="diagnostik_mobil"><i class="bi bi-activity icon"></i><div class="text">Diagnostik</div></div>
            <div class="service" onclick="navigateTo('cuci_mobil')" data-menu="cuci_mobil"><i class="bi bi-droplet icon"></i><div class="text">Cuci</div></div>
        </div>
    </div>

    <div class="chart-container"> <!-- Grafik Container -->
    <h2 class="chart-title">Grafik Bulanan Pelanggan</h2>
    <canvas id="pelangganChart"></canvas>
</div>


<div class="banner-slider-container">
    <div class="banner-slider">
        <div class="banner" id="banner1">
            
                <img src="_assets/img/banner-slide1.png" alt="Banner 1">
            </a>
        </div>
        <div class="banner" id="banner2">
            
                <img src="_assets/img/banner-slide4.png" alt="Banner 2">
            
        </div>
        <div class="banner" id="banner3">
            
                <img src="_assets/img/banner-slide7.png" alt="Banner 3">
            
        </div>
        <div class="banner" id="banner4">
            
                <img src="_assets/img/banner-slide3.jpg" alt="Banner 4">
            
        </div>
        <div class="banner" id="banner5">
            
                <img src="_assets/img/banner-slide6.jpg" alt="Banner 5">
            
        </div>
        <div class="banner" id="banner6">
            
                <img src="_assets/img/banner-slide5.jpg" alt="Banner 6">
            
        </div>
    </div>
    <!-- Slider Controls -->
    <button class="slider-btn left" id="prevBtn">&#10094;</button>
    <button class="slider-btn right" id="nextBtn">&#10095;</button>
</div>

<p style="font-family: Arial, sans-serif; font-size: 14px; color: #555; text-align: center;">
    © 2024 SMK ICB-CT
</p>


    <script>
fetch('../_fungsi/home/grafik_pelanggan.php')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        const labels = data.labels;
        const dataValues = data.data;

        // Membuat array 12 bulan terakhir dari bulan saat ini
        const currentDate = new Date();
        const last12Months = [];
        const monthNames = ['January', 'February', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

        for (let i = 11; i >= 0; i--) {
            const d = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
            const monthName = monthNames[d.getMonth()];
            last12Months.push(`${d.getFullYear()}-${monthName}`);
        }

        // Buat objek data dengan bulan yang sudah diisi default 0
        const dataMap = last12Months.reduce((acc, month) => {
            acc[month] = 80;
            return acc;
        }, {});

        // Isi dataMap dengan data dari server
        labels.forEach((label, index) => {
            if (dataMap.hasOwnProperty(label)) {
                dataMap[label] = dataValues[index];
            }
        });

        // Pisahkan label dan data yang sudah diurutkan
        const sortedLabels = Object.keys(dataMap);
        const sortedDataValues = Object.values(dataMap);

        // Buat grafik batang
        const ctx = document.getElementById('pelangganChart').getContext('2d');
        const pelangganChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: sortedLabels,
                datasets: [{
                    label: 'Jumlah Pelanggan',
                    data: sortedDataValues,
                    backgroundColor: '#b30000',
                    borderColor: '#333',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            display: false // Menyembunyikan label pada sumbu X
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => {
        console.error('Error fetching data:', error);
    });


    (function() {
    let sliderIndex = 0; // Track current index of the visible banner
    const banners = document.querySelectorAll('.banner');
    const totalBanners = banners.length;

    // Function to move to the previous banner
    function moveToPrev() {
        if (sliderIndex === 0) {
            sliderIndex = totalBanners - 1; // Loop back to last banner
        } else {
            sliderIndex--;
        }
        updateSliderPosition();
    }

    // Function to move to the next banner
    function moveToNext() {
        if (sliderIndex === totalBanners - 1) {
            sliderIndex = 0; // Loop back to first banner
        } else {
            sliderIndex++;
        }
        updateSliderPosition();
    }

    // Update the position of the slider
    function updateSliderPosition() {
        const slider = document.querySelector('.banner-slider');
        slider.style.transform = `translateX(-${sliderIndex * 100}%)`;
    }

    // Add event listeners for the slider buttons
    document.getElementById('prevBtn').addEventListener('click', moveToPrev);
    document.getElementById('nextBtn').addEventListener('click', moveToNext);
})();

</script>

</body>
</html>
