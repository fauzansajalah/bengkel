<?php
include '../../_config/koneksi/koneksi.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_teknisi = $_POST['id_teknisi'];

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $targetDir = '../../path_to_images/';
        $fileName = basename($_FILES['foto']['name']);
        $uniqueFileName = time() . '_' . $fileName;
        $targetFilePath = $targetDir . $uniqueFileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        // Validasi jenis file
        if (in_array(strtolower($fileType), $allowedTypes)) {
            // Pindahkan file ke folder tujuan
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $targetFilePath)) {
                // Update nama file di database
                $query = "UPDATE teknisi SET foto = '$uniqueFileName' WHERE id_teknisi = '$id_teknisi'";
                $result = mysqli_query($koneksi, $query);

                if ($result) {
                    echo json_encode(['status' => 'success', 'message' => 'Foto profil berhasil diperbarui.']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui data di database.']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Gagal mengunggah file.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Jenis file tidak didukung. Hanya JPG, JPEG, PNG, dan GIF yang diizinkan.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada file yang diunggah atau file terlalu besar.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Metode tidak valid.']);
}
?>
