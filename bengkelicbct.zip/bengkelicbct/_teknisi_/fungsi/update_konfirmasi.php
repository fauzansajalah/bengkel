<?php
include '../../_config/koneksi/koneksi.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Periksa apakah user memiliki akses sebagai teknisi
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "Akses ditolak. Anda harus login sebagai teknisi."
    ]);
    exit;
}

$id_teknisi = $_SESSION['user_id']; // Ambil ID teknisi dari sesi

// Periksa apakah request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi apakah id_history dikirim
    if (!isset($_POST['id_history'])) {
        http_response_code(400); // Bad Request
        echo json_encode([
            "success" => false,
            "message" => "Parameter 'id_history' tidak ditemukan."
        ]);
        exit;
    }

    $id_history = intval($_POST['id_history']); // Ambil dan validasi id_history

    try {
        // Query untuk mengupdate status konfirmasi teknisi
        $query = "UPDATE history_pelanggan SET konfirmasi_teknisi = 'Dikonfirmasi' WHERE id_history = ?";
        $stmt = $koneksi->prepare($query);

        if ($stmt === false) {
            throw new Exception("Gagal mempersiapkan query.");
        }

        $stmt->bind_param("i", $id_history);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode([
                "success" => true,
                "message" => "Pesanan berhasil dikonfirmasi."
            ]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "ID history tidak ditemukan atau sudah dikonfirmasi sebelumnya."
            ]);
        }

        $stmt->close();
    } catch (Exception $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode([
            "success" => false,
            "message" => "Gagal mengupdate status: " . $e->getMessage()
        ]);
    } finally {
        $koneksi->close();
    }
} else {
    // Respon jika request method bukan POST
    http_response_code(405); // Method Not Allowed
    echo json_encode([
        "success" => false,
        "message" => "Metode HTTP tidak diizinkan."
    ]);
    exit;
}
?>
