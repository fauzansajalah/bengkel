<?php
include '../../_config/koneksi/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_history = $_POST['id_history_booking'];

    $sql = "UPDATE history_booking SET status_pembayaran = 'Sudah Dibayar' WHERE id_history_booking = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('i', $id_history);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengonfirmasi pembayaran.']);
    }

    $stmt->close();
    $koneksi->close();
}
?>
