<?php
include '../../_config/koneksi/koneksi.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "Akses ditolak. Anda harus login sebagai teknisi."]);
    exit;
}

$id_teknisi = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $status_baru = $_POST['status'];

    if (!in_array($status_baru, ['aktif', 'tidak aktif'])) {
        http_response_code(400);
        exit;
    }

    try {
        $query = "UPDATE teknisi SET status = ? WHERE id_teknisi = ?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("si", $status_baru, $id_teknisi);
        $stmt->execute();
        http_response_code(200);
        echo json_encode(["success" => true, "message" => "Status berhasil diperbarui menjadi: " . htmlspecialchars($status_baru)]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Gagal memperbarui status: " . $e->getMessage()]);
    } finally {
        $koneksi->close();
    }
}
?>
