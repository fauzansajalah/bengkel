<?php
include '../../_config/koneksi/koneksi.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    die('Anda harus login sebagai teknisi untuk mengakses fitur ini.');
}

$id_teknisi = $_SESSION['user_id'];

$query = "SELECT e_wallet_id, nomor_e_wallet FROM teknisi WHERE id_teknisi = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param('i', $id_teknisi);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

echo json_encode($data);
$stmt->close();
?>
