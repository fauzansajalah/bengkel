<?php
// Menyertakan file koneksi dan memulai sesi
include '../../_config/koneksi/koneksi.php';
session_start();

// Validasi sesi pengguna
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    die('Anda harus login sebagai teknisi untuk mengakses fitur ini.');
}

// Ambil user_id dari sesi
$user_id = $_SESSION['user_id'];

// Pastikan data foto diterima
if (isset($_POST['foto'])) {
    $foto = $_POST['foto'];

    // Update foto di database menjadi 'teknisi.png'
    $sql = "UPDATE teknisi SET foto = ? WHERE id_teknisi = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("si", $foto, $user_id);
    
    if ($stmt->execute()) {
        // Mengirimkan response sukses jika berhasil
        echo json_encode(['status' => 'success', 'message' => 'Foto berhasil dihapus dan diganti dengan teknisi.png.']);
    } else {
        // Mengirimkan response error jika gagal
        echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat mengupdate foto.']);
    }
    
    $stmt->close();
} else {
    // Jika data foto tidak ditemukan
    echo json_encode(['status' => 'error', 'message' => 'Foto tidak ditemukan.']);
}

$koneksi->close();  // Menutup koneksi
?>
