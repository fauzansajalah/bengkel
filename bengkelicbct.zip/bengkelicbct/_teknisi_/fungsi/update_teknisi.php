<?php
include '../../_config/koneksi/koneksi.php';

// Memulai sesi untuk memastikan bahwa pengguna login
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    echo json_encode(['success' => false, 'error' => 'Anda tidak memiliki izin untuk melakukan perubahan.']);
    exit;
}

// Periksa koneksi database
if (!$koneksi) {
    echo json_encode(['success' => false, 'error' => 'Koneksi database gagal: ' . mysqli_connect_error()]);
    exit;
}

// Ambil ID teknisi dari sesi
$teknisi_id = $_SESSION['user_id'];

// Ambil data dari request body
$data = json_decode(file_get_contents('php://input'), true);

// Validasi data
$fields = ['nama', 'email', 'kategori', 'spesialisasi', 'pengalaman', 'alamat', 'no_hp'];
foreach ($fields as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        echo json_encode(['success' => false, 'error' => "Field $field tidak boleh kosong."]);
        exit;
    }
}

// Filter data untuk menghindari serangan XSS
$nama = htmlspecialchars($data['nama']);
$email = htmlspecialchars($data['email']);
$kategori = htmlspecialchars($data['kategori']);

// Proses spesialisasi untuk menghapus spasi di depan koma
$spesialisasi = $data['spesialisasi'];
$spesialisasi_array = array_map('trim', explode(',', $spesialisasi));
$spesialisasi_clean = implode(',', $spesialisasi_array);

$pengalaman = htmlspecialchars($data['pengalaman']);
$alamat = htmlspecialchars($data['alamat']);
$no_hp = htmlspecialchars($data['no_hp']);

// Query untuk memperbarui data teknisi
$sql = "UPDATE teknisi SET 
        nama = ?, 
        email = ?, 
        kategori = ?, 
        spesialisasi = ?, 
        pengalaman = ?, 
        alamat = ?, 
        no_hp = ? 
        WHERE id_teknisi = ?";

$stmt = $koneksi->prepare($sql);

// Periksa apakah prepare berhasil
if ($stmt === false) {
    echo json_encode(['success' => false, 'error' => 'Gagal mempersiapkan query: ' . $koneksi->error]);
    exit;
}

// Bind parameter
$stmt->bind_param(
    "sssssssi",
    $nama,
    $email,
    $kategori,
    $spesialisasi_clean,
    $pengalaman,
    $alamat,
    $no_hp,
    $teknisi_id
);

// Eksekusi query
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Gagal memperbarui data: ' . $stmt->error]);
}

$stmt->close();
$koneksi->close();
?>
