<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../../_config/koneksi/koneksi.php';
session_start();

// Validasi sesi pengguna
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    die('Anda harus login sebagai teknisi untuk mengakses fitur ini.');
}

// Memeriksa apakah metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_teknisi = $_SESSION['user_id']; // Mengambil ID teknisi dari sesi
    $e_wallet_data = $_POST['nomor_e_wallet'] ?? []; // Data e-wallet dari form

    // Memproses data e-wallet
    $e_wallet_ids = implode(',', array_keys($e_wallet_data));
    $e_wallet_numbers = json_encode($e_wallet_data, JSON_UNESCAPED_UNICODE); // Encode data ke JSON

    // Menggunakan prepared statement untuk keamanan
    $query = "
        UPDATE teknisi 
        SET e_wallet_id = ?, nomor_e_wallet = ? 
        WHERE id_teknisi = ?
    ";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param('ssi', $e_wallet_ids, $e_wallet_numbers, $id_teknisi);

    if ($stmt->execute()) {
        // Pengalihan ke halaman /teknisi/profile
        header('Location: /teknisi/profile');
        exit(); // Menghentikan eksekusi script setelah pengalihan
    } else {
        echo 'Terjadi kesalahan: ' . $stmt->error;
    }

    $stmt->close(); // Menutup prepared statement
}
?>
