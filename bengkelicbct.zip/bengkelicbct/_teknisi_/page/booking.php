<?php
session_start();
include '../../_config/koneksi/koneksi.php';

// Validasi akses teknisi
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    $_SESSION['error_message'] = 'Akses ditolak. Anda harus login sebagai teknisi.';
    header('Location: /');
    exit();
}

$id_teknisi = $_SESSION['user_id'];

// Query untuk mendapatkan data booking pelanggan
$sql = "
    SELECT 
        hb.id_history_booking,
        t.nama AS nama_teknisi,
        p.nama AS nama_pelanggan,
        l.kategori,
        l.menu_layanan,
        l.nama_layanan,
        hb.alamat,
        hb.no_hp,
        CONCAT(hb.tanggal_booking, ' ', hb.pukul) AS waktu_booking,
        hb.tanggal_konfirmasi,
        hb.status_pembayaran,
        hb.konfirmasi_teknisi
    FROM 
        history_booking hb
    JOIN 
        teknisi t ON hb.id_teknisi = t.id_teknisi
    JOIN 
        pelanggan p ON hb.id_pelanggan = p.id_pelanggan
    JOIN 
        layanan l ON hb.id_layanan = l.id_layanan
    WHERE 
        hb.id_teknisi = ?
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id_teknisi);
$stmt->execute();
$result = $stmt->get_result();
$data_booking = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$koneksi->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="/about" class="nav-link" >
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="/teknisi" class="nav-link">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>


<div class="content">
    <div class="container">
        <h2>Pesanan Pelanggan</h2>
        <p>Konfirmasi Pembayaran jika pembayaran dilakukan secara cash.</p>

        <?php
        if (!empty($data_booking)) {
            usort($data_booking, function ($a, $b) {
                return $b['id_history_booking'] - $a['id_history_booking']; // Urutkan dari ID terbesar
            });
        }
        ?>

        <?php if (!empty($data_booking)): ?>
            <?php foreach ($data_booking as $booking): ?>
                <div class="card">
                    <h2>Booking Service</h2>
                    <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($booking['nama_teknisi']) ?></p>
                    <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($booking['nama_pelanggan']) ?></p>
                    <p><strong>Layanan:</strong> <?= htmlspecialchars($booking['kategori']) ?> - <?= htmlspecialchars($booking['menu_layanan']) ?> - <?= htmlspecialchars($booking['nama_layanan']) ?></p>
                    <p><strong>Alamat:</strong> <?= htmlspecialchars($booking['alamat']) ?></p>
                    <p><strong>No. HP:</strong> <?= htmlspecialchars($booking['no_hp']) ?></p>
                    <p><strong>Waktu Booking:</strong> <?= htmlspecialchars($booking['waktu_booking']) ?></p>
                    <p><strong>Status Konfirmasi:</strong> <?= htmlspecialchars($booking['konfirmasi_teknisi']) ?></p>
                    <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($booking['status_pembayaran']) ?></p>

                    <?php if ($booking['konfirmasi_teknisi'] === 'Belum Dikonfirmasi'): ?>
                        <button class="confirm-button" data-id="<?= $booking['id_history_booking'] ?>">Konfirmasi Booking</button>
                    <?php endif; ?>

                    <?php if ($booking['konfirmasi_teknisi'] === 'Dikonfirmasi' && $booking['status_pembayaran'] !== 'Sudah Dibayar'): ?>
                        <button class="confirm-pembayaran-button" data-id="<?= $booking['id_history_booking'] ?>">Konfirmasi Pembayaran</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Tidak ada booking untuk teknisi ini.</p>
        <?php endif; ?>
    </div>
</div>

    <!-- Bottom Menu -->
    <div class="bottom-menu">
        <a href="/teknisi" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="/teknisi/service" class="menu-item">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="/teknisi/booking" class="menu-item active">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="/teknisi/history" class="menu-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="/teknisi/profile" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>
    
    <script>
        // Konfirmasi Pesanan
document.querySelectorAll('.confirm-button').forEach(button => {
    button.addEventListener('click', () => {
        const idHistoryBooking = button.getAttribute('data-id');
        console.log('ID History Booking:', idHistoryBooking); // Debugging

        // SweetAlert konfirmasi
        Swal.fire({
            title: 'Konfirmasi Pesanan',
            text: "Apakah Anda yakin ingin mengonfirmasi pesanan ini?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Konfirmasi'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim permintaan ke server untuk mengupdate status
                fetch('../_teknisi_/fungsi/update_konfirmasi_booking.php', {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/x-www-form-urlencoded' 
                    },
                    body: `id_history_booking=${encodeURIComponent(idHistoryBooking)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: 'Berhasil!',
                            html: `${data.message || 'Pesanan berhasil dikonfirmasi.'}<br>Jangan lupa tanggal booking nya ya.`,
                            icon: 'success'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire(
                            'Gagal!',
                            data.message || 'Terjadi kesalahan saat mengonfirmasi pesanan.',
                            'error'
                        );
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire(
                        'Kesalahan!',
                        'Tidak dapat menghubungi server. Silakan coba lagi nanti.',
                        'error'
                    );
                });
            }
        });
    });
});

document.querySelectorAll('.confirm-pembayaran-button').forEach(button => {
  const idHistoryBooking = button.getAttribute('data-id');
  const card = button.closest('.card');
  const statusPembayaran = card.querySelector('p:nth-child(9) strong');

  if (statusPembayaran) {
    const text = statusPembayaran.textContent.trim();
    if (text === 'Sudah Dibayar') {
      button.style.display = 'none';
    } else {
      button.style.display = 'block';
    }
  }

  // Tambahkan event listener untuk konfirmasi pembayaran
  button.addEventListener('click', () => {
    Swal.fire({
      title: 'Konfirmasi Pembayaran',
      text: "Apakah Anda yakin ingin mengonfirmasi pembayaran ini?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Konfirmasi'
    }).then((result) => {
      if (result.isConfirmed) {
        fetch('../_teknisi_/fungsi/konfirmasi_pembayaran_booking.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `id_history_booking=${encodeURIComponent(idHistoryBooking)}`
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            button.remove(); // Hapus tombol
            Swal.fire({
              title: 'Berhasil!',
              html: `${data.message || 'Pembayaran berhasil dikonfirmasi.'}`,
              icon: 'success',
              confirmButtonText: 'OK' // Menambahkan tombol OK
            }).then(() => {
              window.location.href = window.location.href; // Reload halaman setelah OK diklik
            });
          } else {
            Swal.fire({
              title: 'Gagal!',
              text: data.message || 'Terjadi kesalahan saat mengonfirmasi pembayaran.',
              icon: 'error'
            });
          }
        })
        .catch(error => {
          console.error('Error:', error);
          Swal.fire({
            title: 'Kesalahan!',
            text: 'Tidak dapat menghubungi server. Silakan coba lagi nanti.',
            icon: 'error'
          });
        });
      }
    });
  });
});

    </script>
<!-- JavaScript Libraries -->
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>