<?php
include '../../_config/koneksi/koneksi.php';

// Mulai sesi
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cek akses teknisi
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    $_SESSION['error_message'] = 'Akses ditolak. Anda harus login sebagai teknisi.';
    header('Location: /'); // Redirect ke root directory
    exit();
}

$id_teknisi = $_SESSION['user_id'];

try {
    $query = "SELECT id_teknisi, nama, status FROM teknisi WHERE id_teknisi = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id_teknisi);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $teknisi = $result->fetch_assoc();
    } else {
        echo json_encode(["success" => false, "message" => "Data teknisi tidak ditemukan."]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Query gagal: " . $e->getMessage()]);
} finally {
    if ($koneksi->ping()) {
        $koneksi->close();
}
}
?>



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>

        /* Container untuk toggle switch */
.toggle-switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
}

/* Input yang disembunyikan */
.toggle-input {
    opacity: 0;
    width: 0;
    height: 0;
}

/* Label sebagai toggle switch */
.toggle-label {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    border-radius: 34px;
    transition: background-color 0.4s;
}

/* Lingkaran di dalam switch */
.toggle-slider {
    position: absolute;
    height: 26px;
    width: 26px;
    background-color: white;
    border-radius: 50%;
    top: 4px;
    left: 4px;
    transition: transform 0.4s;
}

/* Warna saat aktif */
.toggle-input:checked + .toggle-label {
    background-color: #b30000;
}

/* Posisi lingkaran saat aktif */
.toggle-input:checked + .toggle-label .toggle-slider {
    transform: translateX(26px);
}

    </style>
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="/about" class="nav-link">
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="/teknisi" class="nav-link">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>


<div class="content">
    <div class="container">
        <br>
        <div class="container">
            <h3 id="greeting-message"></h3>
        <h2>Status Teknisi: <?php echo isset($teknisi['nama']) ? htmlspecialchars($teknisi['nama']) : 'Tidak Ditemukan'; ?></h2>
        <?php if ($teknisi): ?>
        <div class="form-group">
            <label for="status">Status:</label>
            <div class="toggle-switch">
                <input 
                    type="checkbox" 
                    id="status" 
                    name="status" 
                    class="toggle-input" 
                    value="aktif" 
                    <?php echo (isset($teknisi['status']) && $teknisi['status'] == 'aktif') ? 'checked' : ''; ?>
                    onchange="updateStatus(this.checked)"
                >
                <label for="status" class="toggle-label">
                    <span class="toggle-slider"></span>
                </label>
            </div>
        </div>
        
        <!-- Pesan Dinamis Berdasarkan Status -->
        <div id="status-message">
            <?php if (isset($teknisi['status']) && $teknisi['status'] == 'aktif'): ?>
                <p style="color: green;">Akun kamu sedang aktif.</p>
                <p>Jika akun sedang aktif, akun kamu akan bisa dipesan dengan metode service langsung maupun booking.</p>
            <?php else: ?>
                <p style="color: red;">Akun kamu sedang tidak aktif.</p>
                <p>Jika akun sedang tidak aktif, akun kamu hanya akan bisa dipesan dengan metode booking dan tidak akan bisa diakses untuk menu service langsung.</p>
            <?php endif; ?>
        </div>
        </div>
        <br>
            <div class="container">
                <p>Ini adalah aplikasi bengkel dengan metode teknisi ke pelanggan, disini bisa memesan dengan 2 metode yaitu:</p>
                <ul>
                    <li>
                        <strong>Service langsung:</strong> Ketika pelanggan memesan layanan jasa tersebut, teknisi akan datang ke pelanggan saat itu juga.
                    </li>
                    <br>
                    <li>
                        <strong>Booking:</strong> Waktu kedatangan teknisi ke pelanggan diatur oleh pelanggan, tentunya memakai persetujuan dari teknisi dulu.
                    </li>
                </ul>
            </div>
            <!-- Container Baru -->
            <br>
<div class="container">
<div id="realTimeClock" style="font-size: 1.5em; font-weight: bold; margin: 10px auto; text-align: center; display: block; color:#555;"></div>
    </div>
        <?php else: ?>
            <p style="color: red;">Data teknisi tidak tersedia.</p>
        <?php endif; ?>
    </div>
</div>

<script>

function updateClock() {
    const clockElement = document.getElementById('realTimeClock');
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    clockElement.textContent = `${hours}:${minutes}:${seconds}`;
}

// Update clock every second
setInterval(updateClock, 1000);
// Initialize clock immediately
updateClock();

document.addEventListener('DOMContentLoaded', () => {
    const greetingMessage = document.getElementById('greeting-message');

    // Ambil jam saat ini
    const hours = new Date().getHours();

    // Tentukan pesan berdasarkan waktu
    let greeting;
    if (hours >= 5 && hours < 12) {
        greeting = 'Selamat Pagi';
    } else if (hours >= 12 && hours < 15) {
        greeting = 'Selamat Siang';
    } else if (hours >= 15 && hours < 18) {
        greeting = 'Selamat Sore';
    } else {
        greeting = 'Selamat Malam';
    }

    // Tampilkan pesan
    greetingMessage.textContent = `${greeting}, Teknisi!`;
});
    
function updateStatus(isChecked) {
    const status = isChecked ? 'aktif' : 'tidak aktif';
    fetch('_teknisi_/fungsi/update_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `status=${status}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Perbarui pesan dinamis berdasarkan status
            const statusMessage = document.getElementById('status-message');
            if (isChecked) {
                statusMessage.innerHTML = `
                    <p style="color: green;">Akun kamu sedang aktif.</p>
                    <p>*Jika akun sedang aktif, akun kamu akan bisa dipesan dengan metode service langsung maupun booking.</p>
                `;
            } else {
                statusMessage.innerHTML = `
                    <p style="color: red;">Akun kamu sedang tidak aktif.</p>
                    <p>*Jika akun sedang tidak aktif, akun kamu hanya akan bisa dipesan dengan metode booking dan tidak akan bisa dipesan untuk menu service langsung.</p>
                `;
            }
            // SweetAlert untuk sukses
            Swal.fire({
                title: 'Berhasil!',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'OK'
            });
        } else {
            // SweetAlert untuk error
            Swal.fire({
                title: 'Gagal!',
                text: data.message,
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    })
    .catch(error => {
        console.error('Terjadi kesalahan koneksi.');
        // SweetAlert untuk kesalahan koneksi
        Swal.fire({
            title: 'Error!',
            text: 'Terjadi kesalahan koneksi.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
    });
}
</script>



    <!-- Bottom Menu -->
    <div class="bottom-menu">
    <a href="/teknisi" class="menu-item active">
        <i class="fas fa-home"></i>
        <span>Home</span>
    </a>
        <a href="/teknisi/service" class="menu-item">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="/teknisi/booking" class="menu-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="/teknisi/history" class="menu-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="/teknisi/profile" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>
    

    
<!-- JavaScript Libraries -->
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>