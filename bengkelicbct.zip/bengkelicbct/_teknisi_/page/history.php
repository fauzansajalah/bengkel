<?php
include '../../_config/koneksi/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="/about" class="nav-link" >
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="/teknisi" class="nav-link">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>

        <!-- Content -->
    <div class="content">
        <div class="container">
            <h2>History Teknisi</h2>
        <?php
// Koneksi ke database
include('../../_config/koneksi/koneksi.php');

// Menjalankan query untuk mendapatkan data history
$query = "
SELECT 
  hp.id_history, 
  hp.id_transaksi, 
  hp.id_pelanggan, 
  hp.id_teknisi, 
  hp.id_layanan, 
  hp.alamat AS alamat_pelanggan, 
  hp.no_hp AS no_hp_pelanggan, 
  hp.tanggal_konfirmasi AS konfirmasi_pelanggan, 
  hp.status_pembayaran AS status_pembayaran_pelanggan, 
  hp.harga, 
  hp.konfirmasi_teknisi AS konfirmasi_teknisi_pelanggan,
  hb.id_history_booking,
  hb.id_teknisi AS id_teknisi_booking,
  hb.id_layanan AS id_layanan_booking,
  hb.alamat AS alamat_booking,
  hb.no_hp AS no_hp_booking,
  hb.tanggal_booking,
  hb.pukul,
  hb.tanggal_konfirmasi AS konfirmasi_booking,
  hb.status_pembayaran AS status_pembayaran_booking,
  hb.konfirmasi_teknisi AS konfirmasi_teknisi_booking,
  p.nama AS nama_pelanggan,
  t.nama AS nama_teknisi,
  l.kategori,
  l.menu_layanan,
  l.nama_layanan
FROM 
  history_pelanggan hp
  LEFT JOIN history_booking hb ON hp.id_pelanggan = hb.id_pelanggan
  LEFT JOIN pelanggan p ON hp.id_pelanggan = p.id_pelanggan
  LEFT JOIN teknisi t ON hp.id_teknisi = t.id_teknisi
  LEFT JOIN layanan l ON hp.id_layanan = l.id_layanan
WHERE 
  hp.konfirmasi_teknisi = 'Dikonfirmasi' 
  AND hb.konfirmasi_teknisi = 'Dikonfirmasi'
ORDER BY 
  hp.id_history DESC;

";

// Eksekusi query
$result = mysqli_query($koneksi, $query);

// Mengecek apakah data ditemukan
if (mysqli_num_rows($result) > 0) {
    // Menampilkan data dalam bentuk kartu
    while ($row = mysqli_fetch_assoc($result)) {
        ?>
<div class="card">
  <h2>Service Langsung</h2>
  <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($row['nama_teknisi']) ?></p>
  <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($row['nama_pelanggan']) ?></p>
  <p><strong>Layanan:</strong> <?= htmlspecialchars($row['kategori']) ?> - <?= htmlspecialchars($row['menu_layanan']) ?> - <?= htmlspecialchars($row['nama_layanan']) ?></p>
  <p><strong>Harga:</strong> Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
  <p><strong>Alamat:</strong> <?= htmlspecialchars($row['alamat_pelanggan']) ?></p>
  <p><strong>Status Konfirmasi:</strong> <?= htmlspecialchars($row['konfirmasi_teknisi_pelanggan']) ?></p>
  <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($row['status_pembayaran_pelanggan']) ?></p>
</div>

  <div class="card">
    <h2>Booking Service</h2>
    <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($row['nama_teknisi']) ?></p>
    <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($row['nama_pelanggan']) ?></p>
    <p><strong>Layanan:</strong> <?= htmlspecialchars($row['kategori']) ?> - <?= htmlspecialchars($row['menu_layanan']) ?> - <?= htmlspecialchars($row['nama_layanan']) ?></p>
    <p><strong>Alamat:</strong> <?= htmlspecialchars($row['alamat_booking']) ?></p>
    <p><strong>No. HP:</strong> <?= htmlspecialchars($row['no_hp_booking']) ?></p>
    <p><strong>Waktu Booking:</strong> <?= htmlspecialchars($row['tanggal_booking']) ?> <?= htmlspecialchars($row['pukul']) ?></p>
    <p><strong>Status Konfirmasi:</strong> <?= htmlspecialchars($row['konfirmasi_teknisi_booking']) ?></p>
    <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($row['status_pembayaran_booking']) ?></p>
  </div>

        <?php
    }
} else {
    echo "Tidak ada data yang ditemukan.";
}
?>

        </div>
    </div>
    
    <!-- Bottom Menu -->
    <div class="bottom-menu">
        <a href="/teknisi" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="/teknisi/service" class="menu-item">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="/teknisi/booking" class="menu-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="/teknisi/history" class="menu-item active">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="/teknisi/profile" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>
    
<!-- JavaScript Libraries -->
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>