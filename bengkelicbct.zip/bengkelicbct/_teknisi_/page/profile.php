<?php
include '../../_config/koneksi/koneksi.php';

// Memulai sesi untuk akses data login
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    $_SESSION['error_message'] = 'Akses ditolak. Anda harus login sebagai teknisi.';
    header('Location: /'); // Redirect ke root directory
    exit();
}

// Periksa koneksi database
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil ID teknisi dari sesi login
$teknisi_id = $_SESSION['user_id'];

// Query untuk mengambil data teknisi
$sql = "SELECT foto, email, nama, kategori, spesialisasi, pengalaman, alamat, no_hp 
        FROM teknisi WHERE id_teknisi = ?";
$stmt = $koneksi->prepare($sql);

// Cek jika prepare() gagal
if ($stmt === false) {
    die("Gagal mempersiapkan query: " . $koneksi->error);
}

$stmt->bind_param("i", $teknisi_id);
$stmt->execute();
$result = $stmt->get_result();

$teknisi_data = null;
if ($result->num_rows > 0) {
    // Ambil data teknisi
    $teknisi_data = $result->fetch_assoc();
}

$stmt->close();
$koneksi->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="/about" class="nav-link" >
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="/teknisi" class="nav-link">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>

<div class="content">
        <div class="container">
            <?php if ($teknisi_data): ?>
                <div class="profile-card">
                    <h2>Profil Teknisi</h2>
                <div class="profile-header">
    <img src="../../path_to_images/<?= htmlspecialchars($teknisi_data['foto']) ?>" 
         alt="Foto Teknisi" id="profile-photo">

    <!-- Modal untuk Profile Menu -->
    <div id="profileMenu" class="modal">
        <div class="modal-content">
            <button class="btn btn-edit" id="viewProfileBtn">Lihat Profil</button>
            <button class="btn btn-edit" id="changeProfileBtn">Ganti Profil</button>
        </div>
    </div>

    <!-- Modal untuk Lihat Profil -->
    <div id="viewProfileModal" class="modal">
        <div class="modal-content">
            <img src="../../path_to_images/<?= htmlspecialchars($teknisi_data['foto']) ?>" 
                 alt="Foto Teknisi Besar" class="profile-large-photo">
        </div>
    </div>

    <!-- Modal untuk Ganti Profil -->
    <div id="changeProfileModal" class="modal">
    <div class="modal-content" style="position: relative;">
        <!-- Ikon Sampah -->
        <i class="fa fa-trash close-btn" onclick="deletePhoto()" style="font-size: 20px; position: absolute; top: 10px; right: 10px; cursor: pointer;"></i>
        <h2 style="margin-right: 40px;">Ganti Foto Profil</h2>
        <form id="changeProfileForm">
            <input type="file" name="foto" required>
            <button type="submit">Simpan</button>
        </form>
    </div>
</div>


</div>

                    <div class="profile-details" id="profile-details">
                        <p><strong>Nama:</strong> <span id="nama"><?= htmlspecialchars($teknisi_data['nama']) ?></span></p>
                        <p><strong>Email:</strong> <span id="email"><?= htmlspecialchars($teknisi_data['email']) ?></span></p>
                        <p><strong>Kategori:</strong> <span id="kategori"><?= htmlspecialchars($teknisi_data['kategori']) ?></span></p>
                        <p><strong>Spesialisasi:</strong> <span id="spesialisasi"><?= htmlspecialchars($teknisi_data['spesialisasi']) ?></span></p>
                        <p><strong>Pengalaman:</strong> <span id="pengalaman"><?= htmlspecialchars($teknisi_data['pengalaman']) ?></span></p>
                        <p><strong>Alamat:</strong> <span id="alamat"><?= htmlspecialchars($teknisi_data['alamat']) ?></span></p>
                        <p><strong>No HP:</strong> <span id="no_hp"><?= htmlspecialchars($teknisi_data['no_hp']) ?></span></p>
                    </div>
                    <div class="btn-container">
                        <button class="btn btn-edit" onclick="enableEdit()">Edit</button>
                        <a href="javascript:void(0);" id="logoutLink" class="btn-logout">Logout</a>
                    </div>
                    <div class="edit-buttons" style="display:none;">
    <button class="btn btn-edit" onclick="saveChanges()">Simpan</button>
    <button class="btn-cancel" onclick="cancelEdit()">Batal</button>
  </div>

                </div>
                <button class="btn-modal" id="addEWalletBtn">E-Wallet</button>
            <?php else: ?>
                <p>Data teknisi tidak ditemukan.</p>
            <?php endif; ?>
        </div>
    </div>


    <div id="eWalletModal" class="modal" style="display: none;">
    <div class="container">
        <h2>Tambah E-Wallet</h2>

        <form id="eWalletForm" action="../_teknisi_/fungsi/update_e-wallet.php" method="POST">
            <div>
                <label><input type="checkbox" class="e_wallet_checkbox" value="1" data-name="GoPay"> GoPay</label><br>
                <label><input type="checkbox" class="e_wallet_checkbox" value="2" data-name="OVO"> OVO</label><br>
                <label><input type="checkbox" class="e_wallet_checkbox" value="3" data-name="DANA"> DANA</label><br>
                <label><input type="checkbox" class="e_wallet_checkbox" value="4" data-name="ShopeePay"> ShopeePay</label><br>
                <label><input type="checkbox" class="e_wallet_checkbox" value="5" data-name="LinkAja"> LinkAja</label><br>
            </div>
            <div id="e_wallet_numbers"></div>
            <button type="submit" class="btn-modal">Simpan</button>
            <button type="button" class="btn-modal" onclick="closeModal()">Tutup</button>
        </form>
    </div>
</div>


    <!-- Bottom Menu -->
    <div class="bottom-menu">
        <a href="/teknisi" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="/teknisi/service" class="menu-item">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="/teknisi/booking" class="menu-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="/teknisi/history" class="menu-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="/teknisi/profile" class="menu-item active">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>

    <script>
 // Fungsi untuk mengaktifkan edit
 function enableEdit() {
    const fields = ['nama', 'email', 'kategori', 'spesialisasi', 'pengalaman', 'alamat', 'no_hp'];

    fields.forEach(field => {
        const span = document.getElementById(field);
        const currentValue = span.textContent.trim();

        let input;
        if (field === 'spesialisasi') {
            input = document.createElement('div');
            input.id = field;
            const options = ['perbaikan','perawatan','kustom','inspeksi','suku cadang','darurat','diagnostik','cuci'];
            const selectedOptions = currentValue.split(',').map(opt => opt.trim());
            options.forEach(option => {
                const label = document.createElement('label');
                label.classList.add('specialization-option');
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.value = option;
                if (selectedOptions.includes(option)) {
                    checkbox.checked = true;
                }
                label.appendChild(checkbox);
                const spanText = document.createElement('span');
                spanText.textContent = option;
                label.appendChild(spanText);
                input.appendChild(label);
            });
        } else if (field === 'kategori') {
            input = document.createElement('select');
            input.id = field;
            const options = ['motor', 'mobil'];
            options.forEach(option => {
                const optElement = document.createElement('option');
                optElement.value = option;
                optElement.textContent = option;
                if (option === currentValue) {
                    optElement.selected = true;
                }
                input.appendChild(optElement);
            });
        } else {
            input = document.createElement('input');
            input.type = 'text';
            input.value = currentValue;
            input.id = field;
        }
        span.parentNode.replaceChild(input, span);
    });

    // Sembunyikan div btn-container
    document.querySelector('.btn-container').style.display = 'none';
    document.querySelector('.edit-buttons').style.display = 'flex';
    
}

function cancelEdit() {
    location.reload(); // Refresh halaman untuk membatalkan perubahan
}

// Fungsi untuk menyimpan perubahan
function saveChanges() {
    const fields = ['nama', 'email', 'kategori', 'spesialisasi', 'pengalaman', 'alamat', 'no_hp'];
    const data = {};

    fields.forEach(field => {
        const input = document.getElementById(field);

        if (field === 'spesialisasi') {
            // Ambil semua nilai spesialisasi yang tercentang (checkbox)
            const selectedSpesialisasi = Array.from(input.querySelectorAll('input[type="checkbox"]:checked'))
                                              .map(checkbox => checkbox.value);
            data[field] = selectedSpesialisasi.join(', '); // Gabungkan dengan koma
        } else if (field === 'kategori') {
            // Ambil kategori yang dipilih (dropdown)
            data[field] = input.value;
        } else {
            // Untuk field lainnya, ambil nilai dari input
            data[field] = input.value.trim();
        }
    });

fetch('../_teknisi_/fungsi/update_teknisi.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
})
.then(response => response.text())  // Gunakan text() untuk melihat raw response
.then(result => {
    console.log(result);  // Cek apakah ini JSON atau HTML error page
    try {
        const jsonResult = JSON.parse(result);  // Parsing ke JSON
        if (jsonResult.success) {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil diperbarui!',
                showConfirmButton: true
            }).then(() => {
                location.reload(); // Reload halaman setelah SweetAlert ditutup
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: 'Gagal memperbarui data: ' + jsonResult.error,
                showConfirmButton: true
            });
        }
    } catch (error) {
        console.error("Error parsing JSON: ", error);
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Respon server tidak valid: ' + result,
            showConfirmButton: true
        });
    }
})
.catch(error => {
    Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Terjadi kesalahan: ' + error.message,
        showConfirmButton: true
    });
});
}

    // Menambahkan event listener untuk link logout
    document.getElementById('logoutLink').addEventListener('click', function(e) {
        // Mencegah link default agar tidak langsung melakukan redirect
        e.preventDefault();

        // Menampilkan SweetAlert konfirmasi
        Swal.fire({
            title: 'Apakah Anda yakin ingin logout?',
            text: "Anda akan keluar dari akun Anda.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Logout',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika pengguna mengonfirmasi logout, lakukan POST request
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = '/logout'; // Arahkan ke halaman logout
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'logout';
                input.value = 'true';
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        });
    });

    document.getElementById('addEWalletBtn').addEventListener('click', async () => {
    const eWalletNumbersContainer = document.getElementById('e_wallet_numbers');
    const eWalletCheckboxes = document.querySelectorAll('.e_wallet_checkbox');

    try {
        // Fetch data dari server
        const response = await fetch('../_teknisi_/fungsi/get_e_wallet.php');
        const data = await response.json();

        // Proses data e-wallet dari server
        const eWalletIds = data.e_wallet_id ? data.e_wallet_id.split(',') : [];
        const eWalletNumbers = data.nomor_e_wallet ? JSON.parse(data.nomor_e_wallet) : {};

        // Bersihkan form nomor e-wallet sebelumnya
        eWalletNumbersContainer.innerHTML = '';

        eWalletCheckboxes.forEach((checkbox) => {
            // Tandai checkbox jika sesuai dengan data dari server
            checkbox.checked = eWalletIds.includes(checkbox.value);

            // Aktifkan input teks jika checkbox dicentang
            if (checkbox.checked) {
                const walletName = checkbox.getAttribute('data-name');
                const walletId = checkbox.value;

                // Cek jika input sebelumnya ada, hapus untuk mencegah duplikasi
                const existingInput = document.getElementById(`wallet_${walletId}`);
                if (existingInput) {
                    existingInput.remove();
                }

                // Buat elemen input baru
                const input = document.createElement('div');
                input.setAttribute('id', `wallet_${walletId}`);
                input.innerHTML = `
                    <label for="wallet_${walletId}_number">Nomor ${walletName}:</label>
                    <input type="text" name="nomor_e_wallet[${walletId}]" id="wallet_${walletId}_number" value="${eWalletNumbers[walletId] || ''}" required><br>
                `;
                eWalletNumbersContainer.appendChild(input);
            }
        });

        // Tampilkan modal
        document.getElementById('eWalletModal').style.display = 'flex';
    } catch (error) {
        console.error('Gagal memuat data e-wallet:', error);
    }
});


document.querySelectorAll('.e_wallet_checkbox').forEach((checkbox) => {
    checkbox.addEventListener('change', function () {
        const eWalletNumbersContainer = document.getElementById('e_wallet_numbers');
        const walletName = this.getAttribute('data-name');
        const walletId = this.value;

        if (this.checked) {
            if (!document.getElementById(`wallet_${walletId}`)) {
                const input = document.createElement('div');
                input.setAttribute('id', `wallet_${walletId}`);
                input.innerHTML = `
                    <label for="wallet_${walletId}_number">Nomor ${walletName}:</label>
                    <input type="text" name="nomor_e_wallet[${walletId}]" id="wallet_${walletId}_number" required><br>
                `;
                eWalletNumbersContainer.appendChild(input);
            }
        } else {
            const walletInput = document.getElementById(`wallet_${walletId}`);
            if (walletInput) walletInput.remove();
        }
    });
});

// Fungsi untuk menutup modal
function closeModal() {
    const eWalletModal = document.getElementById('eWalletModal');
    eWalletModal.style.display = 'none';
}

document.getElementById('eWalletForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Mencegah form langsung dikirim

        // Ambil data form
        const formData = new FormData(this);

        // Kirim data ke server dengan fetch
        fetch(this.action, {
            method: 'POST',
            body: formData,
        })
        .then(response => response.text())
        .then(data => {
            // Tampilkan pemberitahuan sukses
            Swal.fire({
                title: 'Berhasil!',
                text: 'Data e-wallet berhasil diperbarui.',
                icon: 'success',
                confirmButtonText: 'OK',
            }).then(() => {
                // Tutup modal setelah SweetAlert ditutup
                closeModal();
            });
        })
        .catch(error => {
            // Tampilkan pemberitahuan error
            Swal.fire({
                title: 'Gagal!',
                text: 'Terjadi kesalahan saat memperbarui data.',
                icon: 'error',
                confirmButtonText: 'Coba Lagi',
            });
        });
    });
    const profilePhoto = document.getElementById('profile-photo');
const profileMenu = document.getElementById('profileMenu');
const viewProfileBtn = document.getElementById('viewProfileBtn');
const changeProfileBtn = document.getElementById('changeProfileBtn');

const viewProfileModal = document.getElementById('viewProfileModal');
const changeProfileModal = document.getElementById('changeProfileModal');

// Buka modal saat gambar profil diklik
profilePhoto.addEventListener('click', () => {
    profileMenu.style.display = 'flex';
});

// Lihat profil
viewProfileBtn.addEventListener('click', () => {
    profileMenu.style.display = 'none';
    viewProfileModal.style.display = 'flex';
});

// Ganti profil
changeProfileBtn.addEventListener('click', () => {
    profileMenu.style.display = 'none';
    changeProfileModal.style.display = 'flex';
});

// Tutup modal jika klik di luar modal-content
window.addEventListener('click', (event) => {
    if (event.target === profileMenu) {
        profileMenu.style.display = 'none';
    }
    if (event.target === viewProfileModal) {
        viewProfileModal.style.display = 'none';
    }
    if (event.target === changeProfileModal) {
        changeProfileModal.style.display = 'none';
    }
});

document.getElementById('changeProfileForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append('id_teknisi', <?= json_encode($_SESSION['user_id']) ?>);

    fetch('../_teknisi_/fungsi/update_foto_profile.php', {
    method: 'POST',
    body: formData
})
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parsing JSON
    })
    .then(data => {
        if (data.status === 'success') {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: data.message,
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: data.message,
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Kesalahan Server',
            text: 'Terjadi kesalahan saat mengunggah foto. Silakan coba lagi.',
        });
    });

});

function deletePhoto() {
    // Tampilkan SweetAlert konfirmasi
    Swal.fire({
        icon: 'warning',
        title: 'Apakah Anda yakin?',
        text: 'Foto profil akan dihapus dan diganti dengan foto default.',
        showCancelButton: true,
        cancelButtonText: 'Batal',
        confirmButtonText: 'Ya, hapus',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // Kirim request ke server untuk menghapus foto dan menggantinya dengan 'teknisi.png'
            const xhr = new XMLHttpRequest();
            xhr.open('POST', '../_teknisi_/fungsi/delete_foto_profil.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            
            // Kirim data foto yang dihapus
            xhr.send('foto=teknisi.png');
            
            xhr.onload = function() {
                if (xhr.status == 200) {
                    // Langsung reload halaman setelah foto dihapus
                    location.reload();
                } else {
                    // Tampilkan SweetAlert untuk error
                    Swal.fire({
                        icon: 'error',
                        title: 'Terjadi kesalahan',
                        text: 'Foto profil gagal dihapus.',
                    });
                }
            };
        }
    });
}




    </script>
<!-- JavaScript Libraries -->
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>