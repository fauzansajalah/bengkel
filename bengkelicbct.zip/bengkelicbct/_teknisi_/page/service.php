<?php
session_start();
include '../../_config/koneksi/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'teknisi') {
    $_SESSION['error_message'] = 'Akses ditolak. Anda harus login sebagai teknisi.';
    header('Location: /'); // Redirect ke root directory
    exit();
}

// Ambil ID teknisi yang login
$id_teknisi = $_SESSION['user_id'];

// Query untuk mendapatkan data pesanan pelanggan
$sql = "
    SELECT 
        h.id_history,
        t.nama AS nama_teknisi,
        p.nama AS nama_pelanggan,
        l.kategori,
        l.menu_layanan,
        l.nama_layanan,
        h.harga,
        h.alamat,
        h.konfirmasi_teknisi,
        h.status_pembayaran
    FROM 
        history_pelanggan h
    JOIN 
        teknisi t ON h.id_teknisi = t.id_teknisi
    JOIN 
        pelanggan p ON h.id_pelanggan = p.id_pelanggan
    JOIN 
        layanan l ON h.id_layanan = l.id_layanan
    WHERE 
        h.id_teknisi = ?
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id_teknisi);
$stmt->execute();
$result = $stmt->get_result();

// Ambil semua data
$data_pesanan = $result->fetch_all(MYSQLI_ASSOC);

// Tutup koneksi
$stmt->close();
$koneksi->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="/about" class="nav-link">
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="/teknisi" class="nav-link">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>

<div class="content">
    <div class="container">
        <h2>Pesanan Pelanggan</h2>
        <p>konfirmasi pembayaran jika pembayaran dilakukan secara cash</p>
        
        <?php
        // Cek jika $data_pesanan tidak kosong
        if (!empty($data_pesanan)) {
            // Mengurutkan data pesanan berdasarkan ID history secara menurun (ID terbesar di atas)
            usort($data_pesanan, function($a, $b) {
                return $b['id_history'] - $a['id_history'];
            });
        }
        ?>

        <?php if (!empty($data_pesanan)): ?>
            <?php foreach ($data_pesanan as $pesanan): ?>
                <div class="card">
                    <h2>Service Langsung</h2>
                    <p><strong>Nama Teknisi:</strong> <?= htmlspecialchars($pesanan['nama_teknisi']) ?></p>
                    <p><strong>Nama Pelanggan:</strong> <?= htmlspecialchars($pesanan['nama_pelanggan']) ?></p>
                    <p><strong>Layanan:</strong> <?= htmlspecialchars($pesanan['kategori']) ?> - <?= htmlspecialchars($pesanan['menu_layanan']) ?> - <?= htmlspecialchars($pesanan['nama_layanan']) ?></p>
                    <p><strong>Harga:</strong> Rp <?= number_format($pesanan['harga'], 0, ',', '.') ?></p>
                    <p><strong>Alamat:</strong> <?= htmlspecialchars($pesanan['alamat']) ?></p>
                    <p><strong>Status Konfirmasi:</strong> <?= htmlspecialchars($pesanan['konfirmasi_teknisi']) ?></p>
                    <p><strong>Status Pembayaran:</strong> <?= htmlspecialchars($pesanan['status_pembayaran']) ?></p>

                    <?php if ($pesanan['konfirmasi_teknisi'] === 'Belum Dikonfirmasi'): ?>
                        <button class="confirm-button" data-id="<?= $pesanan['id_history'] ?>">Konfirmasi Pesanan</button>
                    <?php endif; ?>

                    <?php if ($pesanan['konfirmasi_teknisi'] === 'Dikonfirmasi' && $pesanan['status_pembayaran'] !== 'Sudah Dibayar'): ?>
                        <button class="confirm-pembayaran-button" data-id="<?= $pesanan['id_history'] ?>">Konfirmasi Pembayaran</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Tidak ada pesanan untuk teknisi ini.</p>
        <?php endif; ?>
    </div>
</div>


    <script>
document.querySelectorAll('.confirm-button').forEach(button => {
    button.addEventListener('click', () => {
        const idHistory = button.getAttribute('data-id');
        console.log('ID History:', idHistory); // Debugging

        // SweetAlert konfirmasi
        Swal.fire({
            title: 'Konfirmasi Pesanan',
            text: "Apakah Anda yakin ingin mengonfirmasi pesanan ini?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Konfirmasi'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim permintaan ke server untuk mengupdate status
                fetch('../_teknisi_/fungsi/update_konfirmasi.php', {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/x-www-form-urlencoded' 
                    },
                    body: `id_history=${encodeURIComponent(idHistory)}`
                })
                .then(response => {
                    console.log('Response:', response);
                    return response.json();
                })
                .then(data => {
    console.log('Parsed JSON:', data);
    // SweetAlert berdasarkan hasil
    if (data.success) {
        Swal.fire({
            title: 'Berhasil!',
            html: `${data.message || 'Pesanan berhasil dikonfirmasi.'}<br>Segera pergi ke alamat tujuan.`,
            icon: 'success'
        }).then(() => {
            // Reload halaman atau aksi lain setelah berhasil
            location.reload();
        });
    } else {
        Swal.fire(
            'Gagal!',
            data.message || 'Terjadi kesalahan saat mengonfirmasi pesanan.',
            'error'
        );
    }
})

                .catch(error => {
                    console.error('Error parsing JSON:', error);
                    Swal.fire(
                        'Kesalahan!',
                        'Tidak dapat menghubungi server. Silakan coba lagi nanti.',
                        'error'
                    );
                });
            }
        });
    });
});

document.querySelectorAll('.confirm-pembayaran-button').forEach(button => {
  button.style.display = 'block'; // Tampilkan tombol konfirmasi pembayaran
});

document.querySelectorAll('.confirm-pembayaran-button').forEach(button => {
  const idHistory = button.getAttribute('data-id');
  const card = button.closest('.card');
  const statusPembayaran = card.querySelector('p:nth-child(9) strong');

  if (statusPembayaran) {
    const text = statusPembayaran.textContent.trim();
    if (text === 'Sudah Dibayar') {
      button.style.display = 'none';
    } else {
      button.style.display = 'block';
    }
  }


  // Tambahkan event listener untuk konfirmasi pembayaran
  button.addEventListener('click', function() {
    Swal.fire({
      title: 'Konfirmasi Pembayaran',
      text: "Apakah Anda yakin ingin mengonfirmasi pembayaran ini?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Konfirmasi'
    }).then((result) => {
      if (result.isConfirmed) {
        fetch('../_teknisi_/fungsi/konfirmasi_pembayaran.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `id_history=${encodeURIComponent(idHistory)}`
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            button.remove(); // Hapus tombol
            Swal.fire({
              title: 'Berhasil!',
              html: `${data.message || 'Pembayaran berhasil dikonfirmasi.'}`,
              icon: 'success',
              confirmButtonText: 'OK' // Menambahkan tombol OK
            }).then(() => {
              window.location.href = window.location.href; // Reload halaman setelah OK diklik
            });
          } else {
            Swal.fire({
              title: 'Gagal!',
              text: data.message || 'Terjadi kesalahan saat mengonfirmasi pembayaran.',
              icon: 'error'
            });
          }
        })
        .catch(error => {
          console.error('Error:', error);
          Swal.fire({
            title: 'Kesalahan!',
            text: 'Tidak dapat menghubungi server. Silakan coba lagi nanti.',
            icon: 'error'
          });
        });
      }
    });
  });
});


    </script>

    
    <!-- Bottom Menu -->
    <div class="bottom-menu">
        <a href="/teknisi" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="/teknisi/service" class="menu-item active">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="/teknisi/booking" class="menu-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="/teknisi/history" class="menu-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="/teknisi/profile" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>
    
<!-- JavaScript Libraries -->
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<!-- <script src="../../_assets/js/service.js"></script> -->
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>