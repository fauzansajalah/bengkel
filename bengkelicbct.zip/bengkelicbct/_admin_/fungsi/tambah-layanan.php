<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kategori = $_POST['kategori'];
    $menu_layanan = $_POST['menu_layanan'];
    $nama_layanan = $_POST['nama_layanan'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];

    // Query untuk memasukkan data layanan baru
    $query = "INSERT INTO layanan (kategori, menu_layanan, nama_layanan, deskripsi, harga) 
              VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("ssssi", $kategori, $menu_layanan, $nama_layanan, $deskripsi, $harga);

    if ($stmt->execute()) {
        // Catat log ke tabel admin_logs
        session_start();
        $id_admin = $_SESSION['id_admin'] ?? null; // Ambil ID Admin dari sesi
        if ($id_admin) {
            $log_action = "Menambah layanan: $nama_layanan";
            $log_query = "INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)";
            $log_stmt = $koneksi->prepare($log_query);
            $log_stmt->bind_param("is", $id_admin, $log_action);
            $log_stmt->execute();
        }
        
        echo json_encode(['status' => 'success', 'message' => 'Layanan berhasil ditambahkan']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat menambahkan layanan']);
    }
}
?>
