<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database
// Ambil data teknisi
$query = "SELECT * FROM admin";
$result = mysqli_query($koneksi, $query);
?>