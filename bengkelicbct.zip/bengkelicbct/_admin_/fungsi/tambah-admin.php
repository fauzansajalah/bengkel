<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database

// Memulai sesi untuk mendapatkan ID admin
session_start();
$id_admin_logged_in = $_SESSION['id_admin'] ?? null; // Pastikan id_admin dari sesi

if ($_SERVER["REQUEST_METHOD"] === "POST" && $id_admin_logged_in) {
    // Mengambil data dari form
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $no_hp = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']); // Langsung simpan password tanpa hashing

    // Query untuk menambah admin
    $query = "INSERT INTO admin (nama, nama_lengkap, email, no_hp, password) 
              VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("sssss", $nama, $nama_lengkap, $email, $no_hp, $password);

    if ($stmt->execute()) {
        // Catat log ke tabel admin_logs
        $log_action = "Menambahkan admin: $nama_lengkap";
        $log_query = "INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)";
        $log_stmt = $koneksi->prepare($log_query);
        $log_stmt->bind_param("is", $id_admin_logged_in, $log_action);
        $log_stmt->execute();

        // Return response JSON
        echo json_encode(['status' => 'success', 'message' => 'Admin berhasil ditambahkan.']);
        exit;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat menambah admin.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses untuk melakukan tindakan ini.']);
}
?>
