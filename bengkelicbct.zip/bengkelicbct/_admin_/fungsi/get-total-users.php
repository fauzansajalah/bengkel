<?php
// Mulai sesi
session_start();

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

try {
    // Query untuk menghitung total pengguna dari tabel pelanggan
    $query = "SELECT COUNT(*) AS total FROM pelanggan";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $totalUsers = $row['total'];

        // Kirimkan data dalam format JSON
        echo json_encode([
            'success' => true,
            'total' => $totalUsers
        ]);
    } else {
        // Jika query gagal
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch data'
        ]);
    }
} catch (Exception $e) {
    // Tangani error
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
