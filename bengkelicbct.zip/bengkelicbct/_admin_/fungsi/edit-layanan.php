<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_layanan'])) {
    $id_layanan = $_POST['id_layanan'];
    $kategori = $_POST['kategori'];
    $menu_layanan = $_POST['menu_layanan']; // Menambahkan menu_layanan
    $nama_layanan = $_POST['nama_layanan'];
    $deskripsi = $_POST['deskripsi'];
    $harga = $_POST['harga'];
    
    // Ambil id_admin dari sesi (pastikan sesi sudah diatur sebelumnya)
    session_start();
    $id_admin = $_SESSION['id_admin'] ?? null; // Ganti dengan nama sesi yang sesuai

    if (!$id_admin) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses untuk melakukan tindakan ini.']);
        exit;
    }

    // Perbaiki penggunaan $conn menjadi $koneksi
    $query = "UPDATE layanan SET 
                kategori = ?, 
                menu_layanan = ?, 
                nama_layanan = ?, 
                deskripsi = ?, 
                harga = ? 
              WHERE id_layanan = ?";
    $stmt = $koneksi->prepare($query);  // Gunakan $koneksi, bukan $conn
    $stmt->bind_param("ssssdi", $kategori, $menu_layanan, $nama_layanan, $deskripsi, $harga, $id_layanan);

    if ($stmt->execute()) {
        // Catat log ke tabel admin_logs
        $log_action = "Mengedit layanan: $nama_layanan (ID: $id_layanan)";
        $log_query = "INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)";
        $log_stmt = $koneksi->prepare($log_query);
        $log_stmt->bind_param("is", $id_admin, $log_action);
        $log_stmt->execute();

        // Jika berhasil, kirim response sukses
        echo json_encode(['status' => 'success', 'message' => 'Layanan berhasil diperbarui.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat memperbarui data layanan.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Permintaan tidak valid.']);
}
?>
