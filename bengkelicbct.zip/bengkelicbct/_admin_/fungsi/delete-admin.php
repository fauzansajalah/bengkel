<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database

// Memulai sesi untuk mendapatkan ID admin yang sedang login
session_start();
$id_admin_logged_in = $_SESSION['id_admin'] ?? null; // Pastikan id_admin dari sesi

if ($_SERVER["REQUEST_METHOD"] === "POST" && $id_admin_logged_in) {
    // Mengambil ID admin yang akan dihapus
    $id_admin = mysqli_real_escape_string($koneksi, $_POST['id_admin']);

    // Query untuk mendapatkan nama admin yang akan dihapus
    $query = "SELECT nama FROM admin WHERE id_admin = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id_admin);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Ambil nama admin yang akan dihapus
        $row = $result->fetch_assoc();
        $nama_admin = $row['nama'];

        // Pastikan admin yang akan dihapus bukan admin yang sedang login
        if ($id_admin == $id_admin_logged_in) {
            echo json_encode(['status' => 'error', 'message' => 'Anda tidak dapat menghapus akun Anda sendiri.']);
            exit;
        }

        // Query untuk menghapus data admin
        $delete_query = "DELETE FROM admin WHERE id_admin = ?";
        $delete_stmt = $koneksi->prepare($delete_query);
        $delete_stmt->bind_param("i", $id_admin);

        if ($delete_stmt->execute()) {
            // Catat log ke tabel admin_logs
            $log_action = "Menghapus admin: $nama_admin";
            $log_query = "INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)";
            $log_stmt = $koneksi->prepare($log_query);
            $log_stmt->bind_param("is", $id_admin_logged_in, $log_action);
            $log_stmt->execute();

            // Return response JSON
            echo json_encode(['status' => 'success', 'message' => 'Admin berhasil dihapus.']);
            exit;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat menghapus admin.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Admin tidak ditemukan.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses untuk melakukan tindakan ini.']);
}
?>
