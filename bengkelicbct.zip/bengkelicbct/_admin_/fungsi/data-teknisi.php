<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database
// Ambil data teknisi
$query = "SELECT * FROM teknisi";
$result = mysqli_query($koneksi, $query);
$walletQuery = "SELECT * FROM e_wallets";
$walletResult = mysqli_query($koneksi, $walletQuery);
$wallets = [];
while ($walletRow = mysqli_fetch_assoc($walletResult)) {
    $wallets[$walletRow['id']] = $walletRow['nama_wallet'];
}

?>