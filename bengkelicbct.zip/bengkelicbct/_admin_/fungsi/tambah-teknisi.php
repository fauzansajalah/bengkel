<?php
// Tidak ada baris kosong sebelum atau setelah script ini
require '../../_config/koneksi/koneksi.php';

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
error_log("Data POST yang diterima: " . json_encode($_POST));  // Mencatat data POST
// Debugging: Cek apa yang dikirimkan
ob_start(); // Menangkap output
echo json_encode(['status' => 'success', 'message' => 'Teknisi berhasil ditambahkan']);
$output = ob_get_clean(); // Ambil output yang ditangkap
error_log("Response: " . $output); // Log respons untuk memeriksa hasilnya

// Kirimkan response
echo $output;

header('Content-Type: application/json'); // Menambahkan header JSON

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $spesialisasi = isset($_POST['spesialisasi']) ? implode(',', $_POST['spesialisasi']) : '';
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];
    $password = $_POST['password'];

    // Validasi wajib diisi
    if (empty($email) || empty($nama) || empty($kategori) || empty($spesialisasi) || empty($alamat) || empty($no_hp) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Semua field wajib diisi']);
        exit;
    }

    // Pastikan admin telah login
    if (!isset($_SESSION['id_admin'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak, login sebagai admin']);
        exit;
    }

    $id_admin = $_SESSION['id_admin'];

    try {
        // Definisikan e_wallet_ids dan e_wallet_numbers sebagai variabel
        $e_wallet_ids = isset($_POST['nomor_e_wallet']) ? array_keys($_POST['nomor_e_wallet']) : [];
        $e_wallet_numbers = isset($_POST['nomor_e_wallet']) ? json_encode($_POST['nomor_e_wallet']) : '';

        // Tambahkan ke database
        $stmt = $koneksi->prepare("INSERT INTO teknisi (email, nama, kategori, spesialisasi, pengalaman, foto, alamat, no_hp, password, e_wallet_id, nomor_e_wallet) 
                                   VALUES (?, ?, ?, ?, '', 'teknisi.png', ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssssssss', $email, $nama, $kategori, $spesialisasi, $alamat, $no_hp, $password, implode(',', $e_wallet_ids), $e_wallet_numbers);
        $stmt->execute();

        // Mencatat aksi admin
        $action = "Menambahkan teknisi: $nama ($email)";
        $logStmt = $koneksi->prepare("INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)");
        $logStmt->bind_param('is', $id_admin, $action);
        $logStmt->execute();

        echo json_encode(['status' => 'success', 'message' => 'Teknisi berhasil ditambahkan']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal menambahkan teknisi: ' . $e->getMessage()]);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Metode tidak valid']);
}
?>
