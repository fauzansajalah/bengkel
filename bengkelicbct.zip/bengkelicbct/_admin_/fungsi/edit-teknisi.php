<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_teknisi'])) {
    $id_teknisi = $_POST['id_teknisi'];
    $email = $_POST['email'];
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $spesialisasi = implode(',', $_POST['spesialisasi']);
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];

    // Proses e_wallet_id dan nomor_e_wallet
    $e_wallets = isset($_POST['nomor_e_wallet']) ? $_POST['nomor_e_wallet'] : [];
    $e_wallet_ids = implode(',', array_keys($e_wallets)); // Gabungkan ID e-wallet
    $e_wallet_numbers = json_encode($e_wallets); // Simpan nomor sebagai JSON

    $query = "UPDATE teknisi SET 
                email = ?, 
                nama = ?, 
                kategori = ?, 
                spesialisasi = ?, 
                alamat = ?, 
                no_hp = ?, 
                e_wallet_id = ?, 
                nomor_e_wallet = ? 
              WHERE id_teknisi = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("ssssssssi", $email, $nama, $kategori, $spesialisasi, $alamat, $no_hp, $e_wallet_ids, $e_wallet_numbers, $id_teknisi);

    if ($stmt->execute()) {
        // Catat log ke tabel admin_logs
        $log_action = "Mengedit teknisi: $nama (ID: $id_teknisi)";
        $log_query = "INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)";
        $log_stmt = $koneksi->prepare($log_query);
        $log_stmt->bind_param("is", $id_admin, $log_action);
        $log_stmt->execute();

        // Jika berhasil, lakukan redirect ke /teknisi
        header('Location: /admin/teknisi'); 
        exit;  // Pastikan untuk keluar setelah header redirect
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan saat memperbarui data teknisi.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Permintaan tidak valid.']);
}
?>
