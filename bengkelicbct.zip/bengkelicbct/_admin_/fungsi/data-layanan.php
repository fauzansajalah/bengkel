<?php
include('../../_config/koneksi/koneksi.php'); // Mengimpor koneksi database
// Ambil data teknisi
$query = "SELECT * FROM layanan";
$result = mysqli_query($koneksi, $query);
?>