<?php
require '../../_config/koneksi/koneksi.php';

// Atur header JSON
header('Content-Type: application/json');

session_start(); // Mulai sesi untuk mendapatkan id_admin

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_layanan = $_POST['id_layanan'];

    // Pastikan admin telah login
    if (!isset($_SESSION['id_admin'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak, login sebagai admin']);
        exit;
    }

    $id_admin = $_SESSION['id_admin'];

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // Hapus data terkait di tabel history_pelanggan
        $sqlDeleteHistory = "
            DELETE FROM history_pelanggan 
            WHERE id_layanan IN (
                SELECT id_layanan FROM layanan WHERE id_layanan = ?
            )";
        $stmtHistory = $koneksi->prepare($sqlDeleteHistory);
        $stmtHistory->bind_param("i", $id_layanan);
        $stmtHistory->execute();

        // Hapus data terkait di tabel transaksi
        $sqlDeleteTransaksi = "DELETE FROM transaksi WHERE id_layanan = ?";
        $stmtTransaksi = $koneksi->prepare($sqlDeleteTransaksi);
        $stmtTransaksi->bind_param("i", $id_layanan);
        $stmtTransaksi->execute();

// Ambil data layanan untuk log
$sqlGetLayanan = "SELECT nama_layanan, kategori FROM layanan WHERE id_layanan = ?";
$stmtGetLayanan = $koneksi->prepare($sqlGetLayanan);
$stmtGetLayanan->bind_param("i", $id_layanan);
$stmtGetLayanan->execute();
$resultLayanan = $stmtGetLayanan->get_result();
$layananData = $resultLayanan->fetch_assoc();

if (!$layananData) {
    echo json_encode(['status' => 'error', 'message' => "Layanan dengan ID $id_layanan tidak ditemukan"]);
    exit;
}


        $namaLayanan = $layananData['nama_layanan'];
        $kategoriLayanan = $layananData['kategori'];

        // Hapus data dari tabel layanan
        $sqlDeleteLayanan = "DELETE FROM layanan WHERE id_layanan = ?";
        $stmtLayanan = $koneksi->prepare($sqlDeleteLayanan);
        $stmtLayanan->bind_param("i", $id_layanan);
        $stmtLayanan->execute();

        // Catat aksi admin
        $action = "Menghapus layanan: $namaLayanan (Kategori: $kategoriLayanan)";
        $logStmt = $koneksi->prepare("INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)");
        $logStmt->bind_param("is", $id_admin, $action);
        $logStmt->execute();

        // Commit transaksi jika semua berhasil
        $koneksi->commit();
        echo json_encode(['status' => 'success', 'message' => 'Data layanan dan data terkait berhasil dihapus']);
    } catch (Exception $e) {
        // Rollback transaksi jika terjadi kesalahan
        $koneksi->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus data: ' . $e->getMessage()]);
    }
}
?>
