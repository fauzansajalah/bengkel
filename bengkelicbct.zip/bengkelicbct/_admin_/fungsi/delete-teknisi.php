<?php
require '../../_config/koneksi/koneksi.php';

// Atur header JSON
header('Content-Type: application/json');

session_start(); // Mulai sesi untuk mendapatkan id_admin

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_teknisi = $_POST['id_teknisi'];

    // Pastikan admin telah login
    if (!isset($_SESSION['id_admin'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak, login sebagai admin']);
        exit;
    }

    $id_admin = $_SESSION['id_admin'];

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // Hapus data terkait di tabel history_pelanggan
        $sqlDeleteHistory = "
            DELETE FROM history_pelanggan 
            WHERE id_transaksi IN (
                SELECT id_transaksi FROM transaksi WHERE id_teknisi = ?
            )";
        $stmtHistory = $koneksi->prepare($sqlDeleteHistory);
        $stmtHistory->bind_param("i", $id_teknisi);
        $stmtHistory->execute();

        // Hapus data terkait di tabel transaksi
        $sqlDeleteTransaksi = "DELETE FROM transaksi WHERE id_teknisi = ?";
        $stmtTransaksi = $koneksi->prepare($sqlDeleteTransaksi);
        $stmtTransaksi->bind_param("i", $id_teknisi);
        $stmtTransaksi->execute();

        // Ambil data teknisi untuk log
        $sqlGetTeknisi = "SELECT nama, email FROM teknisi WHERE id_teknisi = ?";
        $stmtGetTeknisi = $koneksi->prepare($sqlGetTeknisi);
        $stmtGetTeknisi->bind_param("i", $id_teknisi);
        $stmtGetTeknisi->execute();
        $resultTeknisi = $stmtGetTeknisi->get_result();
        $teknisiData = $resultTeknisi->fetch_assoc();

        if (!$teknisiData) {
            throw new Exception("Teknisi dengan ID $id_teknisi tidak ditemukan");
        }

        $namaTeknisi = $teknisiData['nama'];
        $emailTeknisi = $teknisiData['email'];

        // Hapus data dari tabel teknisi
        $sqlDeleteTeknisi = "DELETE FROM teknisi WHERE id_teknisi = ?";
        $stmtTeknisi = $koneksi->prepare($sqlDeleteTeknisi);
        $stmtTeknisi->bind_param("i", $id_teknisi);
        $stmtTeknisi->execute();

        // Catat aksi admin
        $action = "Menghapus teknisi: $namaTeknisi ($emailTeknisi)";
        $logStmt = $koneksi->prepare("INSERT INTO admin_logs (id_admin, action) VALUES (?, ?)");
        $logStmt->bind_param("is", $id_admin, $action);
        $logStmt->execute();

        // Commit transaksi jika semua berhasil
        $koneksi->commit();
        echo json_encode(['status' => 'success', 'message' => 'Data teknisi dan data terkait berhasil dihapus']);
    } catch (Exception $e) {
        // Rollback transaksi jika terjadi kesalahan
        $koneksi->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus data: ' . $e->getMessage()]);
    }
}
?>
