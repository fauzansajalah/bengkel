<?php
require '../../_config/koneksi/koneksi.php';

if (isset($_GET['query'])) {
    $query = $_GET['query'];
    $sql = "SELECT * FROM teknisi WHERE nama LIKE ?";
    $stmt = $koneksi->prepare($sql);
    $searchTerm = '%' . $query . '%';
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    $teknisiList = [];
    while ($row = $result->fetch_assoc()) {
        $teknisiList[] = $row;
    }

    echo json_encode($teknisiList);
}
?>
