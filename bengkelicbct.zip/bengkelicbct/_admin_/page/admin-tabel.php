<?php
// Mulai sesi
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    header('Location: /'); // Redirect ke halaman login admin jika belum login
    exit;
}

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

require_once '../fungsi/data-admin.php'; // Muat file layanan.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="../../_assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="admin-header">
        <h1><a href="/admin-users" style="color: #fff;">Admin Dashboard</a></h1>
        <br>
        <nav>
            <ul>
                <li><a href="/admin/feedback">Feedback</a></li>
                <li><a href="/admin/layanan">Layanan</a></li>
                <li><a href="/admin/teknisi">Teknisi</a></li>
                <li><a href="/admin/admin">Admin</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </nav>
    </header>
    
    <br>
    <div class="container-tabel">
        <h2>Daftar Admin</h2>
        <button id="btnTambahAdmin" class="btn">Tambah Admin</button>
        <div>
            <input 
            type="text" 
            id="searchAdmin" 
            placeholder="Cari nama admin..." 
            style="padding: 10px 10px 10px 35px; width: 300px; font-size: 16px; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px;">
        </div>
        <div class="tabel-container">
    <div class="tombol-export">
        <a href="laporan-excel-admin" class="btn btn-success">Export Excel</a>
        <a href="laporan-pdf-admin" class="btn btn-success">Export Pdf</a>
      </div>

    <br>
    <table border="1" cellpadding="10" cellspacing="0" id="adminTable">
        <thead>
            <tr>
                <th>ID Admin</th>
                <th>Nama</th>
                <th>Nama Lengkap</th>
                <th>Email</th>
                <th>No. HP</th>
                <th>Created At</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="adminBody">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['id_admin']; ?></td>
                    <td><?php echo $row['nama']; ?></td>
                    <td><?php echo $row['nama_lengkap']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['no_hp']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <button type="button" class="edit" onclick="showEditForm(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>)">Edit</button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id_admin" value="<?php echo $row['id_admin']; ?>">
                            <button type="submit" name="delete" class="btn-delete">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<div id="editModal" class="modal">
    <div class="container">
        <h2>Edit Admin</h2>
        <form id="editAdminForm" onsubmit="return submitEditAdminForm(event)" action="javascript:void(0);">
    <input type="hidden" id="edit-id_admin" name="id_admin">

    <label for="edit-nama">Nama:</label>
    <input type="text" id="edit-nama" name="nama" required><br>

    <label for="edit-nama_lengkap">Nama Lengkap:</label>
    <input type="text" id="edit-nama_lengkap" name="nama_lengkap" required><br>

    <label for="edit-email">Email:</label>
    <input type="email" id="edit-email" name="email" required><br>

    <label for="edit-no_hp">No HP:</label>
    <input type="text" id="edit-no_hp" name="no_hp" required><br>

    <label for="edit-password">Password:</label>
    <input type="password" id="edit-password" name="password"><br>

    <button type="submit" class="btn-modal">Simpan Perubahan</button>
    <button type="button" class="btn-modal" onclick="closeModal()">Tutup</button>
</form>
    </div>
</div> 

<!-- Modal Tambah Admin -->
<div id="modalTambahAdmin" class="modal">
    <div class="container">
        <h2>Tambah Admin</h2>
        <form id="formTambahAdmin">
            <label for="nama">Nama <span class="required">*</span></label>
            <input type="text" id="nama" name="nama" required>

            <label for="nama_lengkap">Nama Lengkap <span class="required">*</span></label>
            <input type="text" id="nama_lengkap" name="nama_lengkap" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email">

            <label for="no_hp">No HP</label>
            <input type="text" id="no_hp" name="no_hp">

            <label for="password">Password <span class="required">*</span></label>
            <input type="password" id="password" name="password" required>

            <button type="button" class="btn-modal" onclick="submitTambahAdminForm()">Tambah</button>
            <button type="button" class="btn-modal" onclick="closeModalTambahAdmin()">Tutup</button>
        </form>
    </div>
</div>
</div>
    <footer class="admin-footer">
        <p>&copy; 2024 Admin Dashboard. All Rights Reserved.</p>
    </footer>
<script>
document.getElementById('searchAdmin').addEventListener('input', async function () {
    const query = this.value;

    try {
        const response = await fetch(`../_admin_/fungsi/search-admin.php?query=${encodeURIComponent(query)}`);
        if (response.ok) {
            const data = await response.json();

            const adminBody = document.getElementById('adminBody');
            adminBody.innerHTML = '';

            data.forEach(row => {
                const tr = document.createElement('tr');

                tr.innerHTML = `
                    <td>${row.id_admin}</td>
                    <td>${row.nama}</td>
                    <td>${row.nama_lengkap}</td>
                    <td>${row.email}</td>
                    <td>${row.no_hp}</td>
                    <td>${row.created_at}</td>
                    <td>
                        <button type="button" class="edit" onclick='showEditForm(${JSON.stringify(row)})'>Edit</button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id_admin" value="${row.id_admin}">
                            <button type="submit" name="delete" class="btn-delete">Hapus</button>
                        </form>
                    </td>
                `;

                adminBody.appendChild(tr);
            });
        } else {
            console.error('Gagal mengambil data');
        }
    } catch (error) {
        console.error('Kesalahan jaringan:', error);
    }
});

// Delegasi event untuk tombol hapus
document.getElementById('adminBody').addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('btn-delete')) {
        e.preventDefault(); // Mencegah pengiriman form langsung

        const form = e.target.closest('form'); // Ambil form terdekat dari tombol
        const id_admin = form.querySelector('input[name="id_admin"]').value; // Ambil ID admin dari input tersembunyi dalam form

        // Tampilkan konfirmasi menggunakan SweetAlert
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data admin ini akan dihapus!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim request AJAX untuk menghapus data admin
                fetch('../_admin_/fungsi/delete-admin.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        'id_admin': id_admin // Kirim ID admin untuk dihapus
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire('Terhapus!', 'Data admin berhasil dihapus.', 'success');
                        // Hapus baris tabel terkait setelah penghapusan
                        form.closest('tr').remove();  // Menghapus baris tabel terkait
                    } else {
                        Swal.fire('Gagal!', data.message, 'error');
                    }
                });
            }
        });
    }
});


function showEditForm(admin) {
    // Tampilkan modal edit admin
    document.getElementById('editModal').style.display = 'flex';

    // Isi form dengan data admin
    document.getElementById('edit-id_admin').value = admin.id_admin;
    document.getElementById('edit-nama').value = admin.nama;
    document.getElementById('edit-nama_lengkap').value = admin.nama_lengkap;
    document.getElementById('edit-email').value = admin.email;
    document.getElementById('edit-no_hp').value = admin.no_hp;
    document.getElementById('edit-password').value = admin.password;

    // Set status admin (radio button atau dropdown)
    const statusElement = document.getElementById('edit-admin-status-' + admin.status.toLowerCase());
    if (statusElement) {
        statusElement.checked = true;
    } else {
        console.error('Status admin tidak ditemukan:', admin.status);
    }
}

// Fungsi untuk menutup modal edit admin
function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Fungsi untuk submit form edit admin
async function submitEditAdminForm(event) {
    // Hentikan default submit form
    event.preventDefault();

    const form = document.getElementById('editAdminForm');
    const formData = new FormData(form);

    try {
        const response = await fetch('../_admin_/fungsi/edit-admin.php', {
            method: 'POST',
            body: formData,
        });

        const result = await response.json();

        if (response.ok && result.status === 'success') {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: result.message,
                confirmButtonText: 'OK'
            }).then(() => {
                closeModal();
                window.location.reload(); // Refresh halaman setelah berhasil
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Terjadi kesalahan!',
                text: result.message || 'Gagal memperbarui data admin.',
                confirmButtonText: 'Coba Lagi'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Terjadi kesalahan jaringan!',
            text: 'Silakan coba lagi nanti.',
            confirmButtonText: 'OK'
        });
    }

    return false; // Pastikan tidak ada submit default
}

    // Fungsi untuk membuka modal
    document.getElementById('btnTambahAdmin').addEventListener('click', function() {
        document.getElementById('modalTambahAdmin').style.display = 'block';
    });

    // Fungsi untuk menutup modal
    function closeModalTambahAdmin() {
        document.getElementById('modalTambahAdmin').style.display = 'none';
    }

    // Fungsi untuk submit form tambah admin
    async function submitTambahAdminForm() {
        const form = document.getElementById('formTambahAdmin');
        const formData = new FormData(form);

        try {
            const response = await fetch('../_admin_/fungsi/tambah-admin.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (response.ok && result.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: result.message,
                    confirmButtonText: 'OK'
                }).then(() => {
                    closeModalTambahAdmin();
                    window.location.reload(); // Refresh halaman setelah berhasil
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Terjadi kesalahan!',
                    text: result.message || 'Gagal menambah data admin.',
                    confirmButtonText: 'Coba Lagi'
                });
            }
        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Terjadi kesalahan jaringan!',
                text: 'Silakan coba lagi nanti.',
                confirmButtonText: 'OK'
            });
        }
    }


</script>
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<script src="../../_plugins/boostrap.bundle.min.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>
</body>
</html>
