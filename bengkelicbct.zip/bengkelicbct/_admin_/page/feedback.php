<?php
// Mulai sesi
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    header('Location: /'); // Redirect ke halaman login admin jika belum login
    exit;
}

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

// Query untuk mengambil data dari tabel feedback, diurutkan berdasarkan id_feedback terbaru
$sql = "SELECT id_feedback, rating, komentar, tanggal_feedback FROM feedback ORDER BY id_feedback DESC";
$result = $koneksi->query($sql);

// Cek jika query gagal
if (!$result) {
    die("Query Error: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="../../_assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="admin-header">
        <h1><a href="/admin-users" style="color: #fff;">Admin Dashboard</a></h1>
        <br>
        <nav>
            <ul>
                <li><a href="/admin/feedback">Feedback</a></li>
                <li><a href="/admin/layanan">Layanan</a></li>
                <li><a href="/admin/teknisi">Teknisi</a></li>
                <li><a href="/admin/admin">Admin</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <div class="container-tabel">
        <br>
        <div class="tabel-container">
            <div class="tombol-export">
                <a href="laporan-excel-feedback" class="btn btn-success">Export Excel</a>
                <a href="laporan-pdf-feedback" class="btn btn-success">Export Pdf</a>
            </div>
            <h2>Feedback</h2>
            <table class="logs-table">
                <thead>
                    <tr>
                        <th>Id Feedback</th>
                        <th>Rating</th>
                        <th>Komentar</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['id_feedback']; ?></td>
                            <td><?php echo $row['rating']; ?></td>
                            <td><?php echo $row['komentar']; ?></td>
                            <td><?php echo $row['tanggal_feedback']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="admin-footer">
        <p>&copy; 2024 Admin Dashboard. All Rights Reserved.</p>
    </footer>

    <script src="../../_plugins/jquery-3.6.0.min.js"></script>
    <script src="../../_plugins/sweetalert.js"></script>
    <script src="../../_plugins/chart.js"></script>
    <script src="../../_plugins/boostrap.bundle.min.js"></script>
    <!-- Kode JavaScript Kustom -->
    <script src="../../_assets/js/script.js"></script>
    <script src="../../_assets/js/booking.js"></script>
    <script src="../../_assets/js/service.js"></script>
    <script src="../../_assets/js/home/home.js"></script>
</body>
</html>
