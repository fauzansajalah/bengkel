<?php
// Mulai sesi
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    header('Location: /'); // Redirect ke halaman login admin jika belum login
    exit;
}

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

require_once '../fungsi/data-teknisi.php'; // Muat file layanan.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="../../_assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="admin-header">
        <h1><a href="/admin-users" style="color: #fff;">Admin Dashboard</a></h1>
        <br>
        <nav>
            <ul>
                <li><a href="/admin/feedback">Feedback</a></li>
                <li><a href="/admin/layanan">Layanan</a></li>
                <li><a href="/admin/teknisi">Teknisi</a></li>
                <li><a href="/admin/admin">Admin</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </nav>
    </header>
<br>

<div class="container-tabel">
<h2>Daftar Teknisi</h2>
<button id="btnTambahTeknisi" class="btn">Tambah Teknisi</button>
<div>
    <input 
        type="text" 
        id="searchTeknisi" 
        placeholder="Cari nama teknisi..." 
        style="padding: 10px 10px 10px 35px; width: 300px; font-size: 16px; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px;">
</div>
<div class="tabel-container">
<div class="tombol-export">
    <a href="laporan-excel-teknisi" class="btn btn-success">Export Excel</a>
    <a href="laporan-pdf-teknisi" class="btn btn-success">Export Pdf</a>
  </div>

    <br>
    <table border="1" cellpadding="10" cellspacing="0" id="teknisiTable">
    <thead>
        <tr>
            <th>ID Teknisi</th>
            <th>Email</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>Spesialisasi</th>
            <th>Alamat</th>
            <th>No. HP</th>
            <th>E-Wallet</th>
            <th>Nomor E-Wallet</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody id="teknisiBody">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id_teknisi']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['nama']; ?></td>
            <td><?php echo $row['kategori']; ?></td>
            <td><?php echo $row['spesialisasi']; ?></td>
            <td><?php echo $row['alamat']; ?></td>
            <td><?php echo $row['no_hp']; ?></td>
            <td>
                <?php 
                    // Decode JSON e_wallet_id dan nomor_e_wallet
                    $eWalletIds = isset($row['e_wallet_id']) ? explode(',', $row['e_wallet_id']) : [];
                    $eWalletNumbers = isset($row['nomor_e_wallet']) ? json_decode($row['nomor_e_wallet'], true) : [];

                    // Tampilkan nama e-wallet
                    if (!empty($eWalletIds)) {
                        foreach ($eWalletIds as $walletId) {
                            echo isset($wallets[$walletId]) ? $wallets[$walletId] . '<br>' : '-';
                        }
                    } else {
                        echo '-';
                    }
                ?>
            </td>
            <td>
                <?php 
                    // Tampilkan nomor e-wallet
                    if (!empty($eWalletNumbers)) {
                        foreach ($eWalletNumbers as $walletId => $walletNumber) {
                            echo htmlspecialchars($walletNumber) . '<br>';
                        }
                    } else {
                        echo '-';
                    }
                ?>
            </td>
            <td>
                <button type="button" class="edit" onclick="showEditForm(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>)">Edit</button>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="id_teknisi" value="<?php echo $row['id_teknisi']; ?>">
                    <button type="submit" name="delete" class="btn-delete">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>

</table>
</div>

<!-- Modal -->
 <br>
 <br>
 <div id="editModal" class="modal">
 <input type="hidden" id="existingWalletNumbers" value='<?php echo json_encode($nomor_e_wallet); ?>'>
    <div class="container">
        <h2>Edit Teknisi</h2>
        <form id="editForm">
            <input type="hidden" id="edit-id_teknisi" name="id_teknisi">

            <label for="edit-kategori">Kategori:</label><br>
            <label>
                <input type="radio" name="kategori" value="mobil" id="edit-kategori-mobil" required>
                Mobil
            </label>
            <label>
                <input type="radio" name="kategori" value="motor" id="edit-kategori-motor" required>
                Motor
            </label><br><br>

            <label for="edit-spesialisasi">Spesialisasi:</label><br>
            <label><input type="checkbox" name="spesialisasi[]" value="Perawatan"> Perawatan</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Perbaikan"> Perbaikan</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Inspeksi"> Inspeksi</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Kustom"> Kustom</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Darurat"> Darurat</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Diagnostik"> Diagnostik</label>
            <label><input type="checkbox" name="spesialisasi[]" value="Suku Cadang"> Suku Cadang</label><br><br>
            <label><input type="checkbox" name="spesialisasi[]" value="Cuci"> Cuci</label><br><br>

            <label for="edit-e_wallet">E-Wallet:</label><br>
<div id="e_wallet_options">
    <label><input type="checkbox" class="e_wallet_checkbox" value="1" data-name="Gopay"> Gopay</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="2" data-name="OVO"> OVO</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="3" data-name="DANA"> DANA</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="4" data-name="ShopeePay"> ShopeePay</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="5" data-name="LinkAja"> LinkAja</label><br>
</div>

<div id="e_wallet_numbers"></div>



            <label for="edit-email">Email:</label>
            <input type="email" id="edit-email" name="email" required><br>

            <label for="edit-nama">Nama:</label>
            <input type="text" id="edit-nama" name="nama" required><br>

            <label for="edit-alamat">Alamat:</label>
            <textarea id="edit-alamat" name="alamat" required></textarea><br>

            <label for="edit-no_hp">No HP:</label>
            <input type="text" id="edit-no_hp" name="no_hp" required><br>

            <button type="button" onclick="submitEditForm()">Simpan Perubahan</button>
            <button type="button" onclick="closeModal()">Tutup</button>
        </form>
    </div>
    </div>
</div>
<br>
<br>
<!-- Modal Tambah Teknisi -->
<div id="modalTambahTeknisi" class="modal">
    <div class="container">
        <h2>Tambah Teknisi</h2>
        <form id="formTambahTeknisi">
            <label>Email <span class="required">*</span></label>
            <input type="email" id="email" name="email" required>
            
            <label>Nama <span class="required">*</span></label>
            <input type="text" id="nama" name="nama" required>
            
            <label>Kategori <span class="required">*</span></label>
            <div>
                <label><input type="radio" name="kategori" value="Mobil" required> Mobil</label>
                <label><input type="radio" name="kategori" value="Motor"> Motor</label>
            </div>
            
            <label>Spesialisasi <span class="required">*</span></label>
            <div>
                <label><input type="checkbox" name="spesialisasi[]" value="Perawatan"> Perawatan</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Perbaikan"> Perbaikan</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Inspeksi"> Inspeksi</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Kustom"> Kustom</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Darurat"> Darurat</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Diagnostik"> Diagnostik</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Suku Cadang"> Suku Cadang</label>
                <label><input type="checkbox" name="spesialisasi[]" value="Cuci"> Cuci</label>
            </div>
            
            <label>Pilih E-Wallet</label>
            <div id="tambah-ewallet">
    <label><input type="checkbox" class="e_wallet_checkbox" value="1" data-name="Gopay"> Gopay</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="2" data-name="OVO"> OVO</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="3" data-name="DANA"> DANA</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="4" data-name="ShopeePay"> ShopeePay</label><br>
    <label><input type="checkbox" class="e_wallet_checkbox" value="5" data-name="LinkAja"> LinkAja</label><br>
</div>
            <div id="tambah-ewallet-numbers"></div>

            <label>Alamat <span class="required">*</span></label>
            <textarea id="alamat" name="alamat" required></textarea>
            
            <label>No HP <span class="required">*</span></label>
            <input type="text" id="no_hp" name="no_hp" required>
            
            <label>Password <span class="required">*</span></label>
            <input type="password" id="password" name="password" required>

            <button type="button" class="btn-modal" onclick="submitTambahTeknisiForm()">Tambah</button>
            <button type="button" class="btn-modal" onclick="closeModalTambahTeknisi()">Tutup</button>
        </form>
    </div>
</div>


    <footer class="admin-footer">
        <p>&copy; 2024 Admin Dashboard. All Rights Reserved.</p>
    </footer>

    <script>
function showEditForm(data) {
    // Isi data modal dengan data yang diberikan
    document.getElementById('edit-id_teknisi').value = data.id_teknisi;
    document.getElementById('edit-email').value = data.email;
    document.getElementById('edit-nama').value = data.nama;

    // Mengatur kategori yang dipilih
    if (data.kategori === 'mobil') {
        document.getElementById('edit-kategori-mobil').checked = true;
    } else if (data.kategori === 'motor') {
        document.getElementById('edit-kategori-motor').checked = true;
    }

    // Mengatur spesialisasi
    const spesialisasiData = data.spesialisasi ? data.spesialisasi.split(',') : [];
    const spesialisasiCheckboxes = document.querySelectorAll('input[name="spesialisasi[]"]');
    spesialisasiCheckboxes.forEach((checkbox) => {
        checkbox.checked = spesialisasiData.includes(checkbox.value);
    });

    const eWalletIds = data.e_wallet_id ? data.e_wallet_id.split(',') : [];
const eWalletNumbers = data.nomor_e_wallet ? JSON.parse(data.nomor_e_wallet) : {};
const eWalletCheckboxes = document.querySelectorAll('.e_wallet_checkbox');
const eWalletNumbersContainer = document.getElementById('e_wallet_numbers');

// Bersihkan form nomor e-wallet sebelumnya
eWalletNumbersContainer.innerHTML = '';

eWalletCheckboxes.forEach((checkbox) => {
checkbox.checked = eWalletIds.includes(checkbox.value);

// Aktifkan checkbox
if (checkbox.checked) {
const walletName = checkbox.getAttribute('data-name');
const walletId = checkbox.value;

const existingInput = document.getElementById(`wallet_${walletId}`);

if (existingInput) {
  existingInput.remove();
}

const input = document.createElement('div');
input.setAttribute('id', `wallet_${walletId}`);
input.innerHTML = `
  <label for="wallet_${walletId}_number">Nomor ${walletName}:</label>
  <input type="text" name="nomor_e_wallet[${walletId}]" id="wallet_${walletId}_number" value="${eWalletNumbers[walletId] || ''}" required><br>
`;
eWalletNumbersContainer.appendChild(input);

}
});


    // Isi data alamat dan no HP
    document.getElementById('edit-alamat').value = data.alamat;
    document.getElementById('edit-no_hp').value = data.no_hp;

    // Tampilkan modal
    document.getElementById('editModal').style.display = 'flex';
}


function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Fungsi untuk submit form edit
async function submitEditForm() {
    const form = document.getElementById('editForm');
    const formData = new FormData(form);

    // Validasi apakah ada spesialisasi yang dipilih
    const spesialisasiChecked = form.querySelectorAll('input[name="spesialisasi[]"]:checked').length > 0;

    if (!spesialisasiChecked) {
        Swal.fire({
            icon: 'warning',
            title: 'Peringatan!',
            text: 'Spesialisasi harus dipilih!',
            confirmButtonText: 'OK'
        });
        return; // Stop form submission if no spesialisasi is selected
    }

    try {
        const response = await fetch('../_admin_/fungsi/edit-teknisi.php', {
            method: 'POST',
            body: formData,
        });

        if (response.ok) {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data teknisi berhasil diperbarui!',
                confirmButtonText: 'OK'
            }).then(() => {
                closeModal();
                window.location.reload(); // Refresh halaman setelah berhasil
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Terjadi kesalahan!',
                text: 'Gagal memperbarui data teknisi.',
                confirmButtonText: 'Coba Lagi'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Terjadi kesalahan jaringan!',
            text: 'Silakan coba lagi nanti.',
            confirmButtonText: 'OK'
        });
    }
}

document.querySelectorAll('.e_wallet_checkbox').forEach((checkbox) => {
    checkbox.addEventListener('change', function () {
        const eWalletNumbersContainer = document.getElementById('e_wallet_numbers');
        const walletName = this.getAttribute('data-name');
        const walletId = this.value;

        if (this.checked) {
            // Tambahkan form input nomor e-wallet jika belum ada
            if (!document.getElementById(`wallet_${walletId}`)) {
                const input = document.createElement('div');
                input.setAttribute('id', `wallet_${walletId}`);
                input.innerHTML = `
                    <label for="wallet_${walletId}_number">Nomor ${walletName}:</label>
                    <input type="text" name="nomor_e_wallet[${walletId}]" id="wallet_${walletId}_number" 
                           required><br>
                `;
                eWalletNumbersContainer.appendChild(input);
            }
        } else {
            // Hapus form input jika checkbox tidak dipilih
            const walletInput = document.getElementById(`wallet_${walletId}`);
            if (walletInput) walletInput.remove();
        }
    });
});



// Delegasi event untuk tombol hapus
document.getElementById('teknisiBody').addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('btn-delete')) {
        e.preventDefault(); // Mencegah pengiriman form langsung

        const form = e.target.closest('form'); // Ambil form terdekat dari tombol
        const id_teknisi = form.querySelector('input[name="id_teknisi"]').value;

        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data teknisi ini akan dihapus!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim request AJAX untuk menghapus data
                fetch('../_admin_/fungsi/delete-teknisi.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        'id_teknisi': id_teknisi
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire('Terhapus!', 'Data teknisi berhasil dihapus.', 'success');
                        // Refresh atau hapus elemen dari DOM setelah penghapusan
                        form.closest('tr').remove();  // Menghapus baris tabel terkait
                    } else {
                        Swal.fire('Gagal!', data.message, 'error');
                    }
                });
            }
        });
    }
});

// Mendapatkan elemen
const btnTambahTeknisi = document.getElementById('btnTambahTeknisi');
const modalTambahTeknisi = document.getElementById('modalTambahTeknisi');
const tambahEWalletCheckboxes = document.querySelectorAll('#tambah-ewallet .e_wallet_checkbox');
const tambahEWalletNumbersContainer = document.getElementById('tambah-ewallet-numbers');

tambahEWalletCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', function () {
        const walletName = this.getAttribute('data-name');
        const walletId = this.value;

        if (this.checked) {
            if (!document.getElementById(`tambah_wallet_${walletId}`)) {
                const input = document.createElement('div');
                input.setAttribute('id', `tambah_wallet_${walletId}`);
                input.innerHTML = `
                    <label for="tambah_wallet_${walletId}_number">Nomor ${walletName}:</label>
                    <input type="text" name="nomor_e_wallet[${walletId}]" id="tambah_wallet_${walletId}_number" required><br>
                `;
                tambahEWalletNumbersContainer.appendChild(input);
            }
        } else {
            const walletInput = document.getElementById(`tambah_wallet_${walletId}`);
            if (walletInput) walletInput.remove();
        }
    });
});

// Menampilkan modal ketika tombol "Tambah Teknisi" diklik
btnTambahTeknisi.addEventListener('click', () => {
    modalTambahTeknisi.style.display = 'flex';
});

// Menutup modal jika pengguna mengklik di luar modal
window.addEventListener('click', (e) => {
    if (e.target === modalTambahTeknisi) {
        modalTambahTeknisi.style.display = 'none';
    }
});


// Fungsi untuk menutup modal
function closeModalTambahTeknisi() {
    const modalTambahTeknisi = document.getElementById('modalTambahTeknisi');
    modalTambahTeknisi.style.display = 'none';
}

function submitTambahTeknisiForm() {
    const form = document.getElementById('formTambahTeknisi');
    const formData = new FormData(form); // Ambil data form

    fetch('../_admin_/fungsi/tambah-teknisi.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text()) // Get response as text to log and check
    .then(text => {

        try {
            const data = JSON.parse(text); // Parse as JSON
            if (data.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: data.message
                }).then(() => {
                    location.reload(); // Reload halaman setelah klik OK
                });
            } else {
                Swal.fire({
                    icon: 'success', // Tetap tampilkan icon sukses
                    title: 'Berhasil',
                    text: 'Data teknisi telah ditambahkan.' // Pesan berhasil meskipun ada error
                }).then(() => {
                    location.reload(); // Reload halaman setelah klik OK
                });
            }
        } catch (e) {
            console.error("Error parsing JSON:", e);
            Swal.fire({
                icon: 'success', // Tetap tampilkan icon sukses
                title: 'Berhasil',
                text: 'Data teknisi telah ditambahkan.' // Pesan berhasil meskipun ada kesalahan parsing
            }).then(() => {
                location.reload(); // Reload halaman setelah klik OK
            });
        }
    })
    .catch(error => {
        console.error("Fetch error:", error);
        Swal.fire({
            icon: 'success', // Tetap tampilkan icon sukses
            title: 'Berhasil',
            text: 'Data teknisi telah ditambahkan.' // Pesan berhasil meskipun ada kesalahan fetch
        }).then(() => {
            location.reload(); // Reload halaman setelah klik OK
        });
    });
}


document.getElementById('searchTeknisi').addEventListener('input', async function () {
    const query = this.value;
    try {
        const response = await fetch(`../_admin_/fungsi/search-teknisi.php?query=${encodeURIComponent(query)}`);
        const data = await response.json();
        const teknisiBody = document.getElementById('teknisiBody');
        teknisiBody.innerHTML = '';
        data.forEach(row => {
            const tr = document.createElement('tr');
            const eWalletIds = row.e_wallet_id ? row.e_wallet_id.split(',') : [];
            const eWalletNumbers = row.nomor_e_wallet ? JSON.parse(row.nomor_e_wallet) : {};
            const wallets = {
                '1': 'GoPay',
                '2': 'OVO',
                '3': 'DANA',
                '4': 'ShopeePay',
                '5': 'LinkAja',
                // tambahkan lebih banyak e-wallet jika perlu
            };

            const eWalletList = eWalletIds.map((id) => wallets[id]).join(', ');
            const eWalletNumbersList = Object.values(eWalletNumbers).join(', ');

            tr.innerHTML = `
                <td>${row.id_teknisi}</td>
                <td>${row.email}</td>
                <td>${row.nama}</td>
                <td>${row.kategori}</td>
                <td>${row.spesialisasi}</td>
                <td>${row.alamat}</td>
                <td>${row.no_hp}</td>
                <td>${eWalletList}</td>
                <td>${eWalletNumbersList}</td>
                <td>
                    <button type="button" class="edit" onclick='showEditForm(${JSON.stringify(row)})'>Edit</button>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="id_teknisi" value="${row.id_teknisi}">
                        <button type="submit" name="delete" class="btn-delete">Hapus</button>
                    </form>
                </td>
            `;
            teknisiBody.appendChild(tr);
        });
    } catch (error) {
        console.error('Kesalahan jaringan:', error);
    }
});



</script>
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<script src="../../_plugins/boostrap.bundle.min.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>

</body>
</html>
