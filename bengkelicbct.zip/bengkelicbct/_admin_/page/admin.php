<?php
// Mulai sesi
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    header('Location: /'); // Redirect ke halaman login admin jika belum login
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="../../_assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="admin-header">
    <h1><a href="/admin-users" style="color: #fff;">Admin Dashboard</a></h1>
        <br>
        <nav>
            <ul>
                <li><a href="/admin/feedback">Feedback</a></li>
                <li><a href="/admin/layanan">Layanan</a></li>
                <li><a href="/admin/teknisi">Teknisi</a></li>
                <li><a href="/admin/admin">Admin</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main class="admin-main">
        <section>
            <h2>Welcome, Admin</h2>
            <p>Di halaman admin ini anda bisa mengubah layanan, juga bisa menambah akun teknisi maupun menghapus akun teknisi begitupula dengan akun admin.</p>
        </section>

        <section id="admin-actions">
            <div class="card">
                <h3>Total Users</h3>
                <p id="total-users">Loading...</p>
            </div>
            <div class="card">
                <h3>System Logs</h3>
                <br>
                <a href="/admin/logs" class="btn">View Logs</a>
            </div>
        </section>
    </main>

    <footer class="admin-footer">
        <p>&copy; 2024 Admin Dashboard. All Rights Reserved.</p>
    </footer>

    <script>
        // Fetch total users for the dashboard
        document.addEventListener('DOMContentLoaded', function() {
            fetch('../_admin_/fungsi/get-total-users.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('total-users').textContent = data.total;
                    } else {
                        document.getElementById('total-users').textContent = 'Error fetching data';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('total-users').textContent = 'Error fetching data';
                });
        });
    </script>
    <script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<script src="../../_plugins/boostrap.bundle.min.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>
</body>
</html>
