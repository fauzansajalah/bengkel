<?php
// Mulai sesi
session_start();

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

// Cek apakah form login telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Query untuk memeriksa email dan password
    $query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) === 1) {
        // Jika email dan password cocok, simpan informasi ke sesi
        $admin = mysqli_fetch_assoc($result);
        $_SESSION['id_admin'] = $admin['id_admin']; // Simpan id_admin ke sesi
        $_SESSION['admin_email'] = $admin['email'];

        // Redirect ke halaman /admin-users
        header('Location: /admin-users');
        exit;
    } else {
        // Jika login gagal, beri pesan error
        $error = "Email atau password salah.";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <style>
body {
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  margin: 0;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-container {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
}


.login-container h1 {
  margin-bottom: 20px;
  font-size: 24px;
  text-align: center;
}


.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
}

.form-group input {
  width: 95%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin: 0 auto;
}



.form-group button {
  width: 100%;
  padding: 10px;
  background-color: #b30000;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
}

.form-group button:hover {
  background-color: #8f0000;
}

.error {
  color: red;
  font-size: 14px;
  margin-bottom: 15px;
  text-align: center;
}

    </style>
</head>
<body>
    <div class="login-container">
        <h1>Login Admin</h1>
        <?php if (!empty($error)) { echo "<div class='error'>$error</div>"; } ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
