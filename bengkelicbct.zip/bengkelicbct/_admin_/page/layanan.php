<?php
// Mulai sesi
session_start();

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['id_admin'])) {
    header('Location: /'); // Redirect ke halaman login admin jika belum login
    exit;
}

// Masukkan koneksi database
include '../../_config/koneksi/koneksi.php';

require_once '../fungsi/data-layanan.php'; // Muat file layanan.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../../_assets/css/index/styles.css">
    <link rel="stylesheet" href="../../_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="../../_assets/css/home/home.css">
    <link rel="stylesheet" href="../../_assets/css/about.css">
    <link rel="stylesheet" href="../../_assets/css/booking.css">
    <link rel="stylesheet" href="../../_assets/css/service.css">
    <link rel="stylesheet" href="../../_assets/css/admin.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="admin-header">
    <h1><a href="/admin-users" style="color: #fff;">Admin Dashboard</a></h1>
        <br>
        <nav>
            <ul>
                <li><a href="/admin/feedback">Feedback</a></li>
                <li><a href="/admin/layanan">Layanan</a></li>
                <li><a href="/admin/teknisi">Teknisi</a></li>
                <li><a href="/admin/admin">Admin</a></li>
                <li><a href="/logout">Logout</a></li>
            </ul>
        </nav>
    </header>
<br>
    <div class="container-tabel">
    <h2>Daftar Layanan</h2>
    <button id="btnTambahLayanan" class="btn">Tambah Layanan</button>
    <div>
        <input 
            type="text" 
            id="searchLayanan" 
            placeholder="Cari nama layanan..." 
            style="padding: 10px 10px 10px 35px; width: 300px; font-size: 16px; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px;">
    </div>
    <div class="tabel-container">
<div class="tombol-export">
    <a href="laporan-excel-layanan" class="btn btn-success">Export Excel</a>
    <a href="laporan-pdf-layanan" class="btn btn-success">Export Pdf</a>
  </div>
    <br>
    <table border="1" cellpadding="10" cellspacing="0" id="layananTable">
        <thead>
            <tr>
                <th>ID Layanan</th>
                <th>Kategori</th>
                <th>Menu Layanan</th>
                <th>Nama Layanan</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="layananBody">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['id_layanan']; ?></td>
                    <td><?php echo $row['kategori']; ?></td>
                    <td><?php echo $row['menu_layanan']; ?></td>
                    <td><?php echo $row['nama_layanan']; ?></td>
                    <td><?php echo $row['deskripsi']; ?></td>
                    <td><?php echo $row['harga']; ?></td>
                    <td>
    <button type="button" class="edit" onclick="showEditForm(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>)">Edit</button>
    <form method="POST" style="display:inline;">
        <input type="hidden" name="id_layanan" value="<?php echo $row['id_layanan']; ?>">
<!-- Tombol delete untuk layanan -->
<button type="submit" name="delete" class="btn-delete">Hapus</button>

    </form>
</td>

                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<!-- Modal Edit Layanan -->
<div id="editModal" class="modal">
    <div class="container">
        <h2>Edit Layanan</h2>
        <form id="editForm">
            <input type="hidden" id="edit-id_layanan" name="id_layanan">

            <label for="edit-kategori">Kategori:</label><br>
            <label>
                <input type="radio" name="kategori" value="Mobil" id="edit-kategori-mobil" required>
                Mobil
            </label>
            <label>
                <input type="radio" name="kategori" value="Motor" id="edit-kategori-motor" required>
                Motor
            </label><br><br>

            <label for="edit-menu_layanan">Menu Layanan:</label><br>
            <label>
                <input type="radio" name="menu_layanan" value="Perawatan" id="edit-menu_layanan-perawatan" required>
                Perawatan
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Perbaikan" id="edit-menu_layanan-perbaikan" required>
                Perbaikan
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Inspeksi" id="edit-menu_layanan-inspeksi" required>
                Inspeksi
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Kustom" id="edit-menu_layanan-kustom" required>
                Kustom
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Darurat" id="edit-menu_layanan-darurat" required>
                Darurat
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Diagnostik" id="edit-menu_layanan-diagnostik" required>
                Diagnostik
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Suku Cadang" id="edit-menu_layanan-suku_cadang" required>
                Suku Cadang
            </label>
            <label>
                <input type="radio" name="menu_layanan" value="Cuci" id="edit-menu_layanan-cuci" required>
                Cuci
            </label>
            <br><br>

            <label for="edit-nama_layanan">Nama Layanan:</label>
            <input type="text" id="edit-nama_layanan" name="nama_layanan" required><br>

            <label for="edit-deskripsi">Deskripsi:</label>
            <textarea id="edit-deskripsi" name="deskripsi" required></textarea><br>

            <label for="edit-harga">Harga:</label>
            <input type="number" id="edit-harga" name="harga" required><br>

            <button type="button" class="btn-modal" onclick="submitEditForm()">Simpan Perubahan</button>
            <button type="button" class="btn-modal" onclick="closeModal()">Tutup</button>
        </form>
    </div>
</div>
<div id="modalTambahLayanan" class="modal">
    <div class="container">
        <h2>Tambah Layanan</h2>
        <form id="formTambahLayanan">
            <label>Kategori <span class="required">*</span></label>
            <div>
                <label><input type="radio" name="kategori" value="Mobil" required> Mobil</label>
                <label><input type="radio" name="kategori" value="Motor"> Motor</label>
            </div>

            <label>Menu Layanan <span class="required">*</span></label>
            <div>
                <label><input type="radio" name="menu_layanan" value="Perawatan" required> Perawatan</label>
                <label><input type="radio" name="menu_layanan" value="Perbaikan"> Perbaikan</label>
                <label><input type="radio" name="menu_layanan" value="Inspeksi"> Inspeksi</label>
                <label><input type="radio" name="menu_layanan" value="Kustom"> Kustom</label>
                <label><input type="radio" name="menu_layanan" value="Darurat"> Darurat</label>
                <label><input type="radio" name="menu_layanan" value="Diagnostik"> Diagnostik</label>
                <label><input type="radio" name="menu_layanan" value="Suku Cadang"> Suku Cadang</label>
                <label><input type="radio" name="menu_layanan" value="Cuci"> Cuci</label>
            </div>

            <label>Nama Layanan <span class="required">*</span></label>
            <input type="text" id="nama_layanan" name="nama_layanan" required>

            <label>Deskripsi <span class="required">*</span></label>
            <textarea id="deskripsi" name="deskripsi" required></textarea>

            <label>Harga <span class="required">*</span></label>
            <input type="number" id="harga" name="harga" required>

            <button type="button" class="btn-modal" onclick="submitTambahLayananForm()">Tambah</button>
            <button type="button" class="btn-modal" onclick="closeModalTambahLayanan()">Tutup</button>
        </form>
    </div>
</div>
    </div>

    <footer class="admin-footer">
        <p>&copy; 2024 Admin Dashboard. All Rights Reserved.</p>
    </footer>
<script>
    // Fungsi untuk menampilkan modal dan mengisi data form
// Fungsi untuk menampilkan modal edit dan mengisi form dengan data layanan
function showEditForm(layanan) {
    document.getElementById('editModal').style.display = 'flex';
    
    // Isi form dengan data layanan
    document.getElementById('edit-id_layanan').value = layanan.id_layanan;
    document.getElementById('edit-nama_layanan').value = layanan.nama_layanan;
    document.getElementById('edit-deskripsi').value = layanan.deskripsi;
    document.getElementById('edit-harga').value = layanan.harga;

    // Set radio buttons untuk kategori
    if (layanan.kategori === 'Mobil') {
        document.getElementById('edit-kategori-mobil').checked = true;
    } else if (layanan.kategori === 'Motor') {
        document.getElementById('edit-kategori-motor').checked = true;
    }

    // Set radio buttons untuk menu_layanan
    document.getElementById('edit-menu_layanan-' + layanan.menu_layanan.toLowerCase()).checked = true;
}

// Delegasi event untuk tombol Edit (selalu berfungsi, meski data diubah oleh pencarian)
document.getElementById('layananBody').addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('edit')) {
        const layanan = JSON.parse(e.target.getAttribute('data-layanan'));
        showEditForm(layanan);
    }
});


// Fungsi untuk menutup modal
function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Fungsi untuk mengirimkan form edit menggunakan AJAX
async function submitEditForm() {
    var formData = new FormData(document.getElementById('editForm'));

    try {
        var response = await fetch('../_admin_/fungsi/edit-layanan.php', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            // Menampilkan SweetAlert sukses
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data layanan berhasil diperbarui!',
                confirmButtonText: 'OK'
            }).then(() => {
                closeModal();
                window.location.reload();  // Refresh halaman setelah berhasil
            });
        } else {
            // Menampilkan SweetAlert error jika response bukan OK
            Swal.fire({
                icon: 'error',
                title: 'Terjadi kesalahan!',
                text: 'Gagal memperbarui data layanan.',
                confirmButtonText: 'Coba Lagi'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        // Menampilkan SweetAlert error jika terjadi kesalahan jaringan
        Swal.fire({
            icon: 'error',
            title: 'Terjadi kesalahan jaringan!',
            text: 'Silakan coba lagi nanti.',
            confirmButtonText: 'OK'
        });
    }
}

// Fungsi untuk menampilkan modal
document.getElementById('btnTambahLayanan').addEventListener('click', function() {
    document.getElementById('modalTambahLayanan').style.display = 'flex';
});

// Fungsi untuk menutup modal
function closeModalTambahLayanan() {
    document.getElementById('modalTambahLayanan').style.display = 'none';
}

// Fungsi untuk mengirimkan form tambah layanan menggunakan AJAX
async function submitTambahLayananForm() {
    var formData = new FormData(document.getElementById('formTambahLayanan'));

    try {
        var response = await fetch('../_admin_/fungsi/tambah-layanan.php', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Layanan berhasil ditambahkan!',
                confirmButtonText: 'OK'
            }).then(() => {
                closeModalTambahLayanan();
                window.location.reload();  // Refresh halaman setelah berhasil
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Terjadi kesalahan!',
                text: 'Gagal menambahkan layanan.',
                confirmButtonText: 'Coba Lagi'
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Terjadi kesalahan jaringan!',
            text: 'Silakan coba lagi nanti.',
            confirmButtonText: 'OK'
        });
    }
}

// Delegasi event untuk tombol hapus
document.getElementById('layananBody').addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('btn-delete')) {
        e.preventDefault(); // Mencegah pengiriman form langsung

        const form = e.target.closest('form'); // Ambil form terdekat dari tombol
        const id_layanan = form.querySelector('input[name="id_layanan"]').value;

        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data layanan ini akan dihapus!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim request AJAX untuk menghapus data layanan
                fetch('../_admin_/fungsi/delete-layanan.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        'id_layanan': id_layanan // Kirim ID layanan untuk dihapus
                    }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire('Terhapus!', 'Data layanan berhasil dihapus.', 'success');
                        // Hapus baris tabel terkait setelah penghapusan
                        form.closest('tr').remove();  // Menghapus baris tabel terkait
                    } else {
                        Swal.fire('Gagal!', data.message, 'error');
                    }
                });
            }
        });
    }
});

document.getElementById('searchLayanan').addEventListener('input', async function () {
    const query = this.value; // Ambil nilai pencarian

    // Kirim permintaan pencarian ke server
    try {
        const response = await fetch(`../_admin_/fungsi/search-layanan.php?query=${encodeURIComponent(query)}`);
        if (response.ok) {
            const data = await response.json();

            // Kosongkan tabel sebelum menambahkan hasil pencarian
            const layananBody = document.getElementById('layananBody');
            layananBody.innerHTML = '';

            // Tambahkan data hasil pencarian ke tabel
            data.forEach(row => {
                const tr = document.createElement('tr');

                tr.innerHTML = `
                    <td>${row.id_layanan}</td>
                    <td>${row.kategori}</td>
                    <td>${row.menu_layanan}</td>
                    <td>${row.nama_layanan}</td>
                    <td>${row.deskripsi}</td>
                    <td>${row.harga}</td>
                    <td>
                        <button type="button" class="edit" data-layanan='${JSON.stringify(row)}'>Edit</button>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id_layanan" value="${row.id_layanan}">
                            <button type="submit" name="delete" class="btn-delete">Hapus</button>
                        </form>
                    </td>
                `;

                layananBody.appendChild(tr);
            });
        } else {
            console.error('Gagal mengambil data');
        }
    } catch (error) {
        console.error('Kesalahan jaringan:', error);
    }
});

</script>
<script src="../../_plugins/jquery-3.6.0.min.js"></script>
<script src="../../_plugins/sweetalert.js"></script>
<script src="../../_plugins/chart.js"></script>
<script src="../../_plugins/boostrap.bundle.min.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="../../_assets/js/script.js"></script>
<script src="../../_assets/js/booking.js"></script>
<script src="../../_assets/js/service.js"></script>
<script src="../../_assets/js/home/home.js"></script>
</body>
</html>
