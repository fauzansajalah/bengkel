<?php
require('../../../libary/fpdf.php');
include '../../../_config/koneksi/koneksi.php';

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Set the title
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(190, 10, 'Data Teknisi', 0, 1, 'C');

// Header tabel
function addTableHeader($pdf) {
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Nama', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Kategori', 1, 0, 'C');
    $pdf->Cell(35, 7, 'Spesialisasi', 1, 0, 'C');
    $pdf->Cell(55, 7, 'Alamat', 1, 0, 'C');
    $pdf->Cell(30, 7, 'No HP', 1, 1, 'C');
}

addTableHeader($pdf);

// Data teknisi
$pdf->SetFont('Times', '', 10);
$sql = "SELECT * FROM teknisi";
$result = $koneksi->query($sql);
$a = 1;

while ($isi = $result->fetch_assoc()) {
    // Cek apakah halaman sudah penuh, jika penuh tambahkan halaman baru
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        addTableHeader($pdf);
    }

    // Hitung tinggi baris berdasarkan teks terpanjang
    $rowHeight = max(
        $pdf->GetStringWidth($isi['nama']) / 30,
        $pdf->GetStringWidth($isi['kategori']) / 30,
        $pdf->GetStringWidth($isi['spesialisasi']) / 35,
        $pdf->GetStringWidth($isi['alamat']) / 55,
        $pdf->GetStringWidth($isi['no_hp']) / 30
    ) * 6;

    // Isi data dalam tabel
    $pdf->Cell(10, $rowHeight, $a++, 1, 0, 'C');
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->MultiCell(30, 6, $isi['nama'], 1);
    $pdf->SetXY($x + 30, $y);
    $pdf->MultiCell(30, 6, $isi['kategori'], 1);
    $pdf->SetXY($x + 60, $y);
    $pdf->MultiCell(35, 6, $isi['spesialisasi'], 1);
    $pdf->SetXY($x + 95, $y);
    $pdf->MultiCell(55, 6, $isi['alamat'], 1);
    $pdf->SetXY($x + 150, $y);
    $pdf->MultiCell(30, 6, $isi['no_hp'], 1);

    // Pindah ke baris baru sesuai dengan tinggi baris
    $pdf->Ln($rowHeight);
}

$pdf->Output();
?>
