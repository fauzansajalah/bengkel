<?php
include '../../../_config/koneksi/koneksi.php';

// Mengatur header untuk download file Excel
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_admin_logs.xls");

// Query untuk mengambil data dari tabel admin_logs
$query = "SELECT * FROM admin_logs";
$result = $koneksi->query($query);

// Menampilkan header kolom dalam file Excel
echo "ID\tID Admin\tAction\tTimestamp\n";

// Loop untuk menampilkan data dalam format Excel
while ($log = $result->fetch_assoc()) {
    echo $log['id'] . "\t" . $log['id_admin'] . "\t" . $log['action'] . "\t" . $log['timestamp'] . "\n";
}
?>
