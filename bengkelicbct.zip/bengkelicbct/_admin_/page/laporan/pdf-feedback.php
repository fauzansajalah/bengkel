<?php
require('../../../libary/fpdf.php');
include '../../../_config/koneksi/koneksi.php';

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Set the title
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(190, 10, 'Laporan Feedback', 0, 1, 'C');

// Header tabel
function addTableHeader($pdf) {
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1, 0, 'C');
    $pdf->Cell(20, 7, 'Rating', 1, 0, 'C');
    $pdf->Cell(120, 7, 'Komentar', 1, 0, 'C');
    $pdf->Cell(40, 7, 'Tanggal Feedback', 1, 1, 'C');
}

addTableHeader($pdf);

// Data feedback
$pdf->SetFont('Times', '', 10);
$sql = "SELECT * FROM feedback";
$result = $koneksi->query($sql);
$a = 1;

while ($isi = $result->fetch_assoc()) {
    // Cek apakah halaman sudah penuh, jika penuh tambahkan halaman baru
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        addTableHeader($pdf);
    }

    // Menghitung tinggi baris berdasarkan panjang teks di setiap kolom
    $ratingWidth = $pdf->GetStringWidth($isi['rating']);
    $komentarWidth = $pdf->GetStringWidth($isi['komentar']);
    $tanggalWidth = $pdf->GetStringWidth($isi['tanggal_feedback']);

    $maxWidth = max($ratingWidth, $komentarWidth, $tanggalWidth) / 120; // Normalisasi berdasarkan lebar maksimum

    // Menghitung tinggi baris
    $rowHeight = $maxWidth * 6;

    // Isi data dalam tabel
    $pdf->Cell(10, 6, $a++, 1, 0, 'C'); // Menampilkan nomor urut
    $pdf->Cell(20, 6, $isi['rating'], 1, 0, 'C'); // Menampilkan rating
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->MultiCell(120, 6, $isi['komentar'], 1); // Menampilkan komentar
    $pdf->SetXY($x + 120, $y);
    $pdf->MultiCell(40, 6, $isi['tanggal_feedback'], 1); // Menampilkan tanggal feedback

    // Pindah ke baris baru sesuai dengan tinggi baris
    $pdf->Ln($rowHeight);
}

$pdf->Output();
?>
