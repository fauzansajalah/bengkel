<?php
include '../../../_config/koneksi/koneksi.php';

// Mengatur header untuk download file Excel
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_admin.xls");

// Query untuk mengambil data dari tabel admin
$query = "SELECT * FROM admin";
$result = $koneksi->query($query);

// Menampilkan header kolom dalam file Excel
echo "ID Admin\tNama\tNama Lengkap\tEmail\tNo HP\tCreated At\n";

// Loop untuk menampilkan data dalam format Excel
while ($admin = $result->fetch_assoc()) {
    // Menangani kolom yang mungkin kosong
    $email = $admin['email'] ? $admin['email'] : '-';
    $no_hp = $admin['no_hp'] ? $admin['no_hp'] : '-';
    
    // Menampilkan data dalam format Excel
    echo $admin['id_admin'] . "\t" . $admin['nama'] . "\t" . $admin['nama_lengkap'] . "\t" . $email . "\t" . $no_hp . "\t" . $admin['created_at'] . "\n";
}
?>
