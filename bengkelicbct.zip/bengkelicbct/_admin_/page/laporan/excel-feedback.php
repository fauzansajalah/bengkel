<?php
include '../../../_config/koneksi/koneksi.php';

// Mengatur header untuk download file Excel
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_feedback.xls");

// Query untuk mengambil data dari tabel feedback
$query = "SELECT * FROM feedback";
$result = $koneksi->query($query);

// Menampilkan header kolom dalam file Excel
echo "ID Feedback\tRating\tKomentar\tTanggal Feedback\n";

// Loop untuk menampilkan data dalam format Excel
while ($feedback = $result->fetch_assoc()) {
    // Menangani komentar yang mungkin mengandung tab atau karakter khusus
    $komentar = str_replace("\t", "    ", $feedback['komentar']);
    
    // Menampilkan data dalam format Excel
    echo $feedback['id_feedback'] . "\t" . $feedback['rating'] . "\t" . $komentar . "\t" . $feedback['tanggal_feedback'] . "\n";
}
?>
