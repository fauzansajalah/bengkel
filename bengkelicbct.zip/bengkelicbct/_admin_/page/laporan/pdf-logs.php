<?php
require('../../../libary/fpdf.php');
include '../../../_config/koneksi/koneksi.php';

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Set the title
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(190, 10, 'Admin Logs Report', 0, 1, 'C');

// Header tabel
function addTableHeader($pdf) {
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1, 0, 'C');
    $pdf->Cell(20, 7, 'ID Admin', 1, 0, 'C');
    $pdf->Cell(90, 7, 'Action', 1, 0, 'C');
    $pdf->Cell(70, 7, 'Timestamp', 1, 1, 'C');
}

addTableHeader($pdf);

// Ambil data dari tabel admin_logs
$pdf->SetFont('Times', '', 10);
$sql = "SELECT * FROM admin_logs";
$result = $koneksi->query($sql);
$no = 1;

while ($isi = $result->fetch_assoc()) {
    // Cek apakah halaman sudah penuh, jika penuh tambahkan halaman baru
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        addTableHeader($pdf);
    }

    // Hitung tinggi baris berdasarkan teks terpanjang
    $rowHeight = max(
        $pdf->GetStringWidth($isi['id_admin']) / 20,
        $pdf->GetStringWidth($isi['action']) / 90,
        $pdf->GetStringWidth($isi['timestamp']) / 70
    ) * 6;

    // Isi data dalam tabel
    $pdf->Cell(10, 6, $no++, 1, 0, 'C');
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    // ID Admin
    $pdf->MultiCell(20, 6, $isi['id_admin'], 1);
    $pdf->SetXY($x + 20, $y);

    // Action
    $pdf->MultiCell(90, 6, $isi['action'], 1);
    $pdf->SetXY($x + 110, $y);

    // Timestamp
    $pdf->MultiCell(70, 6, $isi['timestamp'], 1);

    // Pindah ke baris baru sesuai dengan tinggi baris
    $pdf->Ln($rowHeight);
}

$pdf->Output();
?>
