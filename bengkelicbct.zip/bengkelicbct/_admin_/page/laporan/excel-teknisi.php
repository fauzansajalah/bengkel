<?php
include '../../../_config/koneksi/koneksi.php';

header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_teknisi.xls");

$query = "SELECT * FROM teknisi";
$result = $koneksi->query($query);

echo "ID\tNama\tEmail\tKategori\tSpesialisasi\tPengalaman\tNo HP\tStatus\n";

while ($tek = $result->fetch_assoc()) {
    echo $tek['id_teknisi'] . "\t" . $tek['nama'] . "\t" . $tek['email'] . "\t" . $tek['kategori'] . "\t" . $tek['spesialisasi'] . "\t" . substr($tek['pengalaman'], 0, 200) . "\t" . $tek['no_hp'] . "\t" . $tek['status'] . "\n";
}

?>
