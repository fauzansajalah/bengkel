<?php
include '../../../_config/koneksi/koneksi.php';

// Mengatur header untuk download file Excel
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_layanan.xls");

// Query untuk mengambil data dari tabel layanan
$query = "SELECT * FROM layanan";
$result = $koneksi->query($query);

// Menampilkan header kolom dalam file Excel
echo "ID Layanan\tKategori\tMenu Layanan\tNama Layanan\tDeskripsi\tHarga\n";

// Loop untuk menampilkan data dalam format Excel
while ($layanan = $result->fetch_assoc()) {
    // Menangani deskripsi yang mungkin mengandung tab atau karakter khusus
    $deskripsi = str_replace("\t", "    ", $layanan['deskripsi']);
    
    // Menampilkan data dalam format Excel
    echo $layanan['id_layanan'] . "\t" . $layanan['kategori'] . "\t" . $layanan['menu_layanan'] . "\t" . $layanan['nama_layanan'] . "\t" . $deskripsi . "\t" . $layanan['harga'] . "\n";
}
?>
