<?php
require('../../../libary/fpdf.php');
include '../../../_config/koneksi/koneksi.php';

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Set the title
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(190, 10, 'Data Layanan', 0, 1, 'C');

// Header tabel
function addTableHeader($pdf) {
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Kategori', 1, 0, 'C');
    $pdf->Cell(40, 7, 'Menu Layanan', 1, 0, 'C');
    $pdf->Cell(50, 7, 'Nama Layanan', 1, 0, 'C');
    $pdf->Cell(60, 7, 'Harga', 1, 1, 'C');
}

addTableHeader($pdf);

// Data layanan
$pdf->SetFont('Times', '', 10);
$sql = "SELECT * FROM layanan";
$result = $koneksi->query($sql);
$a = 1;

while ($isi = $result->fetch_assoc()) {
    // Cek apakah halaman sudah penuh, jika penuh tambahkan halaman baru
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        addTableHeader($pdf);
    }

    // Hitung tinggi baris berdasarkan teks terpanjang
    $rowHeight = max(
        $pdf->GetStringWidth($isi['kategori']) / 30,
        $pdf->GetStringWidth($isi['menu_layanan']) / 40,
        $pdf->GetStringWidth($isi['nama_layanan']) / 50,
        $pdf->GetStringWidth(number_format($isi['harga'])) / 60
    ) * 6;

    // Isi data dalam tabel
    $pdf->Cell(10, 6, $a++, 1, 0, 'C');
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->MultiCell(30, 6, $isi['kategori'], 1);
    $pdf->SetXY($x + 30, $y);
    $pdf->MultiCell(40, 6, $isi['menu_layanan'], 1);
    $pdf->SetXY($x + 70, $y);
    $pdf->MultiCell(50, 6, $isi['nama_layanan'], 1);
    $pdf->SetXY($x + 120, $y);
    $pdf->MultiCell(60, 6, 'Rp ' . number_format($isi['harga']), 1);

    // Pindah ke baris baru sesuai dengan tinggi baris
    $pdf->Ln($rowHeight);
}

$pdf->Output();
?>
