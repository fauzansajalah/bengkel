<?php
require('../../../libary/fpdf.php');
include '../../../_config/koneksi/koneksi.php';

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Set the title
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(190, 10, 'Data Admin', 0, 1, 'C');

// Header tabel
function addTableHeader($pdf) {
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Nama', 1, 0, 'C');
    $pdf->Cell(50, 7, 'Nama Lengkap', 1, 0, 'C');
    $pdf->Cell(50, 7, 'Email', 1, 0, 'C');
    $pdf->Cell(30, 7, 'No HP', 1, 0, 'C');
    $pdf->Cell(20, 7, 'Created At', 1, 1, 'C');
}

addTableHeader($pdf);

// Data admin
$pdf->SetFont('Times', '', 10);
$sql = "SELECT * FROM admin";
$result = $koneksi->query($sql);
$a = 1;

while ($isi = $result->fetch_assoc()) {
    // Cek apakah halaman sudah penuh, jika penuh tambahkan halaman baru
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        addTableHeader($pdf);
    }

    // Hitung tinggi baris berdasarkan teks terpanjang
    $rowHeight = max(
        $pdf->GetStringWidth($isi['nama']) / 30,
        $pdf->GetStringWidth($isi['nama_lengkap']) / 50,
        $pdf->GetStringWidth($isi['email']) / 50,
        $pdf->GetStringWidth($isi['no_hp']) / 30,
        $pdf->GetStringWidth($isi['created_at']) / 20
    ) * 6;

    // Isi data dalam tabel
    $pdf->Cell(10, $rowHeight, $a++, 1, 0, 'C');
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->MultiCell(30, 6, $isi['nama'], 1);
    $pdf->SetXY($x + 30, $y);
    $pdf->MultiCell(50, 6, $isi['nama_lengkap'], 1);
    $pdf->SetXY($x + 80, $y);
    $pdf->MultiCell(50, 6, $isi['email'], 1);
    $pdf->SetXY($x + 130, $y);
    $pdf->MultiCell(30, 6, $isi['no_hp'], 1);
    $pdf->SetXY($x + 160, $y);
    $pdf->MultiCell(20, 6, $isi['created_at'], 1);

    // Pindah ke baris baru sesuai dengan tinggi baris
    $pdf->Ln($rowHeight);
}

$pdf->Output();
?>
