<?php
// Konfigurasi database
$host = 'localhost'; // Jangan tambahkan ":PORT" kecuali diperlukan
$username = 'root';
$password = ''; // Password default Laragon adalah kosong
$database = 'bengkelicb'; // Nama database Anda

// Membuat koneksi menggunakan MySQLi (menggunakan objek-oriented)
$koneksi = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error); // Menampilkan error jika koneksi gagal
}
?>
