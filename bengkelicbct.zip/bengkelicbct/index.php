<?php
include '_config/koneksi/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel ICB-CT</title>
    <link rel="stylesheet" href="_assets/css/index/styles.css">
    <link rel="stylesheet" href="_assets/css/index/sidebar.css">
    <link rel="stylesheet" href="_assets/css/home/home.css">
    <link rel="stylesheet" href="_assets/css/about.css">
    <link rel="stylesheet" href="_assets/css/booking.css">
    <link rel="stylesheet" href="_assets/css/service.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Top Navbar -->
<div class="top-navbar" id="topNavbar">
    <button class="navbar-toggler" onclick="toggleSidebar()">
        <i class="bi bi-list"></i> 
    </button>
    <span class="fs-5">BENGKEL ICB CT</span> <!-- Judul navbar -->
    <div class="navbar-menu">
        <a href="javascript:void(0);" class="nav-link" onclick="navigateTo('about')" data-menu="about">
            <i class="bi bi-info-circle"></i> 
        </a>
    </div>
</div>


<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <li class="nav-item">
        <a href="javascript:void(0);" class="nav-link" onclick="navigateTo('home')" data-menu="home">
            <i class="bi bi-house-door sidebar-icon"></i> Home
        </a>
        <a href="javascript:void(0);" class="nav-link" onclick="navigateTo('feedback')" data-menu="feedback">
            <i class="fas fa-paper-plane sidebar-icon"></i> Feedback
        </a>
        <button class="dropdown-btn nav-link" onclick="toggleDropdown('dropdown-sosmed')">
            <i class="bi bi-share sidebar-icon"></i> Sosial Media 
            <i class="bi bi-caret-down-fill ms-auto"></i>
        </button>
        <!-- tidak di fungsikan -->
        <div class="dropdown-container" id="dropdown-sosmed">
            <a href="https://www.instagram.com/smkicbcintateknika/" class="nav-link" target="_blank">
                <i class="bi bi-instagram sidebar-icon"></i> Instagram
            </a>
            <a href="#gatau fb nya" class="nav-link" target="_blank">
                <i class="bi bi-facebook sidebar-icon"></i> Facebook
            </a>
            <a href="#gatawu twiternya" class="nav-link" target="_blank">
                <i class="bi bi-twitter sidebar-icon"></i> Twitter
            </a>
            <a href="#gtw yt nya" class="nav-link" target="_blank">
                <i class="bi bi-youtube sidebar-icon"></i> YouTube
            </a>
        </div>
    </li>
</nav>

        <!-- Content -->
    <div class="content" id="main-content">
        <div class="container">
            <!-- Konten dinamis akan dimuat di sini -->
        </div>
    </div>
    
    <!-- Bottom Menu -->
    <div class="bottom-menu">
        <a href="javascript:void(0);" onclick="home_bottom()" data-menu="home_bottom" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="javascript:void(0);" onclick="service()" data-menu="service" class="menu-item">
            <i class="fas fa-tools"></i>
            <span>Service</span>
        </a>
        <a href="javascript:void(0);" onclick="booking()" data-menu="booking" class="menu-item">
            <i class="fas fa-calendar-alt"></i>
            <span>Booking</span>
        </a>
        <a href="javascript:void(0);" onclick="history()" data-menu="history" class="menu-item">
            <i class="fas fa-history"></i>
            <span>History</span>
        </a>

        <a href="javascript:void(0);" onclick="profile()" data-menu="profile" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>
    
<!-- JavaScript Libraries -->
<script src="_plugins/jquery-3.6.0.min.js"></script>
<script src="_plugins/sweetalert.js"></script>
<script src="_plugins/chart.js"></script>
<script src="_plugins/boostrap.bundle.min.js"></script>
<!-- Kode JavaScript Kustom -->
<script src="_assets/js/script.js"></script>
<script src="_assets/js/booking.js"></script>
<script src="_assets/js/service.js"></script>
<script src="_assets/js/home/home.js"></script>

</body>
</html>