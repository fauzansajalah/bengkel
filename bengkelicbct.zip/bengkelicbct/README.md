-Pelanggan==> Transaksi, kirim feedback
-Teknisi==> Edit Profile Teknisi, update status, Menjual jasa untuk Pelanggan tentunya
-Admin==> Edit layanan, Add Teknisi, nerima Feedback dan lain lain *jika ingin login menggunakan akun admin gunakan /admin

akun yang sudah ada

pelanggan:
email=fauzanalazhar9@gmail.com
password=fauzan

teknisi:
(nama=fauzan
email=mobil1@example.com
password=123
),
(nama=gm chess
email=mobil2@example.com
password=123
),
(nama=ahmat tahalu
email=motor1@example.com
password=123
),
(nama=lubu
email=motor2@example.com
password=123
),


admin:
(email=admin1@example.com
password=123),
(email=admin@example.com
password=123),


pantun:
ke rumah nenek makan pepaya,
tidak lupa makan gorengan,
native kupilih karena terpercaya,
kompatibel tanpa saingan :v


kenapa tidak memakai framework:
sebenarnya saat awal awal lomba, saya belum terlalu menguasai framework, sehingga native menjadi pilihan terbaik menurut saya waktu itu, saat makin kesini saya sadar ternyata pakai framework lebih simple dan lebih aman keamanannya, mau ganti ke framework tapi tanggung dah mau beres