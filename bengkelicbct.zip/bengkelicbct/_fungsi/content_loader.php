<?php
session_start();
include '../_config/koneksi/koneksi.php';

$menu = isset($_GET['menu']) ? $_GET['menu'] : 'home'; // Default ke 'home' jika menu tidak ada
$id = isset($_GET['id']) ? $_GET['id'] : null;

switch ($menu) {
    case 'home':
        require '../_page/home/home.php';
        break;
    case 'home_bottom':
        require '../_page/home/home.php';
        break;
    case 'service':
        require '../_page/service/service.php';
        break;  
    case 'booking':
        require '../_page/booking/booking.php';
        break;
    case 'history':
        require '../_page/history/history.php';
        break;
    case 'profile':
        require '../_page/profile/profile.php';
        break;    
    case 'login':
        require '../_page/profile/profile.php';
        break;    
    case 'feedback':
        require '../_page/feedback.php';
        break;    
    case 'about':
        require '../_page/about.php';
        break;
    case 'menu_mobil':
        require '../_page/service/layanan/layanan_mobil.php';
        break;
    case 'menu_motor':
        require '../_page/service/layanan/layanan_motor.php';
        break;
    case 'menu_teknisi':
        require '../_page/booking/booking.php';
        break;
    case 'teknisi_mobil':
        require '../_page/booking/teknisi/teknisi_mobil/teknisi_mobil.php';
        break;
    case 'teknisi_motor':
        require '../_page/booking/teknisi/teknisi_motor/teknisi_motor.php';
        break;
    case 'perawatan_mobil':
        require '../_page/service/layanan/layanan_mobil/perawatan.php';
        break;
    case 'perbaikan_mobil':
        require '../_page/service/layanan/layanan_mobil/perbaikan.php';
        break;
    case 'diagnostik_mobil':
        require '../_page/service/layanan/layanan_mobil/diagnostik.php';
        break;
    case 'inspeksi_mobil':
        require '../_page/service/layanan/layanan_mobil/inspeksi.php';
        break;
    case 'kustom_mobil':
        require '../_page/service/layanan/layanan_mobil/kustom.php';
        break;
    case 'sukucadang_mobil':
        require '../_page/service/layanan/layanan_mobil/suku_cadang.php';
        break;
    case 'darurat_mobil':
        require '../_page/service/layanan/layanan_mobil/darurat.php';
        break;
    case 'cuci_mobil':
        require '../_page/service/layanan/layanan_mobil/cuci.php';
        break;
    case 'perawatan_motor':
        require '../_page/service/layanan/layanan_motor/perawatan.php';
        break;
    case 'perbaikan_motor':
        require '../_page/service/layanan/layanan_motor/perbaikan.php';
        break;
    case 'diagnostik_motor':
        require '../_page/service/layanan/layanan_motor/diagnostik.php';
        break;
    case 'inspeksi_motor':
        require '../_page/service/layanan/layanan_motor/inspeksi.php';
        break;
    case 'kustom_motor':
        require '../_page/service/layanan/layanan_motor/kustom.php';
        break;
    case 'sukucadang_motor':
        require '../_page/service/layanan/layanan_motor/suku_cadang.php';
        break;
    case 'darurat_motor':
        require '../_page/service/layanan/layanan_motor/darurat.php';
        break;
    case 'cuci_motor':
        require '../_page/service/layanan/layanan_motor/cuci.php';
        break;
    case 'darurat_motorT':
        require '../_page/booking/teknisi/teknisi_motor/darurat.php';
        break;
    case 'diagnostik_motorT':
        require '../_page/booking/teknisi/teknisi_motor/diagnostik.php';
        break;
    case 'inspeksi_motorT':
        require '../_page/booking/teknisi/teknisi_motor/inspeksi.php';
        break;
    case 'kustom_motorT':
        require '../_page/booking/teknisi/teknisi_motor/kustom.php';
        break;
    case 'perawatan_motorT':
        require '../_page/booking/teknisi/teknisi_motor/perawatan.php';
        break;
    case 'perbaikan_motorT':
        require '../_page/booking/teknisi/teknisi_motor/perbaikan.php';
        break;
    case 'sukucadang_motorT':
        require '../_page/booking/teknisi/teknisi_motor/suku_cadang.php';
        break;
    case 'cuci_motorT':
        require '../_page/booking/teknisi/teknisi_motor/cuci.php';
        break;
    case 'darurat_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/darurat.php';
        break;
    case 'diagnostik_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/diagnostik.php';
        break;
    case 'inspeksi_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/inspeksi.php';
        break;
    case 'kustom_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/kustom.php';
        break;
    case 'perawatan_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/perawatan.php';
        break;
    case 'perbaikan_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/perbaikan.php';
        break;
    case 'sukucadang_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/suku_cadang.php';
        break;
    case 'cuci_mobilT':
        require '../_page/booking/teknisi/teknisi_mobil/cuci.php';
        break;
    default:
        echo 'Halaman tidak ditemukan.';
}
?>
