<?php
// Start session
session_start();

// Destroy all sessions and redirect to login page
session_destroy();
header("Location: /");
exit;
?>
