<?php
include '../../../_config/koneksi/koneksi.php';

// Mengatur header untuk mengembalikan HTML
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mengambil data dari form-urlencoded
    $nama = $_POST['nama'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);
    $no_hp = $_POST['no_hp'] ?? '';
    $alamat = $_POST['alamat'] ?? '';
    $tanggal_daftar = date("Y-m-d");

    // Validasi data minimal (bisa ditambahkan sesuai kebutuhan)
    if (empty($nama) || empty($email) || empty($password) || empty($no_hp) || empty($alamat)) {
        echo "<p>Semua field harus diisi.</p>";
        exit;
    }

    // Query untuk memasukkan data ke database
    $query = "INSERT INTO pelanggan (nama, email, password, no_hp, alamat, tanggal_daftar) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $koneksi->prepare($query);

    if ($stmt) {
        $stmt->bind_param("ssssss", $nama, $email, $password, $no_hp, $alamat, $tanggal_daftar);

        if ($stmt->execute()) {
            echo "<p>Registration successful!";
        } else {
            echo "<p>Registration failed. Silakan coba lagi nanti.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Database query preparation failed.</p>";
    }

    $koneksi->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Metode tidak valid. Hanya menerima metode POST.']);
}
?>
