<?php
include '../../../_config/koneksi/koneksi.php';
session_start();

header('Content-Type: application/json'); // Ubah header untuk JSON response

if (!$koneksi) {
    echo json_encode(['success' => false, 'message' => 'Koneksi ke database gagal.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Cek login di tabel pelanggan
    $queryPelanggan = "SELECT id_pelanggan, nama, email, password FROM pelanggan WHERE email = ?";
    $stmtPelanggan = $koneksi->prepare($queryPelanggan);

    if ($stmtPelanggan) {
        $stmtPelanggan->bind_param("s", $email);
        $stmtPelanggan->execute();
        $resultPelanggan = $stmtPelanggan->get_result();

        if ($resultPelanggan->num_rows > 0) {
            $userPelanggan = $resultPelanggan->fetch_assoc();
            if (password_verify($password, $userPelanggan['password'])) {
                $_SESSION['user_id'] = $userPelanggan['id_pelanggan'];
                $_SESSION['user_role'] = 'pelanggan';
                echo json_encode(['success' => true, 'role' => 'pelanggan']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Password salah untuk pelanggan.']);
                exit;
            }
        }
        $stmtPelanggan->close();
    }

    // Cek login di tabel teknisi
    $queryTeknisi = "SELECT id_teknisi, nama, email, password FROM teknisi WHERE email = ?";
    $stmtTeknisi = $koneksi->prepare($queryTeknisi);

    if ($stmtTeknisi) {
        $stmtTeknisi->bind_param("s", $email);
        $stmtTeknisi->execute();
        $resultTeknisi = $stmtTeknisi->get_result();

        if ($resultTeknisi->num_rows > 0) {
            $userTeknisi = $resultTeknisi->fetch_assoc();
            if ($password === $userTeknisi['password']) {
                $_SESSION['user_id'] = $userTeknisi['id_teknisi'];
                $_SESSION['user_role'] = 'teknisi';
                echo json_encode(['success' => true, 'role' => 'teknisi']);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Password salah untuk teknisi.']);
                exit;
            }
        }
        $stmtTeknisi->close();
    }
}

    echo json_encode(['success' => false, 'message' => 'Email tidak ditemukan di sistem.']);
    $koneksi->close();
?>
