<?php
// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

// Sertakan file koneksi database
include '../_config/koneksi/koneksi.php';

// Pastikan koneksi berhasil
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil ID pengguna dan role dari sesi
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role']; // Menyimpan role pengguna (pelanggan atau teknisi)

// Tentukan query berdasarkan role
if ($user_role === 'pelanggan') {
    // Ambil data pengguna dari tabel pelanggan
    $sql = "SELECT * FROM pelanggan WHERE id_pelanggan = ?";
} elseif ($user_role === 'teknisi') {
    // Ambil data pengguna dari tabel teknisi
    $sql = "SELECT * FROM teknisi WHERE id_teknisi = ?";
} elseif ($user_role === 'admin') {
    // Ambil data pengguna dari tabel teknisi
    $sql = "SELECT * FROM admin WHERE id_admin = ?";
} else {
    echo json_encode(['error' => 'Role tidak dikenali']);
    exit;
}

// Persiapkan dan eksekusi query
$stmt = $koneksi->prepare($sql);

// Cek jika prepare() gagal
if ($stmt === false) {
    die("Gagal mempersiapkan query: " . $koneksi->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Jika data pengguna ditemukan
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Menampilkan data pengguna dalam format JSON
    echo json_encode(['user' => $user]);
} else {
    echo json_encode(['error' => 'Data pengguna tidak ditemukan']);
}

?>
