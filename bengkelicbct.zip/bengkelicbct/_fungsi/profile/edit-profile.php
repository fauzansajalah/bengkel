
<?php
include '../../_config/koneksi/koneksi.php';

ob_clean();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Kode Anda disini
        $nama = htmlspecialchars($_POST['nama']);
        $email = htmlspecialchars($_POST['email']);
        $alamat = htmlspecialchars($_POST['alamat']);
        $no_hp = htmlspecialchars($_POST['no_hp']);
        $user_id = intval($_POST['user_id']);

        $sql = "UPDATE pelanggan SET nama = ?, email = ?, alamat = ?, no_hp = ? WHERE id_pelanggan = ?";
        $stmt = $koneksi->prepare($sql);

        if ($stmt === false) {
            throw new Exception('Gagal mempersiapkan query: ' . $koneksi->error);
        }

        $stmt->bind_param("ssssi", $nama, $email, $alamat, $no_hp, $user_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            throw new Exception('Gagal menyimpan data: ' . $koneksi->error);
        }

        $stmt->close();
        $koneksi->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>
