<?php
include('../../_config/koneksi/koneksi.php'); // File koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start(); // Mulai sesi jika belum dimulai

    // Ambil data dari sesi dan form
    $idPelanggan = $_SESSION['user_id'] ?? null; // Ambil ID pelanggan dari sesi
    $idTeknisi = $_POST['id_teknisi'] ?? null;
    $idLayanan = $_POST['id_layanan'] ?? null;
    $harga = $_POST['harga'] ?? 0; // Ambil harga dari form
    $alamat = trim($_POST['alamat'] ?? '');
    $noHp = trim($_POST['no_hp'] ?? '');
    $statusPembayaran = $_POST['status_pembayaran'] ?? 'Belum Dibayar';
    $metodePembayaran = $_POST['metode_pembayaran'] ?? 'Cash';
    $tanggalKonfirmasi = date('Y-m-d H:i:s');

    // Validasi data
    if (!$idPelanggan || !$idTeknisi || !$idLayanan || !$harga || !$alamat || !$noHp) {
        echo "<p>Data tidak lengkap. Silakan coba lagi.</p>";
        exit;
    }

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // Insert ke tabel transaksi
        $sqlInsertTransaksi = "INSERT INTO transaksi (id_pelanggan, id_teknisi, id_layanan, tanggal_transaksi, status_pembayaran, metode_pembayaran) 
                               VALUES (?, ?, ?, ?, ?, ?)";
        $stmtTransaksi = $koneksi->prepare($sqlInsertTransaksi);
        $tanggalTransaksi = date('Y-m-d H:i:s');
        $stmtTransaksi->bind_param('iiisss', $idPelanggan, $idTeknisi, $idLayanan, $tanggalTransaksi, $statusPembayaran, $metodePembayaran);

        if (!$stmtTransaksi->execute()) {
            throw new Exception("Gagal menyimpan data transaksi: " . $stmtTransaksi->error);
        }

        // Ambil ID transaksi yang baru saja di-insert
        $idTransaksi = $koneksi->insert_id;

        // Insert ke tabel history_pelanggan
        $sqlInsertHistory = "INSERT INTO history_pelanggan (id_transaksi, id_pelanggan, id_teknisi, id_layanan, alamat, no_hp, tanggal_konfirmasi, status_pembayaran, harga) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmtHistory = $koneksi->prepare($sqlInsertHistory);
        $stmtHistory->bind_param('iiisssssd', $idTransaksi, $idPelanggan, $idTeknisi, $idLayanan, $alamat, $noHp, $tanggalKonfirmasi, $statusPembayaran, $harga);

        if (!$stmtHistory->execute()) {
            throw new Exception("Gagal menyimpan data history pelanggan: " . $stmtHistory->error);
        }

        // Ambil tahun dan bulan dari tanggal konfirmasi
        $tahun = date('Y', strtotime($tanggalKonfirmasi));
        $bulan = date('F', strtotime($tanggalKonfirmasi));

        // Cek apakah data tahun dan bulan sudah ada di tabel pelanggan_per_bulan
        $sqlCekPelangganPerBulan = "SELECT id, jumlah_pelanggan FROM pelanggan_per_bulan WHERE tahun = ? AND bulan = ?";
        $stmtCek = $koneksi->prepare($sqlCekPelangganPerBulan);
        $stmtCek->bind_param('is', $tahun, $bulan);
        $stmtCek->execute();
        $resultCek = $stmtCek->get_result();

        if ($resultCek->num_rows > 0) {
            // Jika data sudah ada, update jumlah pelanggan
            $row = $resultCek->fetch_assoc();
            $jumlahPelangganBaru = $row['jumlah_pelanggan'] + 1;

            $sqlUpdatePelangganPerBulan = "UPDATE pelanggan_per_bulan SET jumlah_pelanggan = ? WHERE id = ?";
            $stmtUpdate = $koneksi->prepare($sqlUpdatePelangganPerBulan);
            $stmtUpdate->bind_param('ii', $jumlahPelangganBaru, $row['id']);
            $stmtUpdate->execute();
        } else {
            // Jika data belum ada, insert data baru
            $sqlInsertPelangganPerBulan = "INSERT INTO pelanggan_per_bulan (tahun, bulan, jumlah_pelanggan) VALUES (?, ?, 1)";
            $stmtInsert = $koneksi->prepare($sqlInsertPelangganPerBulan);
            $stmtInsert->bind_param('is', $tahun, $bulan);
            $stmtInsert->execute();
        }

        // Commit transaksi jika semua berhasil
        $koneksi->commit();

        // Redirect ke halaman sukses
        header("Location: ../../_page/history/history.php?insert=success");
        exit;
    } catch (Exception $e) {
        // Rollback transaksi jika ada kesalahan
        $koneksi->rollback();
        echo "<p>Terjadi kesalahan: " . htmlspecialchars($e->getMessage()) . "</p>";
    } finally {
        $stmtTransaksi->close();
        $stmtHistory->close();
        $stmtCek->close();
        $koneksi->close();
    }
}
?>
