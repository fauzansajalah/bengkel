<?php
function getLayanan($kategori, $menu_layanan, $searchTerm = '') {
    global $koneksi; // Pastikan $koneksi sudah diinisialisasi
    $searchTerm = '%' . $searchTerm . '%';
    $query = "SELECT nama_layanan FROM layanan WHERE kategori = ? AND menu_layanan = ? AND nama_layanan LIKE ? LIMIT 10";
    $stmt = $koneksi->prepare($query);

    if (!$stmt) {
        die("Query gagal dipersiapkan: " . $koneksi->error);
    }

    $stmt->bind_param("sss", $kategori, $menu_layanan, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    $layanan = [];
    while ($row = $result->fetch_assoc()) {
        $layanan[] = $row['nama_layanan'];
    }

    return $layanan;
}

?>