<?php
include('../../_config/koneksi/koneksi.php');

// Fungsi untuk mengambil data layanan berdasarkan nama layanan
function getLayananData() {
    global $koneksi;

    // Ambil nama layanan dari parameter GET
    $layanan = isset($_GET['layanan']) ? urldecode($_GET['layanan']) : '';

    // Cek jika layanan kosong
    if (empty($layanan)) {
        return null;
    }

    // Ambil detail layanan dari database
    $query = "SELECT * FROM layanan WHERE nama_layanan = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $layanan);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jika data ditemukan, kembalikan hasilnya
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

?>

