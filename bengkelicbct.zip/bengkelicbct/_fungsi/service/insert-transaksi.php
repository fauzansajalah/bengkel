<?php
include('../../_config/koneksi/koneksi.php'); // File koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start(); // Mulai sesi jika belum dimulai

    // Ambil data dari sesi dan form
    $idPelanggan = $_SESSION['user_id'] ?? null; // Ambil ID pelanggan dari sesi
    $idTeknisi = $_POST['id_teknisi'] ?? null;
    $idLayanan = $_POST['id_layanan'] ?? null;
    $statusPembayaran = $_POST['status_pembayaran'] ?? 'Belum Dibayar';
    $metodePembayaran = $_POST['metode_pembayaran'] ?? 'Cash';
    $tanggalTransaksi = date('Y-m-d H:i:s');

    // Validasi data
    if (!$idPelanggan || !$idTeknisi || !$idLayanan) {
        echo "<p>Data tidak lengkap. Silakan coba lagi.</p>";
        exit;
    }

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // Insert ke tabel transaksi
        $sqlInsertTransaksi = "INSERT INTO transaksi (id_pelanggan, id_teknisi, id_layanan, tanggal_transaksi, status_pembayaran, metode_pembayaran) 
                               VALUES (?, ?, ?, ?, ?, ?)";
        $stmtTransaksi = $koneksi->prepare($sqlInsertTransaksi);
        $stmtTransaksi->bind_param('iiisss', $idPelanggan, $idTeknisi, $idLayanan, $tanggalTransaksi, $statusPembayaran, $metodePembayaran);

        if (!$stmtTransaksi->execute()) {
            throw new Exception("Gagal menyimpan data transaksi: " . $stmtTransaksi->error);
        }

        // Commit transaksi jika berhasil
        $koneksi->commit();

        // Redirect ke halaman sukses
        header("Location: ../../_page/history/history.php?insert=success");
        exit;
    } catch (Exception $e) {
        // Rollback transaksi jika ada kesalahan
        $koneksi->rollback();
        echo "<p>Terjadi kesalahan: " . htmlspecialchars($e->getMessage()) . "</p>";
    } finally {
        if (isset($stmtTransaksi)) {
            $stmtTransaksi->close();
        }
        $koneksi->close();
    }
}
?>
