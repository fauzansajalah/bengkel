<?php
// Mengimpor file koneksi
include('../../_config/koneksi/koneksi.php');  // Pastikan path benar

// Fungsi untuk mendapatkan daftar teknisi
function getTeknisiList() {
    global $koneksi;  // Ganti $conn menjadi $koneksi

    // Query untuk mengambil data teknisi
    $sql = "SELECT id_teknisi, nama, kategori, spesialisasi, alamat, foto FROM teknisi";
    $result = $koneksi->query($sql);  // Ganti $conn menjadi $koneksi

    $teknisiList = [];

    // Jika ada hasil query, masukkan ke dalam array
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $teknisiList[] = $row;
        }
    }

    // Mengembalikan daftar teknisi
    return $teknisiList;
}
?>
