    <?php
    include('../_config/koneksi/koneksi.php');

    // Function to fetch teknisi for a specific category and all specializations
    function getTeknisi($kategori, $spesialisasi) {
        global $koneksi;  // Use $koneksi here

        // Check if the database connection is established
        if ($koneksi->connect_error) {
            die("Connection failed: " . $koneksi->connect_error); // If connection fails, stop execution
        }

        // If spesialisasi is an empty string, fetch all technicians for the given category
        if ($spesialisasi === '') {
            $sql = "SELECT * FROM teknisi WHERE kategori = ?";
            $stmt = $koneksi->prepare($sql);

            if ($stmt === false) {
                die("Error preparing query: " . $koneksi->error); // If preparing fails, show error
            }

            // Bind parameters
            $stmt->bind_param("s", $kategori);
        } else {
            // If spesialisasi is provided, filter by both kategori and spesialisasi
            $sql = "SELECT * FROM teknisi WHERE kategori = ? AND FIND_IN_SET(?, spesialisasi)";
            $stmt = $koneksi->prepare($sql);

            if ($stmt === false) {
                die("Error preparing query: " . $koneksi->error); // If preparing fails, show error
            }

            // Bind parameters
            $stmt->bind_param("ss", $kategori, $spesialisasi);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Initialize the array to store technician names
        $layanan = [];

        // Fetch teknisi names into the array
        while ($row = $result->fetch_assoc()) {
            $layanan[] = $row['nama']; // Store the name of the teknisi
        }

        return $layanan;
    }
    ?>
