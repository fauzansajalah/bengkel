<?php
include('../../_config/koneksi/koneksi.php');

// Mengambil parameter 'namaTeknisi' dari URL
$namaTeknisi = isset($_GET['namaTeknisi']) ? $_GET['namaTeknisi'] : '';

// Fungsi untuk mengambil layanan berdasarkan nama teknisi
function getLayananByTeknisi($namaTeknisi) {
    global $koneksi;

    // Query untuk mendapatkan kategori layanan dari teknisi
    $query = "SELECT kategori FROM teknisi WHERE nama = ?";
    $stmt = $koneksi->prepare($query);

    if (!$stmt) {
        die("Query gagal dipersiapkan: " . $koneksi->error);
    }

    $stmt->bind_param("s", $namaTeknisi);
    $stmt->execute();
    $result = $stmt->get_result();

    $layanan = [];
    while ($row = $result->fetch_assoc()) {
        $layanan[] = $row['kategori'];
    }

    return $layanan;
}

// Ambil data layanan untuk teknisi tertentu
$layanan = getLayananByTeknisi($namaTeknisi);
?>
