<?php

// Ambil data layanan
$data = getLayananData();

// Fungsi untuk mendapatkan data teknisi yang sesuai dengan kategori dan status aktif
function getTeknisiByKategori($kategori) {
    global $koneksi;
    $query = "SELECT * FROM teknisi WHERE kategori = ? AND status = 'aktif'";  // Menambahkan filter status = 'aktif'
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    $teknisiList = [];
    while ($row = $result->fetch_assoc()) {
        $teknisiList[] = $row;
    }
    return $teknisiList;
}

// Ambil teknisi berdasarkan kategori layanan
$kategoriLayanan = $data['kategori'];  // Kategori dari layanan yang ditampilkan
$teknisiList = getTeknisiByKategori($kategoriLayanan);

// Pilih teknisi acak jika ada teknisi
$randomTeknisi = $teknisiList ? $teknisiList[array_rand($teknisiList)] : null;
?>
