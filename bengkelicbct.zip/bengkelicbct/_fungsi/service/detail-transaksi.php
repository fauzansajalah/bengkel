<?php

include('../../_config/koneksi/koneksi.php'); // Pastikan file koneksi dimuat

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teknisiId = $_POST['id_teknisi'] ?? null;
    $layananId = $_POST['id_layanan'] ?? null;

    if ($teknisiId && $layananId) {
        // Ambil data layanan
        $sqlLayanan = "SELECT * FROM layanan WHERE id_layanan = ?";
        $stmtLayanan = $koneksi->prepare($sqlLayanan);
        $stmtLayanan->bind_param('i', $layananId);
        $stmtLayanan->execute();
        $resultLayanan = $stmtLayanan->get_result();
        $dataLayanan = $resultLayanan->fetch_assoc();

        // Ambil data teknisi
        $sqlTeknisi = "SELECT * FROM teknisi WHERE id_teknisi = ?";
        $stmtTeknisi = $koneksi->prepare($sqlTeknisi);
        $stmtTeknisi->bind_param('i', $teknisiId);
        $stmtTeknisi->execute();
        $resultTeknisi = $stmtTeknisi->get_result();
        $dataTeknisi = $resultTeknisi->fetch_assoc();

        $stmtLayanan->close();
        $stmtTeknisi->close();
    } else {
        echo "<p>Data tidak lengkap. Silakan pilih teknisi dan layanan.</p>";
    }
} else {
    echo "<p>Metode tidak didukung.</p>";
}

// Ambil data pelanggan berdasarkan sesi `user_id`
$userId = $_SESSION['user_id'] ?? null;
$pelangganData = [
    'alamat' => '',
    'no_hp' => '',
];

if ($userId) {
    $sqlPelanggan = "SELECT alamat, no_hp FROM pelanggan WHERE id_pelanggan = ?";
    $stmtPelanggan = $koneksi->prepare($sqlPelanggan);
    $stmtPelanggan->bind_param('i', $userId);
    $stmtPelanggan->execute();
    $resultPelanggan = $stmtPelanggan->get_result();

    if ($resultPelanggan->num_rows > 0) {
        $pelangganData = $resultPelanggan->fetch_assoc();
    }

    $stmtPelanggan->close();
}

$koneksi->close();
?>