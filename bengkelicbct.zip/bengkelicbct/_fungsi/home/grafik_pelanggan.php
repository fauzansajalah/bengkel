<?php
// Koneksi ke database
include '../../_config/koneksi/koneksi.php';

// Query untuk mendapatkan data pelanggan berdasarkan tahun dan bulan
$sql = "SELECT tahun, bulan, jumlah_pelanggan FROM pelanggan_per_bulan ORDER BY tahun DESC, bulan DESC LIMIT 12";
$result = $koneksi->query($sql);

$labels = [];
$data = [];

while ($row = $result->fetch_assoc()) {
    $labels[] = $row['tahun'] . '-' . str_pad($row['bulan'], 2, '0', STR_PAD_LEFT); // Format tahun-bulan
    $data[] = (int)$row['jumlah_pelanggan'];
}

// Mengembalikan data dalam format JSON
header('Content-Type: application/json');
echo json_encode(['labels' => $labels, 'data' => $data]);
exit;
?>
