<?php
// Sertakan koneksi database
include('../../../_config/koneksi/koneksi.php');

// Inisialisasi variabel
$teknisi = null;
$errorMessage = null;

// Periksa apakah parameter 'id' ada di URL
if (isset($_GET['id'])) {
    // Ambil ID teknisi dari URL
    $teknisiId = $_GET['id'];

    // Pastikan ID adalah angka (validasi tambahan)
    if (!is_numeric($teknisiId)) {
        $errorMessage = "ID teknisi tidak valid.";
    } else {
        // Siapkan query untuk menghindari SQL Injection
        $stmt = $koneksi->prepare("SELECT * FROM teknisi WHERE id_teknisi = ?");
        $stmt->bind_param("i", $teknisiId); // Parameter 'i' menunjukkan tipe data integer

        // Eksekusi query
        $stmt->execute();
        $result = $stmt->get_result();

        // Periksa apakah data teknisi ditemukan
        if ($result->num_rows > 0) {
            // Ambil data teknisi
            $teknisi = $result->fetch_assoc();
        } else {
            $errorMessage = "Teknisi tidak ditemukan.";
        }

        // Tutup statement
        $stmt->close();
    }
} else {
    $errorMessage = "ID teknisi tidak valid.";
}
?>
