<?php
// Menangkap data yang dikirimkan dari form sebelumnya
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id_teknisi']) && isset($_POST['spesialisasi'])) {

        // Dapatkan data teknisi dari database
        $id_teknisi = $_POST['id_teknisi'];
        $spesialisasi = $_POST['spesialisasi'];

        // Query untuk mendapatkan data teknisi berdasarkan id_teknisi
        $query = "SELECT * FROM teknisi WHERE id_teknisi = '$id_teknisi'";
        $result = mysqli_query($koneksi, $query); // Menggunakan $koneksi sesuai dengan konfigurasi Anda
        $teknisi = mysqli_fetch_assoc($result);

        // Menyimpan data teknisi lengkap ke session
        $_SESSION['teknisi'] = [
            'id_teknisi' => $teknisi['id_teknisi'],
            'nama' => $teknisi['nama'],
            'kategori' => $teknisi['kategori'],
            'spesialisasi' => $spesialisasi,
            'alamat' => $teknisi['alamat']
        ];
    }
}
?>