<?php
function getTeknisiByKategori($kategori) {
    global $koneksi; // Menggunakan koneksi dari file koneksi.php
    $sql = "SELECT * FROM teknisi WHERE kategori = '$kategori'";
    $result = $koneksi->query($sql); // Gunakan $koneksi->query() karena kita menggunakan OOP
    return $result;
}
// Ambil data teknisi kategori motor dan mobil
$teknisiMotor = getTeknisiByKategori('Motor');
$teknisiMobil = getTeknisiByKategori('Mobil');
?>