<?php
include('../../_config/koneksi/koneksi.php'); // Pastikan path koneksi sesuai dengan struktur folder Anda

$userId = $_SESSION['user_id'] ?? null;
$pelangganData = [
    'alamat' => '',
    'no_hp' => '',
];

if ($userId) {
    $sqlPelanggan = "SELECT alamat, no_hp FROM pelanggan WHERE id_pelanggan = ?";
    $stmtPelanggan = $koneksi->prepare($sqlPelanggan);
    $stmtPelanggan->bind_param('i', $userId);
    $stmtPelanggan->execute();
    $resultPelanggan = $stmtPelanggan->get_result();

    if ($resultPelanggan->num_rows > 0) {
        $pelangganData = $resultPelanggan->fetch_assoc();
    }

    $stmtPelanggan->close();
}

// Menangkap data teknisi yang sudah ada di session
if (isset($_POST['id_teknisi']) && isset($_POST['id_layanan'])) {
    $id_teknisi = $_POST['id_teknisi'];
    $id_layanan = $_POST['id_layanan'];

    // Query untuk mendapatkan data teknisi
    $query_teknisi = "SELECT * FROM teknisi WHERE id_teknisi = '$id_teknisi'";
    $result_teknisi = mysqli_query($koneksi, $query_teknisi);
    $teknisi = mysqli_fetch_assoc($result_teknisi);

    // Query untuk mendapatkan data layanan
    $query_layanan = "SELECT * FROM layanan WHERE id_layanan = '$id_layanan'";
    $result_layanan = mysqli_query($koneksi, $query_layanan);
    $layanan = mysqli_fetch_assoc($result_layanan);
} else {
    // Jika data teknisi atau layanan tidak ada
    echo '<p class="error">Data tidak ditemukan. Harap kembali dan pilih teknisi serta layanan.</p>';
    exit;
}
?>