<?php
// Include file koneksi
include '../../_config/koneksi/koneksi.php';

header('Content-Type: application/json');
$response = ['status' => 'error', 'message' => '', 'data' => null];

// Cek apakah ID teknisi dikirimkan via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_teknisi = $_POST['id_teknisi'] ?? null;

    // Validasi ID teknisi
    if (!$id_teknisi || !is_numeric($id_teknisi)) {
        $response['message'] = "ID teknisi tidak valid.";
    } else {
        // Ambil data teknisi
        $queryTeknisi = "SELECT * FROM teknisi WHERE id_teknisi = ?";
        $stmt = $koneksi->prepare($queryTeknisi);
        $stmt->bind_param("i", $id_teknisi);
        $stmt->execute();
        $resultTeknisi = $stmt->get_result();

        if ($resultTeknisi->num_rows > 0) {
            $teknisi = $resultTeknisi->fetch_assoc();

            // Ambil kategori layanan berdasarkan spesialisasi teknisi
            $queryLayanan = "SELECT * FROM layanan WHERE menu_layanan = ?";
            $stmtLayanan = $koneksi->prepare($queryLayanan);
            $stmtLayanan->bind_param("s", $teknisi['spesialisasi']);
            $stmtLayanan->execute();
            $resultLayanan = $stmtLayanan->get_result();

            $kategoriLayanan = [];
            while ($row = $resultLayanan->fetch_assoc()) {
                $kategoriLayanan[] = $row;
            }

            $response['status'] = 'success';
            $response['data'] = [
                'teknisi' => $teknisi,
                'layanan' => $kategoriLayanan
            ];
        } else {
            $response['message'] = "Teknisi dengan ID tersebut tidak ditemukan.";
        }

        $stmt->close();
    }
} else {
    $response['message'] = "Permintaan tidak valid.";
}
?>
