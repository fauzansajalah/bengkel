<?php
// Sertakan koneksi database
include '../../_config/koneksi/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_history = $_POST['id_history'];
    $id_history_booking = $_POST['id_history_booking'];
    $payment_method = $_POST['payment_method'];
    $success = false;

    // Periksa apakah id_history tersedia
    if (!empty($id_history)) {
        $query = "UPDATE history_pelanggan SET status_pembayaran = 'Sudah Dibayar' WHERE id_history = ?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("i", $id_history);
        $success = $stmt->execute();
        $stmt->close();
    }

    // Periksa apakah id_history_booking tersedia
    if (!empty($id_history_booking)) {
        $query = "UPDATE history_booking SET status_pembayaran = 'Sudah Dibayar' WHERE id_history_booking = ?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("i", $id_history_booking);
        $success = $stmt->execute();
        $stmt->close();
    }

    // Kirimkan respon ke JavaScript
    echo json_encode(['success' => $success]);
}
?>
