<div class="container">
<?php
// Sertakan file koneksi database
include '../../_config/koneksi/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'];
    $id_history = $_POST['id_history'];
    $id_history_booking = $_POST['id_history_booking'];

    // Query untuk mengambil data dari history_pelanggan
    $query_service = "
        SELECT 
            hp.harga, 
            t.nama AS nama_teknisi, 
            t.e_wallet_id, 
            p.nama AS nama_pelanggan, 
            l.kategori, 
            l.menu_layanan, 
            l.nama_layanan 
        FROM 
            history_pelanggan hp
            LEFT JOIN pelanggan p ON hp.id_pelanggan = p.id_pelanggan
            LEFT JOIN teknisi t ON hp.id_teknisi = t.id_teknisi
            LEFT JOIN layanan l ON hp.id_layanan = l.id_layanan
        WHERE 
            hp.id_history = ?
    ";

    // Query untuk mengambil data dari history_booking
    $query_booking = "
        SELECT 
            hb.tanggal_booking, 
            hb.pukul, 
            t.nama AS nama_teknisi, 
            t.e_wallet_id, 
            p.nama AS nama_pelanggan, 
            l.harga, 
            l.kategori, 
            l.menu_layanan, 
            l.nama_layanan 
        FROM 
            history_booking hb
            LEFT JOIN pelanggan p ON hb.id_pelanggan = p.id_pelanggan
            LEFT JOIN teknisi t ON hb.id_teknisi = t.id_teknisi
            LEFT JOIN layanan l ON hb.id_layanan = l.id_layanan
        WHERE 
            hb.id_history_booking = ?
    ";

    // Eksekusi query untuk history_pelanggan
    $stmt_service = $koneksi->prepare($query_service);
    $stmt_service->bind_param("i", $id_history);
    $stmt_service->execute();
    $result_service = $stmt_service->get_result();

    // Eksekusi query untuk history_booking
    $stmt_booking = $koneksi->prepare($query_booking);
    $stmt_booking->bind_param("i", $id_history_booking);
    $stmt_booking->execute();
    $result_booking = $stmt_booking->get_result();

    // Tampilkan hasil jika ditemukan
    if ($result_service->num_rows > 0 || $result_booking->num_rows > 0) {
        echo "<h2>Konfirmasi Pembayaran</h2>";
        echo "<p><strong>Metode Pembayaran yang Dipilih:</strong> " . htmlspecialchars($payment_method) . "</p>";

        if ($row_service = $result_service->fetch_assoc()) {
            echo "<p><strong>Layanan:</strong> " . htmlspecialchars($row_service['kategori']) . " - " . htmlspecialchars($row_service['menu_layanan']) . " - " . htmlspecialchars($row_service['nama_layanan']) . "</p>";
            echo "<p><strong>Harga:</strong> Rp" . number_format($row_service['harga'], 0, ',', '.') . "</p>";
            echo "<p><strong>Nama Teknisi:</strong> " . htmlspecialchars($row_service['nama_teknisi']) . "</p>";
        }

        if ($row_booking = $result_booking->fetch_assoc()) {
            echo "<p><strong>Layanan:</strong> " . htmlspecialchars($row_booking['kategori']) . " - " . htmlspecialchars($row_booking['menu_layanan']) . " - " . htmlspecialchars($row_booking['nama_layanan']) . "</p>";
            echo "<p><strong>Harga:</strong> " . htmlspecialchars($row_booking['harga']) . "</p>";
            echo "<p><strong>Tanggal Booking:</strong> " . htmlspecialchars($row_booking['tanggal_booking']) . "</p>";
            echo "<p><strong>Pukul:</strong> " . htmlspecialchars($row_booking['pukul']) . "</p>";
            echo "<p><strong>Nama Teknisi:</strong> " . htmlspecialchars($row_booking['nama_teknisi']) . "</p>";
        }

        if (!empty($id_history)) {
            $idHistoryValue = $id_history;
        } else {
            $idHistoryValue = 'null';
        }
        
        if (!empty($id_history_booking)) {
            $idHistoryBookingValue = $id_history_booking;
        } else {
            $idHistoryBookingValue = 'null';
        }
        
        echo "<button class='btn-modal' onclick=\"confirmPayment('$payment_method', $idHistoryValue, $idHistoryBookingValue)\" class=\"btn-confirm\">Konfirmasi Pembayaran</button>";
        } else {
        echo "<p>Data tidak ditemukan.</p>";
    }

    // Tutup statement
    $stmt_service->close();
    $stmt_booking->close();
}
?>
</div>

<script>function confirmPayment(paymentMethod, idHistory, idHistoryBooking) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: `Konfirmasi pembayaran dengan metode ${paymentMethod}`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Konfirmasi!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            // Buat form data untuk dikirim ke server
            const formData = new FormData();
            formData.append('payment_method', paymentMethod);
            formData.append('id_history', idHistory);
            formData.append('id_history_booking', idHistoryBooking);

            // Kirim request untuk update status pembayaran
            fetch('../../_fungsi/history/update_pembayaran.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Pembayaran berhasil dikonfirmasi!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        // Refresh halaman atau alihkan ke halaman lain
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'Gagal!',
                        text: 'Terjadi kesalahan saat mengonfirmasi pembayaran.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            })
            .catch(error => {
                console.error('Terjadi kesalahan:', error);
                Swal.fire({
                    title: 'Error!',
                    text: 'Tidak dapat terhubung ke server.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            });
        }
    });
}
</script>