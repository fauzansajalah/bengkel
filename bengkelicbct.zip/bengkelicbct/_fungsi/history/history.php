<?php
    include '../../_config/koneksi/koneksi.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, tampilkan pesan
    echo "<p>Anda perlu login untuk memesan layanan.</p>";
    exit(); // Hentikan eksekusi skrip
}

// Periksa apakah user sudah login
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'pelanggan') {
    header('Location: ../../_page/profile/login.php');
    exit;
}

$id_pelanggan = $_SESSION['user_id'];

// Query data history pelanggan
$query = "SELECT 
          hp.id_history,
          t.nama AS nama_teknisi,
          p.nama AS nama_pelanggan,
          l.kategori,
          l.menu_layanan,
          l.nama_layanan,
          hp.harga,
          hp.alamat,
          hp.konfirmasi_teknisi,
          hp.status_pembayaran
        FROM 
          history_pelanggan hp
        JOIN 
          teknisi t ON hp.id_teknisi = t.id_teknisi
        JOIN 
          pelanggan p ON hp.id_pelanggan = p.id_pelanggan
        JOIN 
          layanan l ON hp.id_layanan = l.id_layanan
        WHERE 
          hp.id_pelanggan = '$id_pelanggan'";

$result = $koneksi->query($query);
?>