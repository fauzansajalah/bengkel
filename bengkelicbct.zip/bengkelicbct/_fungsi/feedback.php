<?php
include('../_config/koneksi/koneksi.php');

// Mengatur header untuk JSON
header('Content-Type: application/json');

// Variabel untuk menyimpan status feedback
$feedbackStatus = null;

// Membaca input JSON
$inputData = json_decode(file_get_contents('php://input'), true); // Ambil dan decode JSON

// Pastikan input tidak kosong
if (isset($inputData['rating']) && isset($inputData['komentar'])) {
    $rating = $inputData['rating'];
    $komentar = $inputData['komentar'];

    // Escape input untuk mencegah SQL injection
    $rating = mysqli_real_escape_string($koneksi, $rating);
    $komentar = mysqli_real_escape_string($koneksi, $komentar);

    // Simpan feedback ke database
    $query = "INSERT INTO feedback (rating, komentar) VALUES ('$rating', '$komentar')";
    if (mysqli_query($koneksi, $query)) {
        $feedbackStatus = "success"; // Berhasil
    } else {
        $feedbackStatus = "error"; // Gagal
    }
} else {
    $feedbackStatus = "error"; // Jika data tidak valid
}

// Kirim response dalam format JSON
echo json_encode(['status' => $feedbackStatus]);
?>
